package com.gurukul.satsang;

public class ShastraCategoryListRow {

	public String galaryID;
	public String galaryName;
	
	public ShastraCategoryListRow(String galaryID, String galaryName) {
		this.galaryID = galaryID;
		this.galaryName = galaryName;
	}

	public String getGalaryID() {
		return galaryID;
	}

	public void setGalaryID(String galaryID) {
		this.galaryID = galaryID;
	}

	public String getGalaryName() {
		return galaryName;
	}

	public void setGalaryName(String galaryName) {
		this.galaryName = galaryName;
	}
}
