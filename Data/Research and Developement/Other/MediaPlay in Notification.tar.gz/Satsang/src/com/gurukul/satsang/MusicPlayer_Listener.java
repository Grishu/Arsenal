package com.gurukul.satsang;

public interface MusicPlayer_Listener {
   void getPlayingSongIndex(int index);
}
