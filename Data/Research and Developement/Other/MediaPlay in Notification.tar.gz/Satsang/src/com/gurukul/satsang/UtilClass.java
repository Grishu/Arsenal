package com.gurukul.satsang;

public class UtilClass {

    public static Boolean playing = false;
    public static boolean pause = false;
}
