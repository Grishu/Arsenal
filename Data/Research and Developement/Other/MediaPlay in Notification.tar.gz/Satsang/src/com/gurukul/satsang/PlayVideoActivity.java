package com.gurukul.satsang;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.MediaController;

public class PlayVideoActivity extends Activity {

//	private Uri uri;

	public MediaController		mController = null;
	public static final int		USER_MOBILE = 0;
	private ImageButton			btnBack;
	private WebView				playVideo;
	private CommonClass			mCommonClass;
	private String				path;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_play_video);
		initialize();
		
		btnBack.setOnClickListener(new OnClickListener() {
			@SuppressLint("NewApi")
			@Override
			public void onClick(View v) {
				finish();
				playVideo.destroy();
			}
		});

		if(mCommonClass.CheckNetwork(getApplicationContext()) == true){
			playVideo();
		} else {
			showError("Satsang", "Network not available");
		}
		
	}
	
	public void initialize(){
		btnBack			=	(ImageButton) findViewById(R.id.btn_back_in_play_video);
		playVideo		=	(WebView) findViewById(R.id.play_video);
		mCommonClass	=	new CommonClass();
		
		String str		=	getIntent().getStringExtra("VIDEO_PATH");
		if(str.equalsIgnoreCase("http://www.youtube.com/watch?v=o_VYvCMtXcM")){
			path			=	"http://www.youtube.com/embed/o_VYvCMtXcM";
		} else {
			path			=	getIntent().getStringExtra("VIDEO_PATH").replace("watch", "embed");
		}
		System.out.println("VIDEO_PATH = "+ path);
	}
	
	@SuppressLint("SetJavaScriptEnabled")
	private void playVideo() {
		try {
			playVideo.setWebViewClient(new WebViewClient() {
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			}
			});
			playVideo.getSettings().setJavaScriptEnabled(true);
			playVideo.setWebChromeClient(new WebChromeClient());
			playVideo.getSettings().setAllowFileAccess(true);
			playVideo.setWebChromeClient(new WebChromeClient() {
				@Override
				public void onProgressChanged(WebView view, int newProgress) {
					super.onProgressChanged(view, newProgress);
					if (newProgress == 100) {
					} else {
					}
				}

			});
			/****************************************************************************
			 * The below code is to open keyboard while surfing the site in
			 * webview.Webview has to be requested focus explicitly so that it
			 * can open keyboard in turn when any textbox is tapped into webpage
			 ****************************************************************************/
			playVideo.requestFocus(View.FOCUS_DOWN);
			playVideo.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View mView, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
						case MotionEvent.ACTION_UP:
							try {
								if (!mView.hasFocus()) {
									mView.requestFocus();
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							break;
					}
					return false;
				}
			});
			playVideo.loadUrl(path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void showError(String title, String msg){
		
		AlertDialog.Builder b = new Builder(PlayVideoActivity.this);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					finish();
			}
		});
		AlertDialog d = b.create();
		d.show();
	}

	@Override
		public void onBackPressed() {
			super.onBackPressed();
			finish();
			playVideo.destroy();
		}
}