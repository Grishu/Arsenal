package com.gurukul.satsang;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

public class VideoCategoryActivity extends Activity {

	private ImageButton btnBack;
	private ListView lstVideoCategory;
	private CustomList adapter;
	private ArrayList<ShastraCategoryListRow> rowItem;
	private CommonClass mCommClass;	
	private String classID;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_video_category);
		initialize();
		
		if(mCommClass.CheckNetwork(VideoCategoryActivity.this) == true){
			videoCatTask = new LoadingVideoCatTask();
		  	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					videoCatTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.format(Constant.videoCatListURL, classID));
				} else {
					videoCatTask.execute(String.format(Constant.videoCatListURL, classID));
				}
		} else {
			showError("Satsang", "Please check internet connection");
		}
		
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}
	
	public void initialize(){
		btnBack				=	(ImageButton) findViewById(R.id.btn_back_in_video_cat_list);
		lstVideoCategory	=	(ListView) findViewById(R.id.lst_video_cat);
		rowItem				=	new ArrayList<ShastraCategoryListRow>();
		mCommClass			=	new CommonClass();
		classID				=	"2";
	}
	
	LoadingVideoCatTask videoCatTask = null;
	public class LoadingVideoCatTask extends AsyncTask<String, String, String> {

		private ProgressDialog mProgressDialog = null;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(VideoCategoryActivity.this);
			mProgressDialog.setMessage(Constant.msgLoading);
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.show();
		}
		
		@Override
		protected String doInBackground(String... url) {
			JSONParser jParser = new JSONParser();
			String json = jParser.getJSONFromUrl(url[0]);
			return json;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (mProgressDialog != null) {
				mProgressDialog.dismiss();
			}
			if (result != null) {
				setListData(result);
			} else {
				Toast.makeText(VideoCategoryActivity.this, "no data found", Toast.LENGTH_LONG).show();
			}
		}
	}
	
	public void setListData(String data) {
		rowItem = null;
		rowItem = new ArrayList<ShastraCategoryListRow>();
		try {
			JSONArray mainDataArray = new JSONArray(data);
			
			if(mainDataArray.length() == 0){
				showError("Satsang", "No data found");
			} else {
				for (int i = 0; i < mainDataArray.length(); i++) {
					JSONObject shastraCatList = mainDataArray.getJSONObject(i);
					String gallery_id = shastraCatList.get("gallery_id").toString();
					System.out.println("gallery_id = " + gallery_id);
					String gallery_name = shastraCatList.getString("gallery_name");
					System.out.println("gallery_name = " + gallery_name);
					rowItem.add(new ShastraCategoryListRow(gallery_id, gallery_name));
				}
				
				adapter = new CustomList(getApplicationContext());
				lstVideoCategory.setAdapter(adapter);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private class CustomList extends BaseAdapter {

		private Context context;
		private TextView tvName;
		private ImageButton btnPlay;
		private View rowView;
		
		public CustomList(Context c) {
			this.context = c;
		}
		
		@Override
		public int getCount() {
			return rowItem.size();
		}

		@Override
		public ShastraCategoryListRow getItem(int position) {
			return rowItem.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			try {

				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				rowView = inflater.inflate(R.layout.video_cat_list_row, parent, false);
				tvName		= (TextView) rowView.findViewById(R.id.tv_galary_name_video_cat_list_row);
				btnPlay		= (ImageButton) rowView.findViewById(R.id.img_btn_video_cat_list_row);
				
				tvName.setText(rowItem.get(position).getGalaryName());
				
				rowView.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent in = new Intent();
						in.setClass(VideoCategoryActivity.this, VideoTrackListActivity.class);
						in.putExtra("Gallery_ID", rowItem.get(position).getGalaryID());
						startActivity(in);
					}
				});
				
				btnPlay.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent in = new Intent();
						in.setClass(VideoCategoryActivity.this, VideoTrackListActivity.class);
						in.putExtra("Gallery_ID", rowItem.get(position).getGalaryID());
						startActivity(in);
					}
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
			return rowView;
		}
	}
	
	public void showError(String title, String msg){
		
		AlertDialog.Builder b = new Builder(VideoCategoryActivity.this);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					finish();
			}
		});
		AlertDialog d = b.create();
		d.show();
	}
}