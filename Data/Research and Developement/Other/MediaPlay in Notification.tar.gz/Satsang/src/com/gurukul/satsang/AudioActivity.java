package com.gurukul.satsang;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;

public class AudioActivity extends Activity {
	
	public ImageButton btnBack;
	public ImageButton btnAudioBook;
	public ImageButton btnKirtan;
	public ImageButton btnKatha;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_audio);
		initialize();
		
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		btnAudioBook.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(AudioActivity.this, AudioBookCategory.class));
			}
		});
		
		btnKirtan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent().setClass(AudioActivity.this, KirtanCategoryActivity.class));	
			}
		});
		
		btnKatha.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent().setClass(AudioActivity.this, KathaCategoryActivity.class));	
			}
		});
		if(MusicPlayerService.getMusicPlayerService()==null){
			System.out.println("music player is null");
			 getApplicationContext().stopService(new Intent(getApplicationContext(),MusicPlayerService.class));
			 
	  		 Intent mIntent_Service = new Intent(getApplicationContext(),MusicPlayerService.class);
	  		 mIntent_Service.setAction(Constant.ACTIONS_FROM_ACTIVITY);
	  		 startService(mIntent_Service);
		}
	}
	
	public void initialize(){
		btnBack			= (ImageButton) findViewById(R.id.btn_back_in_audio);
		btnAudioBook	= (ImageButton) findViewById(R.id.btn_audio_book);
		btnKatha		= (ImageButton) findViewById(R.id.btn_katha);
		btnKirtan		= (ImageButton) findViewById(R.id.btn_kirtan);
	}
	
	@Override
	protected void onResume() {
		if(MusicPlayerService.getMusicPlayerService()==null){
			System.out.println("music player is null");
			 getApplicationContext().stopService(new Intent(getApplicationContext(),MusicPlayerService.class));
			 
	  		 Intent mIntent_Service = new Intent(getApplicationContext(),MusicPlayerService.class);
	  		 mIntent_Service.setAction(Constant.ACTIONS_FROM_ACTIVITY);
	  		 startService(mIntent_Service);
		}
		super.onResume();
	}
}