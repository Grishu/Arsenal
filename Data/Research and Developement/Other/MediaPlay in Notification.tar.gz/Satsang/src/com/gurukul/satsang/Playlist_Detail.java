package com.gurukul.satsang;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class Playlist_Detail extends Activity implements MusicPlayer_Listener {
	private static ProgressBar mProgress;
	private ImageButton btnPrevious=null,btnNext=null,btnStop=null;
	private static ImageButton btnPlay_Pause=null;
//	private TextView txt_aartiscreentitle=null;
	private static TextView txtcurrentduration=null;
	private static TextView txtcurrent_songposition=null;
	private static TextView txttotalduration=null;
	private static ImageButton btnBack;
	private int AudioFilePos = -1;
	
	public static final String MyPREFERENCES = "MyPrefs" ;
	static ArrayList<AudioBookListRow>		rowItem = null;
	static ArrayList<AudioBookListRow>		rowItem1 = new ArrayList<AudioBookListRow>();

    private boolean mFromTouch = false;
    private boolean paused;
    private static long mPosOverride = -1;
    private long mLastSeekEventTime;
	public static String					galaryID;
	public static String					playing_galary_ID;
	private String							fileName;
	private static boolean firstTime = true;
	private boolean flg_rowItem;
//	private boolean							isFirstTime		= false;
//	private boolean							mpStop			= false;
//	private int								currentsong		= 0;
	public static int						selected_pos	= 0;

	private CommonClass						mCommClass = new CommonClass();
    private ListView lst_playlist = null;
//    private SongAdapter mSongAdapter = null;
    
    private SharedPreferences mSharedPreferencesRead = null;
    
    private static Context context = null;
    
    static String songTitle = null;
    
    /**
     * This Activity keeps the screen on using the window manager, you don't have to worry about managing this
     * it will be kept on for the duration of the Activity life.
     * No permissions are needed in your manifest.
     * @author paul.blundell
     */
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_audio_book_list);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//		onMusicServiceBindStart();
		flg_rowItem = false;
		System.out.println("PLAYLIST DETAILS");
		
		context = this;
		
		mProgress = (ProgressBar) findViewById(android.R.id.progress);
        if (mProgress instanceof SeekBar) {
            SeekBar seeker = (SeekBar) mProgress;
            seeker.setOnSeekBarChangeListener(mSeekListener);
        }
        mProgress.setMax(Constant.PROGRESS_MAX_VALUE);
        
       
        lst_playlist = (ListView) findViewById(R.id.lst_audio_book);
//		mSongAdapter = new SongAdapter();
//		lst_playlist.setAdapter(mSongAdapter);
        
        if(getIntent().getAction().trim().equals(Constant.ACTIONS_FROM_NOTIFICATION)){
			

			System.out.println("ACTIVTITY NOTI - "+Constant.ACTIONS_FROM_NOTIFICATION);
			
			
			if(getIntent().getAction().trim().equals(Constant.ACTIONS_FROM_NOTIFICATION)){
				

				System.out.println("ACTIVTITY NOTI - "+Constant.ACTIONS_FROM_NOTIFICATION);
				
				
				if(MusicPlayerService.getMusicPlayerService()==null){
					 getApplicationContext().stopService(new Intent(getApplicationContext(),MusicPlayerService.class));
					 
					 Intent mIntent_Service = new Intent(getApplicationContext(),MusicPlayerService.class);
					 mIntent_Service.setAction(Constant.ACTIONS_FROM_ACTIVITY);
					 getApplicationContext().startService(mIntent_Service);
				}
				onMusicServiceBindStart(false);
				if (mMusicPlayerService == null){
					Log.d(Constant.TAG, "MusicPlayerService object NULL");
					return;
				}
				ChangeText(mMusicPlayerService.getAudioFilePos());
				
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					
				} else {
					
					AudioFilePos=getIntent().getExtras().getInt(Constant.KEY_AUDIO_FILE_POS, Constant.INVALID_POSTION);
					selected_pos = AudioFilePos;
					flg_rowItem = true;
					
					System.out.println("AUDIO POS : "+AudioFilePos);
				//	ChangeText(AudioFilePos);
					
					//new startMusicService().execute("");
					
				//	startMusicService mstartMusicService = new startMusicService();
				//	mstartMusicService.execute("");
//					onMusicServiceBindStart(true);
					galaryID = getIntent().getStringExtra("GalaryID");
					if (mCommClass.CheckNetwork(getApplicationContext()) == true) {
						audioBookList = new LoadingAudioBookListTask(Constant.ACTIONS_FROM_NOTIFICATION);
					  	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
								audioBookList.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.format(Constant.audioBookListURL, galaryID));
//								System.out.println("sdk version in if = " + Build.VERSION.SDK_INT);
							} else {
								audioBookList.execute(String.format(Constant.audioBookListURL, galaryID));
//								System.out.println("sdk version in else = " + Build.VERSION.SDK_INT);
							}
					} else {
						showError("Satsang", "Please check internet connection");
					}
				}
			}
        }
			else if(getIntent().getAction().trim().equals(Constant.ACTIONS_FROM_ACTIVITY)){
				

				System.out.println("ACTIVTITY ACT - "+Constant.ACTIONS_FROM_ACTIVITY);
							
				AudioFilePos=getIntent().getExtras().getInt(Constant.KEY_AUDIO_FILE_POS, Constant.INVALID_POSTION);
//				selected_pos = AudioFilePos;
//				flg_rowItem = true;
				System.out.println("AUDIO POS : "+AudioFilePos);
			//	ChangeText(AudioFilePos);
				
				//new startMusicService().execute("");
				
			//	startMusicService mstartMusicService = new startMusicService();
			//	mstartMusicService.execute("");
//				onMusicServiceBindStart(true);
				galaryID = getIntent().getStringExtra("GalaryID");
				if (mCommClass.CheckNetwork(getApplicationContext()) == true) {
					audioBookList = new LoadingAudioBookListTask(Constant.ACTIONS_FROM_ACTIVITY);
				  	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
							audioBookList.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.format(Constant.audioBookListURL, galaryID));
//							System.out.println("sdk version in if = " + Build.VERSION.SDK_INT);
						} else {
							audioBookList.execute(String.format(Constant.audioBookListURL, galaryID));
//							System.out.println("sdk version in else = " + Build.VERSION.SDK_INT);
						}
				} else {
					showError("Satsang", "Please check internet connection");
				}
				
		
			}
			
        
        
		
		
	/*	
		Button logout = (Button) findViewById(R.id.logout);
		
		if(UserID.equals("")) logout.setVisibility(View.GONE);
		
		logout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				SharedPreferences mSharedPreferencesWrite = getSharedPreferences(Constant.SHARED_PREFERENCES.SHARED_PREF_LOGIN, MODE_WORLD_WRITEABLE);
				
				SharedPreferences.Editor mSharedPreferencesEdit = mSharedPreferencesWrite.edit();
				mSharedPreferencesEdit.putString(Constant.SHARED_PREFERENCES.SIGNIN.KEY_LOGIN, "");
				mSharedPreferencesEdit.putString(Constant.SHARED_PREFERENCES.SIGNIN.KEY_USERID, "");
				mSharedPreferencesEdit.putString(Constant.SHARED_PREFERENCES.SIGNIN.KEY_FIRST_NAME, "");
				mSharedPreferencesEdit.putString(Constant.SHARED_PREFERENCES.SIGNIN.KEY_LAST_NAME, "");
				mSharedPreferencesEdit.putString(Constant.SHARED_PREFERENCES.SIGNIN.KEY_EMAIL, "");
				mSharedPreferencesEdit.commit();
				
				Toast.makeText(Playlist_Detail.this, Constant.SIGNIN.LOGOUT_MSG, Toast.LENGTH_LONG).show();
				
				Intent i = new Intent(Playlist_Detail.this, Home.class);
				startActivity(i);
				finish();
								
				
			}
		});*/
		
		btnBack=(ImageButton)findViewById(R.id.btn_back_in_audio_book);
		btnPrevious=(ImageButton)findViewById(R.id.btn_previous_in_mediacontroller);
		btnNext=(ImageButton)findViewById(R.id.btn_next_in_mediacontroller);
		btnStop=(ImageButton)findViewById(R.id.btn_stop_in_mediacontroller);
		btnPlay_Pause=(ImageButton)findViewById(R.id.btn_play_pause_in_mediacontroller);
		
		btnPrevious.setOnClickListener(mPreviousListener);
		btnNext.setOnClickListener(mNextListener);
		btnStop.setOnClickListener(mStopListener);
		btnPlay_Pause.setOnClickListener(mPauseListener);
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		
		txtcurrentduration=(TextView)findViewById(R.id.tv_playing_time_in_audio_book);
//		txtcurrent_songposition=(TextView)findViewById(R.id.txtcurrent_songposition);
		txttotalduration=(TextView)findViewById(R.id.tv_total_time_in_audio_book);
		
		/*txt_aartiscreentitle.setTypeface(CommonClass.setFont(getApplicationContext(), Constant.GUJARATI_FONT1));
		txt_aarti_description.setTypeface(CommonClass.setFont(getApplicationContext(), Constant.GUJARATI_FONT1));
		*/
	
	}
	
	/*
	*//*********************************************** Get webservice of Playlist *******************************************************************/
	private class startMusicService extends AsyncTask<String, String, Boolean> 
	{
		private ProgressDialog mProgressDialog=null;
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(Playlist_Detail.this);
			mProgressDialog.setMessage("LOADING DATA");
		
			mProgressDialog.show();
		}

		@Override
		protected Boolean doInBackground(String... params) {
			
			/********************************************To Provide the PARAMETERS TO WEB SERVICE*********************************************/
			        	return onMusicServiceBindStart(true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			if(mProgressDialog!=null)
			{
				if(mProgressDialog.isShowing()) mProgressDialog.dismiss();
			}
			super.onPostExecute(result);
		}
	}
	
	
	/*
	private void GotoBack(){
		Intent mIntent=new Intent(this,Aarti_List.class);
		startActivity(mIntent);
		finish();
		this.overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			GotoBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}*/
	
	private void ChangeText(int position){
		try {
			mMusicPlayerService.setNotification();
			//System.out.println("POSITION : "+position +"Playlist SONG- "+Playlist_Favourites.SONGS_TITLE.get(position));
//			System.out.println("POSITION : "+position +"Playlist SONG- "+trimName(rowItem.get(position).getGalleryImagesName()));
//			System.out.println("POSITION : "+position +"Playlist SONG- "+rowItem.get(position).getGalleryImagesName());
			
			songTitle = trimName(rowItem.get(position).getGalleryImagesName());
			
			//txt_aartiscreentitle.setText(Constant.SONG_TITLE.get(position));
			
			//txt_aartiscreentitle.setText(Playlist_Favourites.SONGS_TITLE.get(position));
			//txt_aarti_description.setText(CommonClass.getString(getResources().getAssets().open(Constant.AARTI_TEXT_FILE[position])));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private View.OnClickListener mPreviousListener = new View.OnClickListener() {
        public void onClick(View v) {
        	if(!(mMusicPlayerService.index <= 0)) mMusicPlayerService.index = mMusicPlayerService.index - 1;
        	boolean isMusic = pre();
        	if(isMusic){
        		mMusicPlayerService.pauseScreen = false;
            	mMusicPlayerService.stopScreen = false;            
            	mMusicPlayerService.setNotification();
        	}
        }
    };
    
    
    static boolean pre(){
    	if (mMusicPlayerService == null){
			Log.d(Constant.TAG, "MusicPlayerService object NULL");
			return false;
		}
        try {
        	  mMusicPlayerService.Previous();
        	  setPausePlayButtonImage();
        	  return true;
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return false;
    }
    
    private View.OnClickListener mNextListener = new View.OnClickListener() {
        public void onClick(View v) {
        	if(!(mMusicPlayerService.index >= rowItem1.size() - 1)) mMusicPlayerService.index = mMusicPlayerService.index + 1;
        	boolean isMusic = next();
        	if(isMusic){
            	mMusicPlayerService.pauseScreen = false;
            	mMusicPlayerService.stopScreen = false;     
            	mMusicPlayerService.setNotification();
        	}
        }
    };
    
    
    static boolean next(){
    	if (mMusicPlayerService == null){
			Log.d(Constant.TAG, "MusicPlayerService object NULL");
			return false;
		}
        try {
        	mMusicPlayerService.Next();
        	setPausePlayButtonImage();
        	return true;
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return false;
    }
    
    private View.OnClickListener mPauseListener = new View.OnClickListener() {
        public void onClick(View v) {
        	System.out.println("FIRST TIME : "+firstTime);
        	        	
        	if(firstTime){
        		
        		if(rowItem == null){
        			
        			rowItem = new ArrayList<AudioBookListRow>();
        			rowItem = rowItem1;
        			flg_rowItem = true;
        			playing_galary_ID = galaryID;
//        			selected_pos = 0;
        		}

            	System.out.println("SIZE : "+rowItem.size()+"   "+rowItem1.size());
        		
        		onMusicServiceBindStart(true);
        		
        		
            	
        	}
        	else{
        		doPauseResume();
        	}
        }
    };
    
    static void doPauseResume() {
        try {
	        	if (mMusicPlayerService == null){
					Log.d(Constant.TAG, "MusicPlayerService object NULL");
					return;
				}
	        	
	        	mMusicPlayerService.stopScreen = false;
	        	
	            if (mMusicPlayerService.isPlaying()) {
	            	mMusicPlayerService.pause(true);
	            	
	            						
					mMusicPlayerService.pauseScreen = true;
					
	            } else {
	            	((Activity) context).runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							mMusicPlayerService.play();	
							mMusicPlayerService.pauseScreen = false;
						}
					});
	            }
	            mMusicPlayerService.setNotification();
	            refreshNow();
	            setPausePlayButtonImage();
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }
    static void setPausePlayButtonImage() {
        try {
	            if (mMusicPlayerService != null && mMusicPlayerService.isPlaying()) {
	//            	  btnPlay_Pause.setText("Pause");
	            	  btnPlay_Pause.setImageResource(R.drawable.ic_pause);
	            } else {
	//            	  btnPlay_Pause.setText("Play");
	            	  btnPlay_Pause.setImageResource(R.drawable.ic_play);
	            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }
    
    private View.OnClickListener mStopListener = new View.OnClickListener() {
        public void onClick(View v) {
        	doStop();
        	mMusicPlayerService.pauseScreen = true;
        	mMusicPlayerService.stopScreen = true;
        	if(MusicPlayerService.notiCancelOnStop == true) {
            	mMusicPlayerService.stopNotification();
            	System.out.println("after stopnotification");
        	}
        }
    };
    static void doStop() {
        try {
	        	if (mMusicPlayerService == null){
					Log.d(Constant.TAG, "MusicPlayerService object NULL");
					return;
				}
	            if (mMusicPlayerService.isPlaying()) {
	            	mMusicPlayerService.pause(true);
	            	mMusicPlayerService.seek(0);
	            }
	            
	            MusicPlayerService.flag = false;
	            
	            refreshNow();
	            setPausePlayButtonImage();
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }
	
    @Override
    public void onResume() {
        super.onResume();
        setPausePlayButtonImage();
       
    }
    
    @Override
    public void onStop() {
        paused = true;
        mHandler.removeMessages(REFRESH);
        super.onStop();
    }

    @Override
    public void onStart() {
        super.onStart();
        paused = false;
        long next = refreshNow();
        queueNextRefresh(next);
    }
	
	 private static final int REFRESH = 1;
	 private void queueNextRefresh(long delay) {
		 System.out.println("in queueNextRefresh ()");
	        if (!paused) {
	            Message msg = mHandler.obtainMessage(REFRESH);
	            mHandler.removeMessages(REFRESH);
	            mHandler.sendMessageDelayed(msg, delay);
	        }
	  }

	  static long refreshNow() {
	        if(mMusicPlayerService == null){
	            return Constant.PROGRESS_REFRESH_RATE;
	        }
	        try {
		            long pos = mPosOverride < 0 ? mMusicPlayerService.position() : mPosOverride;
		            long remaining = Constant.PROGRESS_MAX_VALUE - (pos % Constant.PROGRESS_MAX_VALUE);
		            if ((pos >= 0) && (mMusicPlayerService.duration() > 0)) {
		            	txttotalduration.setText(Constant.makeTimeString(context, mMusicPlayerService.duration()/Constant.PROGRESS_MAX_VALUE));
		            	txtcurrentduration.setText(Constant.makeTimeString(context, pos / Constant.PROGRESS_MAX_VALUE));
		                
		                if (mMusicPlayerService.isPlaying()) {
		                	txtcurrentduration.setVisibility(View.VISIBLE);
		                	txttotalduration.setVisibility(View.VISIBLE);
		                } else {
		                    // blink the counter
		                    int vis = txtcurrentduration.getVisibility();
		                    txtcurrentduration.setVisibility(vis == View.INVISIBLE ? View.VISIBLE : View.INVISIBLE);
		                    
		                    int vis_total = txttotalduration.getVisibility();
		                    txttotalduration.setVisibility(vis_total == View.INVISIBLE ? View.VISIBLE : View.INVISIBLE);
		                    
		                    remaining = Constant.PROGRESS_REFRESH_RATE;
		                }
	
		                mProgress.setProgress((int) (Constant.PROGRESS_MAX_VALUE * pos / mMusicPlayerService.duration()));
		            } else {
		            	txtcurrentduration.setText("--:--");
		            	txttotalduration.setText("--:--");
		                mProgress.setProgress(Constant.PROGRESS_MAX_VALUE);
		            }
		            // return the number of milliseconds until the next full second, so
		            // the counter can be updated at just the right time
		            //txtcurrent_songposition.setText((mMusicPlayerService.getAudioFilePos()+1)+"/"+Playlist_Favourites.SONGS.size());
		         //   txtcurrent_songposition.setText((mMusicPlayerService.getAudioFilePos()+1)+"/"+rowItem1.size());
		            return remaining;
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
	        return Constant.PROGRESS_REFRESH_RATE;
	    }
	    
	    private final Handler mHandler = new Handler() {
	        @Override
	        public void handleMessage(Message msg) {
	            switch (msg.what) {
	                case REFRESH:
	                    long next = refreshNow();
	                    queueNextRefresh(next);
	                    break;	   
	                default:
	                    break;
	            }
	        }
	    };
	    
	    private OnSeekBarChangeListener mSeekListener = new OnSeekBarChangeListener() {
	        public void onStartTrackingTouch(SeekBar bar) {
	            mLastSeekEventTime = 0;
	            mFromTouch = true;
	        }
	        public void onProgressChanged(SeekBar bar, int progress, boolean fromuser) {
	            if (!fromuser || (mMusicPlayerService == null)){
					return;
				}
	            long now = SystemClock.elapsedRealtime();
	            if ((now - mLastSeekEventTime) > 250) {
	                mLastSeekEventTime = now;
	                mPosOverride = mMusicPlayerService.duration() * progress / 1000;
	                try {
	                	mMusicPlayerService.seek(mPosOverride);
	                } catch (Exception e) {
	                	e.printStackTrace();
	                }

	                // trackball event, allow progress updates
	                if (!mFromTouch) {
	                    refreshNow();
	                    mPosOverride = -1;
	                }
	            }
	        }
	        public void onStopTrackingTouch(SeekBar bar) {
	            mPosOverride = -1;
	            mFromTouch = false;

	            System.out.println("FINISH......."+mMusicPlayerService.index);
	            mMusicPlayerService.index = mMusicPlayerService.index + 1;
	            mMusicPlayerService.setNotification();
	        }
	    };
	
	@Override
	public void getPlayingSongIndex(int index) {
		if (mMusicPlayerService == null){
			Log.d(Constant.TAG, "MusicPlayerService object NULL");
			
			return;
		}
//		if (mBound) {
			ChangeText(index);
			
			
//			Toast.makeText(this, "Data getPlayingSongIndex = "+index, Toast.LENGTH_SHORT).show();
//		}
	}
	
//	private MusicPlayerService mMusicPlayerService = null;
//	private boolean	mBound = false;
//    private void onMusicServiceBindStart() {
//        if(CommonClass.IsServiceRunning(getApplicationContext(),Constant.MUSICPLAYER_SERVICE)){
//        	Log.d(Constant.TAG, "MusicPlayerService Running");
//            // Bind to LocalService
//            Intent intent = new Intent(getApplicationContext(), MusicPlayerService.class);
//            getApplicationContext().bindService(intent, mConnection, Context.BIND_ADJUST_WITH_ACTIVITY);
//        }
//        else{
//        	Log.d(Constant.TAG, "MusicPlayerService Not Running");
//        }
//    }
//	
//    private void onMusicServiceBindStop() {
//            // Unbind from the service
//            if (mBound) {
//            	if(mMusicPlayerService!=null && mConnection!=null){
//            		getApplicationContext().unbindService(mConnection);
//            	}
//                mBound = false;
//            }
//    }
//    
//    /** Defines callbacks for service binding, passed to bindService() */
//    private ServiceConnection mConnection = new ServiceConnection() 
//    {
//        @Override
//        public void onServiceConnected(ComponentName className,IBinder service) {
//        	Log.d(Constant.TAG, "onServiceConnected");
//            // We've bound to LocalService, cast the IBinder and get LocalService instance
//            LocalBinder binder = (LocalBinder) service;
//            mMusicPlayerService = binder.getService();
//            mMusicPlayerService.setMusicPlayer_Listener(Aarti_Detail.this);
//            if(AudioFilePos != mMusicPlayerService.getAudioFilePos()){
//                mMusicPlayerService.setAudioFilePos(AudioFilePos);
//            }
//            setPausePlayButtonImage();
//            mBound = true;
//        }
//        @Override
//        public void onServiceDisconnected(ComponentName arg0) 
//        {
//        	Log.d(Constant.TAG, "onServiceDisconnected");
//            mBound = false;
//        }
//    };
//    
//	@Override
//	protected void onDestroy(){
//		getApplicationContext().stopService(new Intent(getApplicationContext(),MusicPlayerService.class));
//		mMusicPlayerService = null;
//		super.onDestroy();
//	}
	
  static MusicPlayerService mMusicPlayerService = null;
//  private boolean mBound = false;
  private Boolean onMusicServiceBindStart(boolean fromactivity) {
  		mMusicPlayerService=MusicPlayerService.getMusicPlayerService();
  		if(mMusicPlayerService!=null){
	          mMusicPlayerService.setMusicPlayer_Listener(Playlist_Detail.this);
	          if(fromactivity){
		         // if(AudioFilePos != mMusicPlayerService.getAudioFilePos()){
		        	  
		        	  System.out.println("AUDIO FILE POS: "+AudioFilePos);
		        	  
		              mMusicPlayerService.setAudioFilePos(AudioFilePos);
		        //  }
	          }
	          setPausePlayButtonImage();
	          return true;     
  		}else{
  			
  			System.out.println("Music Player is NULL ");
  			return false;
  			
  		}
		
  }
  
  
  
  /************************************ SONG ADAPTER ************************************************/
  
//  class SongAdapter extends BaseAdapter{
//
//		private LayoutInflater minflater = null;
//		
//		
//		public SongAdapter() {
//			minflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
//			
//		}
//		
//		@Override
//		public int getCount() {
//			// TODO Auto-generated method stub
//			return Constant.SONG.size();
//		}
//
//		@Override
//		public Object getItem(int position) {
//			// TODO Auto-generated method stub
//			return position;
//		}
//
//		@Override
//		public long getItemId(int position) {
//			// TODO Auto-generated method stub
//			return position;
//		}
//
//		@Override
//		public View getView(final int position, View convertView, ViewGroup parent) {
//			// TODO Auto-generated method stub
//			View view = minflater.inflate(R.layout.songlist, null);
//			
//			TextView title = (TextView) view.findViewById(R.id.title);
//			title.setText(Constant.SONG_TITLE.get(position));
//			
//			return view;
//		}
//	}

  
	LoadingAudioBookListTask audioBookList = null;
	private ProgressDialog mProgressDialog = null;
	public class LoadingAudioBookListTask extends AsyncTask<String, String, String> {
		private String action = null;
		LoadingAudioBookListTask(String action){
			this.action = action;
		}
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(Playlist_Detail.this);
			mProgressDialog.setMessage(Constant.msgLoading);
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.show();
		}

		@Override
		protected String doInBackground(String... url) {
			JSONParser jParser = new JSONParser();
			String json = jParser.getJSONFromUrl(url[0]);
			return json;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			
			if (result != null) {
				setListData(result);
				
			} else {
				Toast.makeText(Playlist_Detail.this, "no data found",
						Toast.LENGTH_LONG).show();
			}
		}
		
		private void setListData(String data) {
			rowItem1 = null;
			rowItem1 = new ArrayList<AudioBookListRow>();
			try {
				JSONArray mainDataArray = new JSONArray(data);
				System.out.println("main size = " + mainDataArray.length());
				if(mainDataArray.length() == 0){
					showError("Satsang", "No data found");
				} else {
					for (int i = 0; i < mainDataArray.length(); i++) {
						JSONObject audioBookList = mainDataArray.getJSONObject(i);
						String gallery_images_id = audioBookList.get("gallery_images_id").toString();
						String gallery_id = audioBookList.get("gallery_id").toString();
						String gallery_image_title = audioBookList.get("gallery_image_title").toString();
						String gallery_images_name = Constant.defaultSongPth + audioBookList.get("gallery_images_name").toString().replace(" ", "%20");
						String gallery_language = audioBookList.getString("gallery_language");
						String download = audioBookList.getString("download");

//						rowItem.add(new AudioBookListRow(gallery_images_id, gallery_id, gallery_image_title, gallery_images_name, gallery_language, download));
						rowItem1.add(new AudioBookListRow(gallery_images_id, gallery_id, gallery_image_title, gallery_images_name, gallery_language, download));
						System.out.println("path = " + gallery_images_name);
					}
					adapter = new SongAdapter(Playlist_Detail.this);
				}
				System.out.println("size = " + rowItem1.size());
				if(rowItem1.size() > 0) {
					if(action.equalsIgnoreCase(Constant.ACTIONS_FROM_NOTIFICATION)){
						songTitle = trimName(rowItem1.get(selected_pos).getGalleryImagesName());
						lst_playlist.setAdapter(adapter);
					} else if(action.equalsIgnoreCase(Constant.ACTIONS_FROM_ACTIVITY)){
						
						songTitle = trimName(rowItem1.get(0).getGalleryImagesName());
						lst_playlist.setAdapter(adapter);
					}

				} else {
					selected_pos = -1;
					AudioFilePos = -1;
					flg_rowItem = false;
				}
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
//					llMain.setEnabled(true);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	
	public static SongAdapter adapter = null;
	public class SongAdapter extends BaseAdapter {

		private Context context;
		private LinearLayout llRow;
		private ImageButton btnDownload;
		private TextView tvName;
		private View rowView;

		public SongAdapter(Context c) {
			this.context = c;
		}

		@Override
		public int getCount() { 
			return rowItem1.size();
		}

		@Override
		public AudioBookListRow getItem(int position) {
			return rowItem1.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			try {

				LayoutInflater inflater = (LayoutInflater) context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				rowView			= inflater.inflate(R.layout.audio_book_list_row, parent, false);
				llRow			= (LinearLayout) rowView.findViewById(R.id.ll_parent_in_audio_book_list_row);
				tvName			= (TextView) rowView.findViewById(R.id.tv_audio_book_text);
				btnDownload		= (ImageButton) rowView.findViewById(R.id.btn_download_in_audio_book);
				if(flg_rowItem == true){
					if (position == selected_pos) {
						llRow.setBackgroundResource(R.color.white);
						tvName.setTextColor(getResources().getColor(R.color.black));
					}else{
						llRow.setBackgroundResource(R.drawable.slide_bg);
						tvName.setTextColor(getResources().getColor(R.color.white));
					}
				}

				tvName.setText(trimName(rowItem1.get(position)
						.getGalleryImagesName()));
			} catch (Exception e) {
				e.printStackTrace();
			}

			rowView.setOnClickListener(new OnClickListener() {
				@SuppressLint("CommitPrefEdits")
				@Override
				public void onClick(View v) {
//					currentsong = position;
					rowItem = null;
					rowItem = new ArrayList<AudioBookListRow>();
					rowItem = rowItem1;
					flg_rowItem = true;
					selected_pos = position;
					firstTime = false;
					AudioFilePos = position;
					mMusicPlayerService.index = position;

					onMusicServiceBindStart(true);
        			playing_galary_ID = galaryID;

				}
			});

			 btnDownload.setOnClickListener(new OnClickListener() {
				 @Override
				 public void onClick(View v) {
					 if(mCommClass.CheckNetwork(getApplicationContext()) == true){
						 if(mCommClass.MemoryCardCheck(getApplicationContext()) == true){
								String path = rowItem1.get(position).getGalleryImagesName();
								fileName = trimName(rowItem1.get(position).getGalleryImagesName());
								DownloadURL download = new DownloadURL();
								download.execute(path);
						 } else {
							 Toast.makeText(getApplicationContext(), "Memory card is not available", Toast.LENGTH_LONG).show();
						 }
					 } else {
						 Toast.makeText(getApplicationContext(), "Network not available", Toast.LENGTH_LONG).show();
					 }
			 	}
			 });
			return rowView;
		}
	}

	public String trimName(String str) {
		String temp = str.substring(str.lastIndexOf("/") + 1, str.length()); 
		return temp.replace("%20", " ");
	}

	public class DownloadURL extends AsyncTask<String, String, String> {

		private ProgressDialog mProgressDialog = null;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(Playlist_Detail.this);
			mProgressDialog.setMessage(Constant.msgDownload);
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.show();
		}

		@Override
		protected String doInBackground(String... url) {
			String msg = mp3load(url[0]);
			return msg;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (mProgressDialog != null) {
				mProgressDialog.dismiss();
			}
			Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
		}

	}

	public String mp3load(String url_path) {
		try {
			URL url = new URL(url_path.replace(" ", "%20"));
			System.out.println("download path = " + url);
			HttpURLConnection c = (HttpURLConnection) url.openConnection();
			c.setRequestMethod("GET");
			c.setDoOutput(true);
			c.connect();

			String PATH = Environment.getExternalStorageDirectory() + "/download/";
			System.out.println("sdcard path = " + PATH);
			File file = new File(PATH);
			if (!file.exists()) {
				file.mkdirs();
			}
			File outputFile = new File(file, fileName);
			if(outputFile.exists()){
				return fileName + " is already downloaded";
			} else {
				FileOutputStream fos = new FileOutputStream(outputFile);
				InputStream is = c.getInputStream();
				byte[] buffer = new byte[1024];
				int len1 = 0;
				while ((len1 = is.read(buffer)) != -1) {
					fos.write(buffer, 0, len1);
				}
				fos.flush();
				fos.close();
				is.close();
				return "Downloading successfully completed";
			}
		} catch (IOException e) {
			return "Downloading failed";
		}
	}
	
	public void showError(String title, String msg){
		
		AlertDialog.Builder b = new Builder(Playlist_Detail.this);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					finish();
			}
		});
		AlertDialog d = b.create();
		d.show();
	}

	@Override
	  public void onWindowFocusChanged(boolean hasFocus)
	  {
	      try
	      {
	    	  System.out.println("Focus : "+hasFocus);
	    	  
	          if(hasFocus)
	          {
	        	  System.out.println("Focus Service : "+mMusicPlayerService.getMusicPlayerService());
	        	  if(mMusicPlayerService.getMusicPlayerService() == null){
	        		  ((Activity) context).finish();
	        	  }
	          }
	      }
	      catch(Exception ex)
	      {          
	          ex.printStackTrace();          
	      }
	  }

}