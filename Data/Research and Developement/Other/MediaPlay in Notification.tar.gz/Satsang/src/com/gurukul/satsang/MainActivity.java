package com.gurukul.satsang;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.ovte.slidemenu.widget.AnimationLayout;

public class MainActivity extends Activity implements AnimationLayout.Listener {

	private ImageButton btnShastra;
	private ImageButton btnAudio;
	private ImageButton btnVideo;
	private ImageButton btnContact;
	
    protected AnimationLayout mLayout;
    public final static String TAG = "Demo";

    private ArrayList<String> parentItems = new ArrayList<String>();
	public static ArrayList<Object> childItems = new ArrayList<Object>();
	public static ArrayList<Object> childItemName = new ArrayList<Object>();

	public static ExpandableListView expandbleLis;
	public static ExpandableListAdapter mNewAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		initialize();
		
		btnShastra.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, ShastraCategoryList.class));
			}
		});
		
		btnAudio.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, AudioActivity.class));
			}
		});
		
		btnVideo.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent().setClass(MainActivity.this, VideoCategoryActivity.class));
			}
		});

		setAddressList();
		
        mLayout = (AnimationLayout) findViewById(R.id.animation_layout);
        mLayout.setListener(this);

	}
	
	public void initialize(){
		btnShastra		=	(ImageButton) findViewById(R.id.btn_shastra);
		btnAudio		=	(ImageButton) findViewById(R.id.btn_audio);
		btnVideo		=	(ImageButton) findViewById(R.id.btn_video);
		btnContact		=	(ImageButton) findViewById(R.id.btn_contact);
		expandbleLis	=	(ExpandableListView) findViewById(R.id.exp_slide_items);
		
	}

    public void onClickContentButton(View v) {
        mLayout.toggleSidebar();
    }

    @Override
    public void onBackPressed() {
        if (mLayout.isOpening()) {
            mLayout.closeSidebar();
        } else {
            finish();
        }
    }

    /* Callback of ExpandAnimationLayout.Listener to monitor status of Sidebar */
    @Override
    public void onSidebarOpened() {
        Log.d(TAG, "opened");
        btnAudio.setVisibility(View.INVISIBLE);
        btnContact.setImageResource(R.drawable.ic_contact_slid_in);
    }

    /* Callback of ExpandAnimationLayout.Listener to monitor status of Sidebar */
    @Override
    public void onSidebarClosed() {
        Log.d(TAG, "close");
        btnAudio.setVisibility(View.VISIBLE);
        btnContact.setImageResource(R.drawable.ic_contact);
    }

    /* Callback of ExpandAnimationLayout.Listener to monitor status of Sidebar */
    @Override
    public boolean onContentTouchedWhenOpening() {
        // the content area is touched when sidebar opening, close sidebar
        Log.d(TAG, "going to close sidebar");
        mLayout.closeSidebar();
        return true;
    }
    
    @SuppressLint("NewApi")
	public void setAddressList(){
    	try{
    		String data = loadJSONFromAsset();
			JSONArray mainDataArray = new JSONArray(data);
			for (int i = 0; i < mainDataArray.length(); i++) {
				JSONObject vacancyData = mainDataArray.getJSONObject(i);
				JSONObject obj = vacancyData.getJSONObject("address");
				
				String id = obj.get("address_id").toString();
				System.out.println("address id = " + id);
				
				String title = obj.getString("title");
				parentItems.add(title);
				
				String address = obj.get("gurukul_address").toString();
				String city = obj.get("city").toString();
				String pincode = obj.get("pincode").toString();
				String state = obj.get("state").toString();
				String temp = obj.get("contact_no").toString();
				String contactNo = temp.replace(", ", "" + Html.fromHtml("<br/>"));

				System.out.println("contactNo = " + contactNo);

				ArrayList<String> child = new ArrayList<String>();
				child.add(address);
				child.add(city);
				child.add(pincode);
				child.add(state);
				child.add(contactNo);
				childItems.add(child);
				
				ArrayList<String> childHeader = new ArrayList<String>();
				childHeader.add("Address :");
				childHeader.add("City :");
				childHeader.add("Pincode :");
				childHeader.add("State :");
				childHeader.add("Contact No. :");
				childItemName.add(childHeader);
			}

		mNewAdapter = new ExpandableListAdapter(this);
		expandbleLis.setAdapter(mNewAdapter);

	} catch (JSONException e) {

		e.printStackTrace();
	} catch (Exception e1){
		e1.printStackTrace();
	}
    }
    
    public class ExpandableListAdapter extends BaseExpandableListAdapter {

    	private Context _context;
    	private ArrayList<String> tempChild, tempChildName;
    	
    	public ExpandableListAdapter(Context context) {
    		this._context = context;
    	}

    	@Override
    	public Object getChild(int groupPosition, int childPosititon) {
    		return null;
    	}

    	@Override
    	public long getChildId(int groupPosition, int childPosition) {
    		return childPosition;
    	}

    	@SuppressLint("NewApi")
		@SuppressWarnings("unchecked")
    	@Override
    	public View getChildView(int groupPosition, int childPosition,
    			boolean isLastChild, View convertView, ViewGroup parent) {

    		try {
    			tempChildName = (ArrayList<String>) childItemName.get(groupPosition);
    			tempChild = (ArrayList<String>) childItems.get(groupPosition);

    			TextView text1 = null;
    			TextView text2 = null;

    			if (convertView == null) {
    				LayoutInflater infalInflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    				convertView = infalInflater.inflate(R.layout.child_view, null);
    			}

    			text1 = (TextView) convertView.findViewById(R.id.txtSubType);
    			text1.setText(tempChildName.get(childPosition));

    			text2 = (TextView) convertView.findViewById(R.id.txtData);
    			if(text1.getText().toString().equalsIgnoreCase("Contact No. :")){
    				text2.setAutoLinkMask(Linkify.PHONE_NUMBERS);
//    				text2.setTextIsSelectable(true);
    			}
    			text2.setText(tempChild.get(childPosition));
    		}catch (Exception e){
    			e.printStackTrace();
    		}

    		return convertView;
    	}
    	
    	@SuppressWarnings("unchecked")
		@Override
    	public int getChildrenCount(int groupPosition) {
    		return ((ArrayList<String>) childItems.get(groupPosition)).size();
    	}

    	@Override
    	public Object getGroup(int groupPosition) {
    		return parentItems.get(groupPosition);
    	}

    	@Override
    	public int getGroupCount() {
    		return parentItems.size();
    	}

    	@Override
    	public long getGroupId(int groupPosition) {
    		return groupPosition;
    	}

    	@Override
    	public View getGroupView(final int groupPosition, boolean isExpanded,
    			View convertView, ViewGroup parent) {
    		try{
    			String headerTitle = (String) getGroup(groupPosition);
    			if (convertView == null) {
    				LayoutInflater infalInflater = (LayoutInflater) this._context
    						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    				convertView = infalInflater.inflate(R.layout.parent_view, null);
    			}
    			
    			if(isExpanded) {
    				convertView.setBackgroundResource(R.drawable.ic_parent_selected);
    			} else {
    				convertView.setBackgroundResource(R.drawable.slide_bg);
    			}
    			
    			TextView lblListHeader = (TextView) convertView
    					.findViewById(R.id.lblListHeader);
    			lblListHeader.setTypeface(null, Typeface.BOLD);
    			lblListHeader.setText(headerTitle);

    		}catch(Exception e){
    			e.printStackTrace();
    		}

    		return convertView;
    	}

    	@Override
    	public boolean hasStableIds() {
    		return false;
    	}

    	@Override
    	public boolean isChildSelectable(int groupPosition, int childPosition) {
    		return true;
    	}
    	
    	@Override
    	public void onGroupExpanded(int groupPosition) {
    		try {
    			int len = mNewAdapter.getGroupCount();
    		    
        	    for (int i = 0; i < len; i++) {
        	        if (i != groupPosition) {
        	        	expandbleLis.collapseGroup(i);
        	        }
        	    }
			} catch (Exception e) {
				// TODO: handle exception
			}
    		
    	}

    }
    
    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = getAssets().open("gurukul_addressbook.txt");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }
}