package com.gurukul.satsang;

import java.util.Formatter;
import java.util.Locale;

import android.content.Context;

public class Constant {
	public static String shastraCatListURL		= "http://www.media.gurukul.us/webservice/categories_data.php?classID=3";
	public static String shastraListURL			= "http://www.media.gurukul.us/webservice/get_data.php?gallery_id=";
	public static String audioBookCategoryURL	= "http://www.media.gurukul.us/webservice/categories_data.php?classID=%s&albumID=%s";
	public static String audioBookListURL		= "http://www.media.gurukul.us/webservice/get_data.php?gallery_id=%s";
	public static String kirtanListURL			= "http://www.media.gurukul.us/webservice/get_data.php?gallery_id=%s";
	public static String kathaListURL			= "http://www.media.gurukul.us/webservice/get_data.php?gallery_id=%s";
	public static String videoCatListURL		= "http://www.media.gurukul.us/webservice/categories_data.php?classID=%s";
	public static String videoTrackListURL		= "http://www.media.gurukul.us/webservice/get_data.php?gallery_id=%s";
	public static String kirtanCatListURL		= "http://www.media.gurukul.us/webservice/categories_data.php?classID=%s&albumID=%s";
	public static String kathaCatListURL		= "http://www.media.gurukul.us/webservice/categories_data.php?classID=%s&albumID=%s";
	public static String defaultSongPth			= "http://www.media.gurukul.us/images/bhajan/";
	public static String msgLoading				= "Loading...";
	public static String msgDownload			= "Downloading ...";
	
	public static final String INTENT_BASE_NAME = "se.slide.sgu.AudioPlayer";
    public static final String UPDATE_PLAYLIST = INTENT_BASE_NAME + ".PLAYLIST_UPDATED";
    public static final String QUEUE_TRACK = INTENT_BASE_NAME + ".QUEUE_TRACK";
    public static final String PAUSE_TRACK = INTENT_BASE_NAME + ".PAUSE_TRACK";
    public static final String PLAY_TRACK = INTENT_BASE_NAME + ".PLAY_TRACK";
    public static final String QUEUE_ALBUM = INTENT_BASE_NAME + ".QUEUE_ALBUM";
    public static final String PLAY_ALBUM = INTENT_BASE_NAME + ".PLAY_ALBUM";
    public static final String PLAY_PAUSE_TRACK = INTENT_BASE_NAME + ".PLAY_PAUSE_TRACK";
    public static final String HIDE_PLAYER = INTENT_BASE_NAME + ".HIDE_PLAYER";
    public static final String EVENT_PLAY_PAUSE = INTENT_BASE_NAME + ".EVENT_PLAY_PAUSE";
    
	public static final String TAG = "NOTI";
	public static final String SHARED_PREF_PLAYER = "Shared Preference";

//	public static final ArrayList<String> SONG_TITLE = new ArrayList<String>();
//	public static final ArrayList<String> SONG = new ArrayList<String>();
	
	public static final String ACTIONS_FROM_ACTIVITY = "ACTION_FROM_ACTIVITY";
	public static final String ACTIONS_FROM_NOTIFICATION = "ACTIONS_FROM_NOTIFICATION";
	
	public static final int INVALID_POSTION = -1;
	public static final String SP_SONG_POSITION = "song_position";
	
	public static final int NOTIFICATION_WIDTH=300;
	public static final int NOTIFICATION_HEIGHT=38;
	public static final int NOTIFICATION_TEXT_SIZE=22;
	public static final int NOTIFICATION_TEXT_Y_POS=25;
	
	public static final int PROGRESS_REFRESH_RATE=500;
	public static final int PROGRESS_MAX_VALUE=1000;
	
	public static final String KEY_AUDIO_FILE_POS="audio_file_pos";
	
	 /*  Try to use String.format() as little as possible, because it creates a
     *  new Formatter every time you call it, which is very inefficient.
     *  Reusing an existing Formatter more than tripled the speed of
     *  makeTimeString().
     *  This Formatter/StringBuilder are also used by makeAlbumSongsLabel()
     */
    private static StringBuilder sFormatBuilder = new StringBuilder();
    private static Formatter sFormatter = new Formatter(sFormatBuilder, Locale.getDefault());
    private static final Object[] sTimeArgs = new Object[5];
    public static String makeTimeString(Context context, long secs) {
        String durationformat = context.getString(
                secs < 3600 ? R.string.durationformatshort : R.string.durationformatlong);
        
        /* Provide multiple arguments so the format can be changed easily
         * by modifying the xml.
         */
        sFormatBuilder.setLength(0);

        final Object[] timeArgs = sTimeArgs;
        timeArgs[0] = secs / 3600;
        timeArgs[1] = secs / 60;
        timeArgs[2] = (secs / 60) % 60;
        timeArgs[3] = secs;
        timeArgs[4] = secs % 60;

        return sFormatter.format(durationformat, timeArgs).toString();
    }

}