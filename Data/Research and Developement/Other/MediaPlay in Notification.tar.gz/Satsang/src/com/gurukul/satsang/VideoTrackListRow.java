package com.gurukul.satsang;

public class VideoTrackListRow {

	public String galleryImagesID;
	public String galleryID;
	public String galleryImageTitle;
	public String galleryImagesName;
	public String galleryLanguage;
	public String download;

	public VideoTrackListRow(String galleryImagesID, String galleryID, String galleryImageTitle, String galleryImagesName, String galleryLanguage, String download) {
		this.galleryImagesID = galleryImagesID;
		this.galleryID = galleryID;
		this.galleryImageTitle = galleryImageTitle;
		this.galleryImagesName = galleryImagesName;
		this.galleryLanguage = galleryLanguage;
		this.download = download;
	}

	public String getGalleryImagesID() {
		return galleryImagesID;
	}

	public void setGalleryImagesID(String galleryImagesID) {
		this.galleryImagesID = galleryImagesID;
	}

	public String getGalleryID() {
		return galleryID;
	}

	public void setGalleryID(String galleryID) {
		this.galleryID = galleryID;
	}

	public String getGalleryImageTitle() {
		return galleryImageTitle;
	}

	public void setGalleryImageTitle(String galleryImageTitle) {
		this.galleryImageTitle = galleryImageTitle;
	}

	public String getGalleryImagesName() {
		return galleryImagesName;
	}

	public void setGalleryImagesName(String galleryImagesName) {
		this.galleryImagesName = galleryImagesName;
	}

	public String getGalleryLanguage() {
		return galleryLanguage;
	}

	public void setGalleryLanguage(String galleryLanguage) {
		this.galleryLanguage = galleryLanguage;
	}

	public String getDownload() {
		return download;
	}

	public void setDownload(String download) {
		this.download = download;
	}
}
