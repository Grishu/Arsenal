package com.gurukul.satsang;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class AudioBookCategory extends Activity {

	private ImageButton							btnBack;
	private ListView							lstAudioBook;
	private CustomList							adapter;
	private ArrayList<AudioBookCatListRow>		rowItem;
	private CommonClass							mCommClass;
	private int 								classID;
	private int									albumID;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_audio_book_category);
		
		initialize();
		
		if(mCommClass.CheckNetwork(getApplicationContext()) == true){
			audioBookCategory = new LoadingAudioBookCatTask();
		  	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					audioBookCategory.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.format(Constant.audioBookCategoryURL, classID, albumID));
				} else {
					audioBookCategory.execute(String.format(Constant.audioBookCategoryURL, classID, albumID));
				}
		} else {
			showError("Satsang", "Please check internet connection");
		}
		
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		
		
	}
	
	public void initialize(){
		btnBack			=	(ImageButton) findViewById(R.id.btn_back_in_audio_book_cat);
		lstAudioBook	=	(ListView) findViewById(R.id.lst_audio_book_cat);
		rowItem			=	new ArrayList<AudioBookCatListRow>();
		mCommClass		=	new CommonClass();
		classID			=	4;
		albumID			=	3;
	}
	
	LoadingAudioBookCatTask audioBookCategory = null;
	public class LoadingAudioBookCatTask extends AsyncTask<String, String, String> {

		private ProgressDialog mProgressDialog = null;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(AudioBookCategory.this);
			mProgressDialog.setMessage(Constant.msgLoading);
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.show();
		}
		
		@Override
		protected String doInBackground(String... url) {
			JSONParser jParser = new JSONParser();
			String json = jParser.getJSONFromUrl(url[0]);
			System.out.println("result data = " + json);
			return json;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (mProgressDialog != null) {
				mProgressDialog.dismiss();
			}
			if (result != null) {
				setListData(result);
			} else {
				Toast.makeText(AudioBookCategory.this, "no data found", Toast.LENGTH_LONG).show();
			}
		}
	}
	
	public void setListData(String data) {
		rowItem = null;
		rowItem = new ArrayList<AudioBookCatListRow>();
		try {
			JSONArray mainDataArray = new JSONArray(data);
			if(mainDataArray.length() == 0){
				showError("Satsang", "No data found");
			} else {
				for (int i = 0; i < mainDataArray.length(); i++) {
					JSONObject AudioBookList = mainDataArray.getJSONObject(i);
					
					String galleryID = AudioBookList.get("gallery_id").toString();
					String galleryName = AudioBookList.getString("gallery_name");
					
					rowItem.add(new AudioBookCatListRow(galleryID, galleryName));
				}
				
				adapter = new CustomList(getApplicationContext());
				lstAudioBook.setAdapter(adapter);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private class CustomList extends BaseAdapter {

		private Context context;
		private TextView tvName;
		private View rowView;
//		private ImageButton imgGod;
		private LinearLayout llListRow;
		
		public CustomList(Context c) {
			this.context = c;
		}
		
		@Override
		public int getCount() {
			return rowItem.size();
		}

		@Override
		public AudioBookCatListRow getItem(int position) {
			return rowItem.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			try {

				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				rowView = inflater.inflate(R.layout.katha_cat_list_row, parent, false);
//				llListRow = (LinearLayout) rowView.findViewById(R.id.ll_shastra_list_row);
				
				tvName		= (TextView) rowView.findViewById(R.id.tv_galary_name_in_katha_cat_list_row);
				
				tvName.setText(rowItem.get(position).getGalleryName());
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			rowView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent i = new Intent();
					i.setClass(AudioBookCategory.this,  Playlist_Detail.class);
					i.setAction(Constant.ACTIONS_FROM_ACTIVITY);
					i.putExtra(Constant.KEY_AUDIO_FILE_POS, 0);
					i.putExtra("GalaryID", rowItem.get(position).getGalleryID());
					startActivity(i);
					
				}
			});
//			btnPlay.setOnClickListener(new OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					Intent i = new Intent();
//					i.setClass(AudioBookCategory.this,  Playlist_Detail.class);
//					i.setAction(Constant.ACTIONS_FROM_ACTIVITY);
//					i.putExtra(Constant.KEY_AUDIO_FILE_POS, 0);
//					i.putExtra("GalaryID", rowItem.get(position).getGalleryID());
//					startActivity(i);
//				}
//			});

			return rowView;
		}
	}
	
	public void showError(String title, String msg){
		
		AlertDialog.Builder b = new Builder(AudioBookCategory.this);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					finish();
			}
		});
		AlertDialog d = b.create();
		d.show();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
  	  if(MusicPlayerService.getMusicPlayerService() == null){
  		finish();
  	  }
	}
}