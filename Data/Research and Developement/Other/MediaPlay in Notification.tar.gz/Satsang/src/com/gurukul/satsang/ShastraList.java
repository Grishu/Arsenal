package com.gurukul.satsang;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ShastraList extends Activity {

	private ImageButton							btnBack;
	private TextView							tvLanguage;
	private ListView							lstShastra;
	private CustomList							adapter;
	private ArrayList<ShastraListRow>			rowItem;
	private CommonClass							mCommClass;
	private String								galaryID;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_shastra_list);
		
		initialize();
		
		if(mCommClass.CheckNetwork(ShastraList.this) == true){
			shastraTask = new LoadingShastraTask();
		  	  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					shastraTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, Constant.shastraListURL + galaryID);
				} else {
					shastraTask.execute(Constant.shastraListURL + galaryID);
				}
			System.out.println("shastralist url = " + Constant.shastraListURL + galaryID);
		} else {
			showError("Satsang", "Please check internet connection");
		}
		
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}
	
	public void initialize(){
		btnBack			=	(ImageButton) findViewById(R.id.btn_back_in_shastra_list);
		tvLanguage		=	(TextView) findViewById(R.id.tv_language_in_shastra_list);
		lstShastra		=	(ListView) findViewById(R.id.lst_shastra);
		mCommClass		=	new CommonClass();
		galaryID		=	getIntent().getStringExtra("Gallery_ID");
		System.out.println("galary id in shastra List = " +galaryID);
	}
	
	LoadingShastraTask shastraTask = null;
	public class LoadingShastraTask extends AsyncTask<String, String, String> {

		private ProgressDialog mProgressDialog = null;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			try{
				if (mProgressDialog == null) {
					mProgressDialog = new ProgressDialog(ShastraList.this);
				}
				if (mProgressDialog != null) {
					// keyFlag=true;
					if (!mProgressDialog.isShowing()) {
						mProgressDialog.show();
						mProgressDialog.setMessage(Constant.msgLoading);
						mProgressDialog.setCanceledOnTouchOutside(false);
					}
				}
			} catch(Exception e){
				e.printStackTrace();
			}
		}
		
		@Override
		protected String doInBackground(String... url) {
			JSONParser jParser = new JSONParser();
			String json = jParser.getJSONFromUrl(url[0]);
			System.out.println("json in shatralist = " + json) ;
			return json;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if(mProgressDialog != null){
				if (mProgressDialog.isShowing()) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
			}
			if (result != null && result.length() != 0) {
				setListData(result);
			} else {
				Toast.makeText(ShastraList.this, "no data found", Toast.LENGTH_LONG).show();
			}
		}
	}
	
	public void setListData(String data) {
		rowItem = null;
		rowItem = new ArrayList<ShastraListRow>();
		try {
			JSONArray mainDataArray = new JSONArray(data);
			if(mainDataArray.length() == 0){
				showError("Satsang", "No data found");
			} else {
				String galleryLanguage = null;
				for (int i = 0; i < mainDataArray.length(); i++) {
					JSONObject shastraList = mainDataArray.getJSONObject(i);
					
					String galleryImagesID = shastraList.get("gallery_images_id").toString();
					String galleryID = shastraList.get("gallery_id").toString();
					String galleryImageTitle = shastraList.getString("gallery_image_title");
					String galleryImagesName = shastraList.getString("gallery_images_name");
					galleryLanguage = shastraList.getString("gallery_language");
					String download = shastraList.getString("download"); 
					
					rowItem.add(new ShastraListRow(galleryImagesID, galleryID, galleryImageTitle, galleryImagesName, galleryLanguage, download));
				}
				
				tvLanguage.setText(galleryLanguage);
				adapter = new CustomList(getApplicationContext());
				lstShastra.setAdapter(adapter);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private class CustomList extends BaseAdapter {

		private Context context;
		private TextView tvName;
//		private ImageButton btnPlay;
		private View rowView;
		
		public CustomList(Context c) {
			this.context = c;
		}
		
		@Override
		public int getCount() {
			return rowItem.size();
		}

		@Override
		public ShastraListRow getItem(int position) {
			return rowItem.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			try {

				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				rowView = inflater.inflate(R.layout.shastra_list_row, parent, false);
				tvName		= (TextView) rowView.findViewById(R.id.tv_galary_name);
//				btnPlay = (ImageButton) rowView.findViewById(R.id.img_btn_in_shastra_list_row);
				
				tvName.setText(rowItem.get(position).getGalleryImageTitle());
				System.out.println("in custom list view");
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			rowView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String path = checkURL(rowItem.get(position).getGalleryImagesName());
					String fileName = rowItem.get(position).getGalleryImageTitle();
					Intent in = new Intent(ShastraList.this, ShastraDetailActivity.class);
					in.putExtra("PDF_URL", path.replace(" ", "%20"));
					in.putExtra("File_Name", fileName);
					startActivity(in);
//					rowView.setEnabled(false);
				}
			});
			
//			btnPlay.setOnClickListener(new OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					String path = checkURL(rowItem.get(position).getGalleryImagesName());
//					String fileName = rowItem.get(position).getGalleryImageTitle();
//					Intent in = new Intent(ShastraList.this, ShastraDetailActivity.class);
//					in.putExtra("PDF_URL", path.replace(" ", "%20"));
//					in.putExtra("File_Name", fileName);
//					startActivity(in);
////					rowView.setEnabled(false);
//				}
//			});
			
			return rowView;
		}
	}
	
	public String checkURL(String url){
		String temp = url.substring(0, 4);
		if(temp.equalsIgnoreCase("http")){
			return url;
		} else {
			String str = "http://www.media.gurukul.us/images/shastra/" + url;
			return str;
		}
	}
	
	@Override
	protected void onRestart() {
		super.onRestart();
		finish();
		System.out.println("this is in restart activity in shastra list");
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		System.out.println("this is in pause activity in shastra list");
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		System.out.println("in resume activity in shastra list");
	}
	
	public void showError(String title, String msg){
		
		AlertDialog.Builder b = new Builder(ShastraList.this);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					finish();
			}
		});
		AlertDialog d = b.create();
		d.show();
	}

}