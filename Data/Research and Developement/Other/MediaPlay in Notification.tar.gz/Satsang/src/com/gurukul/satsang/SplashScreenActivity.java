package com.gurukul.satsang;

import android.os.Bundle;
import android.view.Window;
import android.app.Activity;
import android.content.Intent;

public class SplashScreenActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_splash_screen);
//		getApplicationContext().stopService(new Intent(getApplicationContext(),MusicPlayerService.class));
//		MusicPlayerService.setMusicPlayerServiceNull();

        Thread t = new Thread(Splash_Runnable);
        t.start();
	}

	Runnable Splash_Runnable = new Runnable() {
        @Override
        public void run() {
            try {
                Thread.sleep(3000);
                startActivity(new Intent(SplashScreenActivity.this, MainActivity.class));
                SplashScreenActivity.this.finish();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };
}
