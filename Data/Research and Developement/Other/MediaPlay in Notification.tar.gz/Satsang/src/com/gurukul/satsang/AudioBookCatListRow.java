package com.gurukul.satsang;

public class AudioBookCatListRow {
	public String galleryID;
	public String galleryName;
	
	public AudioBookCatListRow(String galleryID, String galleryName) {
		this.galleryID = galleryID;
		this.galleryName = galleryName;
	}

	public String getGalleryID() {
		return galleryID;
	}

	public void setGalleryID(String galleryID) {
		this.galleryID = galleryID;
	}

	public String getGalleryName() {
		return galleryName;
	}

	public void setGalleryName(String galleryName) {
		this.galleryName = galleryName;
	}
}
