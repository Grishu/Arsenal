package com.gurukul.satsang;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ShastraDetailActivity extends Activity {

	private WebView mWeb_PageLink = null;
	private TextView tvMsg;
	private ImageButton btnBack;
	private LinearLayout llTopBar;
	private Uri mCapturedImageURI = null;
	private final static int FILECHOOSER_RESULTCODE = 1;
	private String URL = null;
	private String fileName = null;
	private ProgressDialog mProgressDialog = null;
	private CommonClass mCommonClass = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_shastra_detail);
		initialize();
		
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mWeb_PageLink.destroy();
				finishActivity(10);
				finish();
			}
		});
		
		if (mCommonClass.CheckNetwork(ShastraDetailActivity.this)) {
			if(fileIsAvailable == null){
				fileIsAvailable = new CheckFileIsAvailableTask();
				fileIsAvailable.execute(URL.replace(" ", "%20"), fileName);
			}
		} else {
			mWeb_PageLink.setVisibility(View.GONE);
			llTopBar.setVisibility(View.VISIBLE);
			tvMsg.setText("Please check internet connection");
			tvMsg.setVisibility(View.VISIBLE);
		}
	}

	public void initialize() {
		mWeb_PageLink	= (WebView) findViewById(R.id.web_PageLink);
		tvMsg			= (TextView) findViewById(R.id.tv_in_shastra_detail);
		btnBack			= (ImageButton) findViewById(R.id.btn_back_in_shastra_detail);
		llTopBar		= (LinearLayout) findViewById(R.id.ll_header_in_shastra_detail);
		mCommonClass	= new CommonClass();
		URL				= getIntent().getStringExtra("PDF_URL");
		fileName		= getIntent().getStringExtra("File_Name");
	}
	
	
	CheckFileIsAvailableTask fileIsAvailable = null;
	private class CheckFileIsAvailableTask extends AsyncTask<String, String, String> {
		private String fileName;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			try{
				if (mProgressDialog == null) {
					mProgressDialog = new ProgressDialog(ShastraDetailActivity.this);
				}
				if (mProgressDialog != null) {
					// keyFlag=true;
					if (!mProgressDialog.isShowing()) {
						mProgressDialog.show();
						mProgressDialog.setMessage(Constant.msgLoading);
						mProgressDialog.setCanceledOnTouchOutside(false);
					}
				}
			} catch(Exception e){
				e.printStackTrace();
			}
		}
		
		@Override
		protected String doInBackground(String... url) {
			fileName	= url[1];
			int status = mCommonClass.checkFileIsAvailable(url[0]);
			return ""+status;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (mProgressDialog.isShowing()) {
				mProgressDialog.dismiss();
			}
			if(result != null){
				fileIsAvailable = null;
				if(result.equalsIgnoreCase("200")){
					llTopBar.setVisibility(View.GONE);
					tvMsg.setVisibility(View.GONE);
					mWeb_PageLink.setVisibility(View.VISIBLE);
					LoadWebPageLink(URL);
				} else {
					mWeb_PageLink.setVisibility(View.GONE);
					llTopBar.setVisibility(View.VISIBLE);
					tvMsg.setText(fileName + "  is not available");
					tvMsg.setVisibility(View.VISIBLE);
				}
			}
		}
	}

	@SuppressWarnings("deprecation")
	@SuppressLint("SetJavaScriptEnabled")
	private void LoadWebPageLink(String URL) {
		if (mCommonClass.CheckNetwork(ShastraDetailActivity.this)) {

			// String BackURL = URL;

			overridePendingTransition(0, 0);

			mWeb_PageLink.loadUrl(URL);
			mWeb_PageLink.getSettings().setJavaScriptEnabled(true);
			mWeb_PageLink.getSettings().setPluginState(PluginState.ON);
			mWeb_PageLink.getSettings().setUseWideViewPort(true);
			mWeb_PageLink.setDownloadListener(new DownloadListener() {
				public void onDownloadStart(String url, String userAgent,
						String contentDisposition, String mimetype,
						long contentLength) {
					new GetPDF().execute(url.trim());

				}
			});

			mWeb_PageLink.setWebChromeClient(new WebChromeClient() {
				@Override
				public void onProgressChanged(final WebView view,
						final int newProgress) {
					super.onProgressChanged(view, newProgress);

					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub

							try {
								if (mProgressDialog == null) {
									mProgressDialog = new ProgressDialog(view
											.getContext());
								}
								if (mProgressDialog != null) {

									// keyFlag=true;
									if (!mProgressDialog.isShowing()) {
										mProgressDialog.show();
										mProgressDialog
												.setMessage(Constant.msgLoading);
										mProgressDialog.setProgress(0);
										mProgressDialog
												.setCanceledOnTouchOutside(false);
									}
									mProgressDialog
											.incrementProgressBy(newProgress);
									if (newProgress == 100
											&& mProgressDialog.isShowing()) {
										mProgressDialog.dismiss();
										mProgressDialog = null;
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							// keyFlag=false;
						}
					});
				}

				// For Android 3.0+
				public void openFileChooser(ValueCallback<Uri> uploadMsg,
						String acceptType) {
					// KG_Specification.this.mUploadMessage = uploadMsg;
					finish();

					Intent pickIntent = new Intent();
					pickIntent.setType("image/*");
					pickIntent.setAction(Intent.ACTION_GET_CONTENT);

					Intent takePhotoIntent = new Intent(
							MediaStore.ACTION_IMAGE_CAPTURE);
					File photo = new File(Environment
							.getExternalStorageDirectory(), String.format(
							"Pic%snew.jpg", System.currentTimeMillis()));
					mCapturedImageURI = Uri.fromFile(photo);
					takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT,
							mCapturedImageURI);
					String pickTitle = "Select or take a new Picture"; // Or get
					// from
					// strings.xml
					Intent chooserIntent = Intent.createChooser(pickIntent,
							pickTitle);
					chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
							new Intent[] { takePhotoIntent });

					startActivityForResult(chooserIntent,
							ShastraDetailActivity.FILECHOOSER_RESULTCODE);
//					 mCapturedImageURI=null;
				}

				// For Android < 3.0
				@SuppressWarnings("unused")
				public void openFileChooser(ValueCallback<Uri> uploadMsg) {
					openFileChooser(uploadMsg, "");
				}

				// For Firing the action in Android >4.0
				@SuppressWarnings("unused")
				public void openFileChooser(ValueCallback<Uri> uploadMsg,
						String acceptType, String capture) {
				}
			});

			mWeb_PageLink.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					view.loadUrl(url);
					return true;
				}
			});

			mWeb_PageLink.getSettings().setBuiltInZoomControls(true);
		}

	}

	private class GetPDF extends AsyncTask<String, Boolean, Boolean> {
		private ProgressDialog mDialog = null;
		private String Pdf_Path = "";

		protected void onPreExecute() {
			super.onPreExecute();
			mDialog = new ProgressDialog(ShastraDetailActivity.this);
			mDialog.setCanceledOnTouchOutside(false);
			mDialog.setMessage(Constant.msgLoading);
			mDialog.show();

		}

		protected Boolean doInBackground(String... PDFURL) {
			try {
				String URL = PDFURL[0];

				File PDFDirectory = new File(
						Environment.getExternalStorageDirectory()
								+ "/Download/");
				if (!PDFDirectory.exists()) {
					PDFDirectory.mkdir();
				}

				InputStream mInputStream = CommonClass
						.OpenHttpConnectionPost(URL);
				Pdf_Path = PDFDirectory
						+ String.format("/Satsang%sPDF.pdf",
								String.valueOf(URL.hashCode()));
				FileOutputStream fos = new FileOutputStream(Pdf_Path);

				byte data[] = new byte[1024];

				int count = 0;

				while ((count = mInputStream.read(data)) != -1) {
					fos.write(data, 0, count);
				}
				fos.close();
				mInputStream.close();

				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		}

		protected void onPostExecute(Boolean result) {
			if(mDialog != null){
				if (mDialog.isShowing()) {
					mDialog.dismiss();
					mDialog = null;
				}
			}
			if (result) {
				try {
					Uri path = Uri.fromFile(new File(Pdf_Path));
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setDataAndType(path, "application/pdf");
					startActivityForResult(intent, 10);
				} catch (Exception e) {
					e.printStackTrace();
					Toast.makeText(ShastraDetailActivity.this,
							"PDF Viewer Not Found in Your Device",
							Toast.LENGTH_SHORT).show();
				}

			} else {
				Toast.makeText(ShastraDetailActivity.this, "Not Download PDF",
						Toast.LENGTH_SHORT).show();
			}
			super.onPostExecute(result);
		}

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		mWeb_PageLink.destroy();
		finishActivity(10);
		 finish();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		finish();
		System.out.println("this is in restart activity");
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		System.out.println("this is in pause activity");
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		System.out.println("in resume activity");
	}
}
