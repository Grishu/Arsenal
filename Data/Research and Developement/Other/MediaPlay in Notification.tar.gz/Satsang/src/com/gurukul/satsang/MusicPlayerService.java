package com.gurukul.satsang;

import java.io.IOException;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore.Audio;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.TypedValue;
import android.widget.RemoteViews;

public class MusicPlayerService extends Service {
	private SharedPreferences mSharedPreferences_Read = null;
	private SharedPreferences mSharedPreferences_Write = null;
	private NotificationManager mNotificationManager;
	private Notification notification;
	public static boolean notiCancelOnStop = false;

	private static MusicPlayerService mMusicPlayerService = null;
	private MusicPlayer_Listener mMusicPlayer_Listener = null;

	public static int index = 0;
	public int id;
	public static boolean flag = true, pauseScreen = false, stopScreen = false;;

	public void setMusicPlayer_Listener(Context context) {
		mMusicPlayer_Listener = (MusicPlayer_Listener) context;
	}

	public static MusicPlayerService getMusicPlayerService() {
		return mMusicPlayerService;
	}

	public static MusicPlayerService setMusicPlayerServiceNull() {
		// stopScreen=true;
		// pauseScreen = true;
		// mMusicPlayerService.stopStart();
		return mMusicPlayerService = null;
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Log.e(Constant.TAG, "onCreate MusicPlayerService");
		startWakeLock();
		// startRepeatingTask();
		mSharedPreferences_Read = getSharedPreferences(
				Constant.SHARED_PREF_PLAYER, MODE_WORLD_READABLE);
		mSharedPreferences_Write = getSharedPreferences(
				Constant.SHARED_PREF_PLAYER, MODE_WORLD_WRITEABLE);

		registerPlay();

	}

	private TelephonyManager mTelephonyManager = null;

	/*
	 * Register the telephony events
	 */
	private void RegisterCallState() {
		if (mTelephonyManager == null) {
			mTelephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
			mTelephonyManager.listen(mPhoneStateListener,
					PhoneStateListener.LISTEN_CALL_STATE);
		}
	}

	/*
	 * De-register the telephony events
	 */
	private void DeRegisterCallState() {
		if (mTelephonyManager != null) {
			mTelephonyManager.listen(mPhoneStateListener,
					PhoneStateListener.LISTEN_NONE);
			mTelephonyManager = null;
		}
	}

	private final PhoneStateListener mPhoneStateListener = new PhoneStateListener() {
		/*
		 * Call State Changed
		 */
		public void onCallStateChanged(int state, String incomingNumber) {
			Log.d("DEBUG", "STATE " + state);
			// String phoneState = "UNKNOWN";
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				// phoneState = "IDLE";
				if (mAudio_Player != null) {
					try {
						if (MusicPlayerService.this.position() > 2000) {

							if (UtilClass.playing == true) {
								MusicPlayerService.this.play();
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				Log.d("DEBUG", "IDLE(Phone Ending)");
				break;
			case TelephonyManager.CALL_STATE_RINGING:
				// phoneState = "Ringing (" + incomingNumber + ") ";
				if (mAudio_Player != null) {
					try {
						if (MusicPlayerService.this.isPlaying()) {
							MusicPlayerService.this.pause(true);
							UtilClass.playing = true;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				Log.d("DEBUG", "RINGING(Phone inComming)");
				break;
			case TelephonyManager.CALL_STATE_OFFHOOK:
				// phoneState = "Offhook";
				if (mAudio_Player != null) {
					try {
						if (MusicPlayerService.this.isPlaying()) {
							MusicPlayerService.this.pause(true);
							UtilClass.playing = true;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				Log.d("DEBUG", "OFFHOOK(Phone Running and Calling)");
				break;

			}
			super.onCallStateChanged(state, incomingNumber);
		}

	};

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		Log.e(Constant.TAG, "onStart MusicPlayerService");
		try {
			if (intent != null) {
				// if(intent.getAction().trim().equals(Constant.MUSIC_PLAYER.ACTIONS_FROM_ACTIVITY)){
				// startBind();
				mMusicPlayerService = this;
				Audio_Player_Memory_Allocate();
				RegisterCallState();
				// setNotification();
				// }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Audio_Player mAudio_Player = null;
	private String mFileToPlay;
	private int mPlayPos = Constant.INVALID_POSTION;

	private void Audio_Player_Memory_Allocate() {
		mAudio_Player = new Audio_Player();
		mAudio_Player.setHandler(mMediaplayerHandler);
	}

	/**
	 * Provides a unified interface for dealing with midi files and other media
	 * files.
	 */
	private class Audio_Player {
		private MediaPlayer mMediaPlayer = new MediaPlayer();
		private Handler mHandler = null;
		private boolean mIsInitialized = false;

		public Audio_Player() {
			mMediaPlayer.setWakeMode(MusicPlayerService.this,
					PowerManager.PARTIAL_WAKE_LOCK);
		}

		// public void setDataSource(String path) {
		// try {
		// mMediaPlayer.reset();
		// mMediaPlayer.setOnPreparedListener(null);
		// if (path.startsWith("content://")) {
		// mMediaPlayer.setDataSource(MusicPlayerService.this, Uri.parse(path));
		// } else {
		// mMediaPlayer.setDataSource(path);
		// }
		// mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		// mMediaPlayer.prepare();
		// } catch (IOException ex) {
		// // TODO: notify the user why the file couldn't be opened
		// mIsInitialized = false;
		// return;
		// } catch (IllegalArgumentException ex) {
		// // TODO: notify the user why the file couldn't be opened
		// mIsInitialized = false;
		// return;
		// }
		// mMediaPlayer.setOnCompletionListener(listener);
		// mMediaPlayer.setOnErrorListener(errorListener);
		//
		// mIsInitialized = true;
		// }

		public void setDataSource(String asset_path) {
			if (asset_path == null) {
				return;
			}
			try {

				// System.out.println("SONG Played : " + asset_path);
				// asset_path =
				// "http://ia700200.us.archive.org/1/items/testmp3testfile/mpthreetest.mp3";
				// System.out.println("SONG Played : "+asset_path);
				mMediaPlayer.reset();
				mMediaPlayer.setOnPreparedListener(null);
				mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
				mMediaPlayer.setDataSource(asset_path);
				mMediaPlayer.prepare();

				/*
				 * AssetFileDescriptor mAssetFileDescriptor =
				 * getAssets().openFd(asset_path);
				 * mMediaPlayer.setDataSource(mAssetFileDescriptor
				 * .getFileDescriptor(), mAssetFileDescriptor.getStartOffset(),
				 * mAssetFileDescriptor.getLength());
				 * mAssetFileDescriptor.close();
				 */

			} catch (IOException ex) {
				// TODO: notify the user why the file couldn't be opened

				ex.printStackTrace();
				mIsInitialized = false;
				return;
			} catch (IllegalArgumentException ex) {
				// TODO: notify the user why the file couldn't be opened
				ex.printStackTrace();
				mIsInitialized = false;
				return;
			}
			mMediaPlayer.setOnCompletionListener(listener);
			mMediaPlayer.setOnErrorListener(errorListener);

			mIsInitialized = true;
		}

		public boolean isInitialized() {
			return mIsInitialized;
		}

		public boolean isPlaying() {
			return mMediaPlayer.isPlaying();
		}

		public void start() {
			mMediaPlayer.start();
			UtilClass.playing = true;
		}

		public void stop() {
			mMediaPlayer.reset();
			mIsInitialized = false;
			UtilClass.playing = false;
		}

		/**
		 * You CANNOT use this player anymore after calling release()
		 */
		public void release() {
			stop();
			mMediaPlayer.release();
		}

		public void pause() {
			mMediaPlayer.pause();
			UtilClass.playing = false;
		}

		public void setHandler(Handler handler) {
			mHandler = handler;
		}

		MediaPlayer.OnCompletionListener listener = new MediaPlayer.OnCompletionListener() {
			public void onCompletion(MediaPlayer mp) {
				// Acquire a temporary wakelock, since when we return from
				// this callback the MediaPlayer will release its wakelock
				// and allow the device to go to sleep.
				// This temporary wakelock is released when the RELEASE_WAKELOCK
				// message is processed, but just in case, put a timeout on it.
				mHandler.sendEmptyMessage(TRACK_ENDED);
				// stopForeground(true);
				UtilClass.playing = false;
			}
		};

		MediaPlayer.OnErrorListener errorListener = new MediaPlayer.OnErrorListener() {
			public boolean onError(MediaPlayer mp, int what, int extra) {
				switch (what) {
				case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
					mIsInitialized = false;
					mMediaPlayer.release();
					// Creating a new MediaPlayer and settings its wakemode does
					// not
					// require the media service, so it's OK to do this now,
					// while the
					// service is still being restarted
					mMediaPlayer = new MediaPlayer();
					mHandler.sendEmptyMessage(TRACK_ENDED);
					return true;
				default:
					Log.d("MultiPlayer", "Error: " + what + "," + extra);
					break;
				}
				return false;
			}
		};

		public long duration() {
			return mMediaPlayer.getDuration();
		}

		public long position() {
			return mMediaPlayer.getCurrentPosition();
		}

		public long seek(long whereto) {
			mMediaPlayer.seekTo((int) whereto);
			return whereto;
		}

		public void setVolume(float vol) {
			mMediaPlayer.setVolume(vol, vol);
		}

		public void setAudioSessionId(int sessionId) {
			mMediaPlayer.setAudioSessionId(sessionId);
		}

		public int getAudioSessionId() {
			return mMediaPlayer.getAudioSessionId();
		}
	}

	private static final int TRACK_ENDED = 1;
	private Handler mMediaplayerHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case TRACK_ENDED:
				Next();
				break;
			default:
				break;
			}
		}
	};

	/**
	 * Returns whether something is currently playing
	 * 
	 * @return true if something is playing (or will be playing shortly, in case
	 *         we're currently transitioning between tracks), false if not.
	 */
	public boolean isPlaying() {
		if (mAudio_Player == null) {
			Audio_Player_Memory_Allocate();
		}
		return mAudio_Player.isPlaying();
	}

	/**
	 * Returns the path of the currently playing file, or null if no file is
	 * currently playing.
	 */
	public String getPath() {
		return mFileToPlay;
	}

	/**
	 * Opens the specified file and readies it for playback.
	 * 
	 * @param path
	 *            The full path of the file to be opened.
	 */
	public void openAudio() {
		synchronized (this) {
			if (mAudio_Player == null) {
				Audio_Player_Memory_Allocate();
			}

			System.out.println("mPlayPos : " + mPlayPos);

			if (mPlayPos < 0 || mPlayPos > (Playlist_Detail.rowItem.size())) {
				return;
			}
			// if mCursor is null, try to associate path with a database cursor
			mFileToPlay = Playlist_Detail.rowItem.get(mPlayPos)
					.getGalleryImagesName();
			mAudio_Player.setDataSource(mFileToPlay);

			if (!mAudio_Player.isInitialized()) {
				stop();
			}
		}
	}

	private void StoreSongPostion() {
		SharedPreferences.Editor editor = mSharedPreferences_Write.edit();
		editor.putInt(Constant.SP_SONG_POSITION, mPlayPos);
		editor.commit();
	}

	public void setAudioFilePos(int audiofilepos) {

		// System.out.println("AUDIO FILE POS: "+audiofilepos);

		mPlayPos = audiofilepos;
		Playlist_Detail.selected_pos = mPlayPos;
		Playlist_Detail.adapter.notifyDataSetChanged();
		StoreSongPostion();
		stop();
		openAudio();
		play();
	}

	public int getAudioFilePos() {
		return mSharedPreferences_Read.getInt(Constant.SP_SONG_POSITION, -1);
	}

	public void Previous() {
		synchronized (this) {
			if (Playlist_Detail.rowItem.size() == 0) {
				Log.d(Constant.TAG, "No play queue");
				return;
			}

			mPlayPos--;
			Playlist_Detail.selected_pos = mPlayPos;
			Playlist_Detail.adapter.notifyDataSetChanged();

			if (mPlayPos < 0) {
				mPlayPos = 0;
				Playlist_Detail.selected_pos = mPlayPos;
				Playlist_Detail.adapter.notifyDataSetChanged();
				return;
			}

			StoreSongPostion();

			stop();
			openAudio();
			play();

			if (mMusicPlayer_Listener != null) {
				new Handler().post(new Runnable() {
					@Override
					public void run() {
						mMusicPlayer_Listener.getPlayingSongIndex(mPlayPos);
					}
				});
			}
		}
	}

	public void Next() {
		synchronized (this) {
			if (Playlist_Detail.rowItem.size() == 0) {
				Log.d(Constant.TAG, "No play queue");
				return;
			}

			mPlayPos++;
			Playlist_Detail.selected_pos = mPlayPos;
			Playlist_Detail.adapter.notifyDataSetChanged();

			if (mPlayPos > (Playlist_Detail.rowItem.size() - 1)) {
				mPlayPos = (Playlist_Detail.rowItem.size() - 1);
				Playlist_Detail.selected_pos = mPlayPos;
				Playlist_Detail.adapter.notifyDataSetChanged();
				return;
			}

			StoreSongPostion();

			stop();
			openAudio();
			play();

			if (mMusicPlayer_Listener != null) {
				new Handler().post(new Runnable() {
					@Override
					public void run() {
						mMusicPlayer_Listener.getPlayingSongIndex(mPlayPos);
					}
				});
			}
		}
	}

	public void play() {
		synchronized (this) {
			if (mAudio_Player == null) {
				Audio_Player_Memory_Allocate();
			}
			if (mAudio_Player.isInitialized()) {
				mAudio_Player.start();

				// Looper.prepare();

				Handler handler = new Handler();
				handler.post(new Runnable() {
					@Override
					public void run() {
						System.out.println("NOTIFICATION");
						setNotification();
					}
				});

				// handler.sendEmptyMessage(0);
			}
		}
	}

	public void playStart() {
		synchronized (this) {
			if (mAudio_Player == null) {
				Audio_Player_Memory_Allocate();
			}
			if (mAudio_Player.isInitialized()) {
				mAudio_Player.start();
			}
		}
	}

	public void stopStart() {
		try {
			if (mMusicPlayerService == null) {
				Log.d(Constant.TAG, "MusicPlayerService object NULL");
				return;
			}
			if (mMusicPlayerService.isPlaying()) {
				mMusicPlayerService.pause(true);
				mMusicPlayerService.seek(0);
			}

			MusicPlayerService.flag = false;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void stop() {
		synchronized (this) {
			if (mAudio_Player == null) {
				Audio_Player_Memory_Allocate();
			}
			if (mAudio_Player.isInitialized()) {
				mAudio_Player.stop();
				stopNotification();
			}
		}
	}

	/**
	 * Pauses playback (call play() to resume)
	 */
	public void pause(boolean removeicon) {
		synchronized (this) {
			if (mAudio_Player == null) {
				Audio_Player_Memory_Allocate();
			}
			if (isPlaying()) {
				mAudio_Player.pause();
				// stopForeground(removeicon);
			}
		}
	}

	/**
	 * Returns the duration of the file in milliseconds. Currently this method
	 * returns -1 for the duration of MIDI files.
	 */
	public long duration() {
		if (mAudio_Player == null) {
			Audio_Player_Memory_Allocate();
		}
		if (mAudio_Player.isInitialized()) {
			return mAudio_Player.duration();
		}
		return -1;
	}

	/**
	 * Returns the current playback position in milliseconds
	 */
	public long position() {
		if (mAudio_Player == null) {
			Audio_Player_Memory_Allocate();
		}
		if (mAudio_Player.isInitialized()) {
			return mAudio_Player.position();
		}
		return -1;
	}

	/**
	 * Seeks to the position specified.
	 * 
	 * @param pos
	 *            The position to seek to, in milliseconds
	 */
	public long seek(long pos) {
		if (mAudio_Player == null) {
			Audio_Player_Memory_Allocate();
		}
		if (mAudio_Player.isInitialized()) {
			if (pos < 0)
				pos = 0;
			if (pos > mAudio_Player.duration())
				pos = mAudio_Player.duration();
			return mAudio_Player.seek(pos);
		}
		return -1;
	}

	public Bitmap getTitle(String text) {
		Bitmap mBitmap = Bitmap.createBitmap((int) TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, Constant.NOTIFICATION_WIDTH,
				getResources().getDisplayMetrics()), (int) TypedValue
				.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
						Constant.NOTIFICATION_HEIGHT, getResources()
								.getDisplayMetrics()), Bitmap.Config.ARGB_4444);
		Canvas mCanvas = new Canvas(mBitmap);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setSubpixelText(true);
		// paint.setTypeface(CommonClass.setFont(getApplicationContext(),
		// Constant.GUJARATI_FONT1));
		paint.setStyle(Paint.Style.FILL);
		paint.setColor(Color.BLACK);
		paint.setTextSize(TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, Constant.NOTIFICATION_TEXT_SIZE,
				getResources().getDisplayMetrics()));
		paint.setTextAlign(Align.LEFT);
		mCanvas.drawText(text, 0, TypedValue.applyDimension(
				TypedValue.COMPLEX_UNIT_DIP, Constant.NOTIFICATION_TEXT_Y_POS,
				getResources().getDisplayMetrics()), paint);
		return mBitmap;
	}

	public static final int PLAYBACKSERVICE_STATUS = 1999;

	@SuppressWarnings("deprecation")
	@SuppressLint("NewApi")
	void setNotification() {
		try {
			int icon = R.drawable.ic_launcher;
			long when = System.currentTimeMillis();

			notification = new Notification(icon, "Satsang", when);
			mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				RemoteViews contentView = null;
				if (pauseScreen == false && stopScreen == false) {
					Log.i(Constant.TAG, "Pause Button Showing");
					contentView = new RemoteViews(getPackageName(),
							R.layout.notification_layout);
				} else {
					Log.i(Constant.TAG, "Play Button Showing");
					contentView = new RemoteViews(getPackageName(),
							R.layout.notification_layout_pause);
				}

//				 notiCancelOnStop = false;
				Intent buttonsIntent = new Intent();
				/*
				 * buttonsIntent.putExtra("do_action", "stop");
				 * contentView.setOnClickPendingIntent(R.id.btnStop,
				 * PendingIntent.getService(this, 1111, buttonsIntent,
				 * PendingIntent.FLAG_UPDATE_CURRENT));//getActivity(ctx, 0,
				 * buttonsIntent, PendingIntent.FLAG_UPDATE_CURRENT));
				 * buttonsIntent.putExtra("do_action", "next");
				 * contentView.setOnClickPendingIntent(R.id.btnNext,
				 * PendingIntent.getService(this, 2222, buttonsIntent,
				 * PendingIntent.FLAG_UPDATE_CURRENT));//getActivity(ctx, 0,
				 * buttonsIntent, PendingIntent.FLAG_UPDATE_CURRENT));
				 * buttonsIntent.putExtra("do_action", "pre");
				 * contentView.setOnClickPendingIntent(R.id.btnPrevious,
				 * PendingIntent.getService(this, 3333, buttonsIntent,
				 * PendingIntent.FLAG_UPDATE_CURRENT));//getActivity(ctx, 0,
				 * buttonsIntent, PendingIntent.FLAG_UPDATE_CURRENT));
				 * buttonsIntent.putExtra("do_action", "play");
				 * contentView.setOnClickPendingIntent(R.id.btnPlayPause,
				 * PendingIntent.getService(this, 10000, buttonsIntent,
				 * PendingIntent.FLAG_UPDATE_CURRENT));//getActivity(ctx, 0,
				 * buttonsIntent, PendingIntent.FLAG_UPDATE_CURRENT));
				 */

				// System.out.println("POSITION TITLE : "+
				// trimName(Playlist_Detail.rowItem.get(index).getGalleryImagesName()));

				contentView.setTextViewText(R.id.title,
						trimName(Playlist_Detail.rowItem.get(index)
								.getGalleryImagesName()));

				id = R.id.title;

				buttonsIntent.setAction(NEXT_ACTION);
				contentView.setOnClickPendingIntent(R.id.btnNext, PendingIntent
						.getBroadcast(this, 9, buttonsIntent,
								PendingIntent.FLAG_UPDATE_CURRENT));// getActivity(ctx,
																	// 0,
																	// buttonsIntent,
																	// PendingIntent.FLAG_UPDATE_CURRENT));
				buttonsIntent.setAction(PRE_ACTION);
				contentView.setOnClickPendingIntent(R.id.btnPrevious,
						PendingIntent.getBroadcast(this, 8, buttonsIntent,
								PendingIntent.FLAG_UPDATE_CURRENT));// getActivity(ctx,
																	// 0,
																	// buttonsIntent,
																	// PendingIntent.FLAG_UPDATE_CURRENT));
				buttonsIntent.setAction(PLAY_ACTION);
				contentView.setOnClickPendingIntent(R.id.btnPlayPause,
						PendingIntent.getBroadcast(this, 7, buttonsIntent,
								PendingIntent.FLAG_UPDATE_CURRENT));// getActivity(ctx,
																	// 0,
																	// buttonsIntent,
																	// PendingIntent.FLAG_UPDATE_CURRENT));
				buttonsIntent.setAction(STOP_ACTION);
				contentView.setOnClickPendingIntent(R.id.btnStop, PendingIntent
						.getBroadcast(this, 6, buttonsIntent,
								PendingIntent.FLAG_UPDATE_CURRENT));// getActivity(ctx,
																	// 0,
																	// buttonsIntent,
																	// PendingIntent.FLAG_UPDATE_CURRENT));
				buttonsIntent.setAction(CANCEL_ACTION);
				contentView.setOnClickPendingIntent(R.id.btnCancel,
						PendingIntent.getBroadcast(this, 5, buttonsIntent,
								PendingIntent.FLAG_UPDATE_CURRENT));// getActivity(ctx,
																	// 0,
																	// buttonsIntent,
																	// PendingIntent.FLAG_UPDATE_CURRENT));

				notification.contentView = contentView;

				notification.flags |= Notification.FLAG_NO_CLEAR; // Do not
																	// clear the
																	// notification
				notification.defaults |= Notification.DEFAULT_LIGHTS; // LED
				// notification.defaults |= Notification.DEFAULT_VIBRATE;
				// //Vibration
				// notification.defaults |= Notification.DEFAULT_SOUND; // Sound
				notification.flags |= Notification.FLAG_ONGOING_EVENT;

				// mNotificationManager.notify(1, notification);
				startForeground(PLAYBACKSERVICE_STATUS, notification);
			} else {
				// System.out.println("sdk version in else = " +
				// Build.VERSION.SDK_INT);

				System.out.println("notiCancelOnStop = " + notiCancelOnStop);
				
				RemoteViews views = new RemoteViews(getPackageName(),
						R.layout.normal_notification);
				views.setImageViewResource(R.id.imageView1, R.drawable.god_img);
				views.setTextViewText(R.id.title_in_normal_notification,
						trimName(Playlist_Detail.rowItem.get(index)
								.getGalleryImagesName()));

//				notification = new Notification();

				notiCancelOnStop = true;
				notification.contentView = views;
//				notification.flags |= Notification.FLAG_AUTO_CANCEL;
				
				notification.icon = R.drawable.god_img;
				


				Intent mIntent = new Intent(this, Playlist_Detail.class);
				mIntent.setAction(Constant.ACTIONS_FROM_NOTIFICATION);
				mIntent.setFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
				mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_FORWARD_RESULT);
				
				mIntent.putExtra(Constant.KEY_AUDIO_FILE_POS, index);
				mIntent.putExtra("GalaryID", Playlist_Detail.playing_galary_ID);
				PendingIntent contentIntent = PendingIntent.getActivity(this, 100, mIntent, PendingIntent.FLAG_UPDATE_CURRENT);
				notification.contentIntent = contentIntent;
//			     mNotificationManager.notify(PLAYBACKSERVICE_STATUS, notification);  
				startForeground(PLAYBACKSERVICE_STATUS, notification);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void stopNotification() {
		stopForeground(true);
		mNotificationManager.cancelAll();
		System.out.println("After cancelall()");
		
	}

	@Override
	public void onDestroy() {

		unRegisterPlay();

		// stopRepeatingTask();
		DeRegisterCallState();
		// stopForeground(true);
		// stopBind();
		stopWakeLock();
		Log.e(Constant.TAG, "onDestroy MusicPlayerService");
		super.onDestroy();
	}

	private WakeLock mWakeLock = null;
	private static final String WAKE_LOCK_TAG = "WAKE_LOCK_MUSIC_PLAYER_SERVICE";

	private void startWakeLock() {
		if (mWakeLock == null) {
			Log.d(Constant.TAG, "getting a new WakeLock");
			PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
			Log.d(Constant.TAG, "PowerManager acquired");
			mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
					WAKE_LOCK_TAG);
			Log.d(Constant.TAG, "WakeLock set");
		}
		mWakeLock.acquire();
		Log.d(Constant.TAG, "WakeLock acquired");
	}

	private void stopWakeLock() {
		if (mWakeLock != null) {
			mWakeLock.release();
			Log.d(Constant.TAG, "WakeLock released");
		}
	}

	/*
	 * @Override public int onStartCommand(Intent intent, int flags, int
	 * startId) { //TODO do something useful
	 * 
	 * System.out.println("SERVICE.............. "); String action =
	 * intent.getStringExtra("do_action");
	 * 
	 * System.out.println("Action : "+action);
	 * 
	 * if(intent != null){ mMusicPlayerService=this;
	 * Audio_Player_Memory_Allocate(); RegisterCallState(); }
	 * 
	 * 
	 * if (intent != null && action != null) { if(action.equals("play")){
	 * System.out.println("Play............");
	 * 
	 * mMusicPlayerService.stop();
	 * 
	 * if(flag == true){ System.out.println("Pausing............");
	 * mMusicPlayerService.pause(true); flag = false; }else{
	 * 
	 * System.out.println("Playing............");
	 * 
	 * 
	 * synchronized (this) { if (Constant.SONG.size() == 0) {
	 * Log.d(Constant.TAG, "No play queue");
	 * 
	 * }
	 * 
	 * StoreSongPostion();
	 * 
	 * stop(); openAudio(); play();
	 * 
	 * if(mMusicPlayer_Listener!=null){ new Handler().post(new Runnable() {
	 * 
	 * @Override public void run() {
	 * mMusicPlayer_Listener.getPlayingSongIndex(mPlayPos); } }); } }
	 * 
	 * flag = true; }
	 * 
	 * // Playlist_Detail.doPauseResume();
	 * 
	 * }else if(action.equals("stop")){
	 * System.out.println("Stopping............");
	 * 
	 * flag = false; mMusicPlayerService.stop(); Playlist_Detail.doStop();
	 * 
	 * }else if(action.equals("next")){ System.out.println("Next............");
	 * 
	 * mMusicPlayerService.stop(); Playlist_Detail.doStop();
	 * 
	 * Playlist_Detail.next();
	 * 
	 * if(!(index >= Constant.SONG.size() - 1)) index ++;
	 * 
	 * }else if(action.equals("pre")){ System.out.println("Pre............");
	 * 
	 * mMusicPlayerService.stop(); Playlist_Detail.doStop();
	 * 
	 * Playlist_Detail.pre();
	 * 
	 * if(!(index <= 0)) index --; }
	 * 
	 * // if(intent!=null && action == null){ // mMusicPlayerService=this; //
	 * Audio_Player_Memory_Allocate(); // RegisterCallState(); // // } } return
	 * Service.START_NOT_STICKY; }
	 */
	public static final String NEXT_ACTION = "next_action";
	public static final String PRE_ACTION = "pre_action";
	public static final String PLAY_ACTION = "play_action";
	public static final String PAUSE_ACTION = "pause_action";
	public static final String STOP_ACTION = "stop_action";
	public static final String CANCEL_ACTION = "cancel_action";

	private void registerPlay() {

		IntentFilter mIntentFilter = new IntentFilter();
		mIntentFilter.addAction(NEXT_ACTION);
		mIntentFilter.addAction(PRE_ACTION);
		mIntentFilter.addAction(PLAY_ACTION);
		mIntentFilter.addAction(PAUSE_ACTION);
		mIntentFilter.addAction(STOP_ACTION);
		mIntentFilter.addAction(CANCEL_ACTION);

		registerReceiver(mBrodcastPlayAction, mIntentFilter);

	}

	public void unRegisterPlay() {

		unregisterReceiver(mBrodcastPlayAction);
	}

	private BrodcastPlayAction mBrodcastPlayAction = new BrodcastPlayAction();

	private class BrodcastPlayAction extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			System.out.println("Receiver : " + intent.getAction());

			if (intent.getAction().equals(NEXT_ACTION)) {
				stopScreen = false;
				pauseScreen = false;
				if (!(index >= Playlist_Detail.rowItem.size() - 1))
					index = index + 1;
				Next();

			} else if (intent.getAction().equals(PRE_ACTION)) {
				stopScreen = false;
				pauseScreen = false;
				if (!(index <= 0))
					index = index - 1;
				Previous();

			} else if (intent.getAction().equals(STOP_ACTION)) {
				stopScreen = true;
				pauseScreen = true;
				stopStart();
				setNotification();

			} else if (intent.getAction().equals(PLAY_ACTION)) {
				stopScreen = false;
				if (mMusicPlayerService.isPlaying()) {
					pauseScreen = true;
					pause(true);
					setNotification();
				} else {
					pauseScreen = false;
					playStart();
					setNotification();
				}

			} else if (intent.getAction().equals(CANCEL_ACTION)) {
				stopScreen = true;
				pauseScreen = true;
				stopStart();
				getApplicationContext().stopService(
						new Intent(getApplicationContext(),
								MusicPlayerService.class));
				setMusicPlayerServiceNull();
			}

			Playlist_Detail.refreshNow();
			Playlist_Detail.setPausePlayButtonImage();
		}
	}

	public String trimName(String str) {
		String temp = str.substring(str.lastIndexOf("/") + 1, str.length());
		return temp.replace("%20", " ");
	}

}