/** Automatically generated file. DO NOT MODIFY */
package com.gurukul.satsang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}