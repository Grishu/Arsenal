/** Automatically generated file. DO NOT MODIFY */
package com.drc.karoake_app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}