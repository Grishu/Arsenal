package com.drc.karoake_app;

import java.io.File;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.drc.karaoke_app.commonUtils.Constant;

public class Gallery_Fragment extends Fragment {

	private Context m_context;
	private String fileName = "";
	private int deleteFIlePos = -1;
	public static ExpandableListView expandbleList;
	private TextView tvEmpty;
	private Dialog m_dialog;
	private File root;
	private File thumRoot;
	private ArrayList<File> parentItems;
	private ArrayList<File> thumItems;
	private ArrayList<String> childarr;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Gallery");
		View m_view = inflater.inflate(R.layout.gallery_layout, container, false);
		m_context = Gallery_Fragment.this.getActivity();
		expandbleList = (ExpandableListView) m_view.findViewById(R.id.exp_slide_items_in_gallery);
		tvEmpty = (TextView) m_view.findViewById(R.id.tv_no_record_in_gallery);
		parentItems = new ArrayList<File>();
		thumItems = new ArrayList<File>();
		childarr = new ArrayList<String>();
		root = new File(Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH);
		thumRoot = new File(Constant.PLAY_VIDEO.VIDEO_PATH);
		System.out.println("In on create view of gallery");
		getfile(root);
		childarr.add("1");
		getThum(thumRoot);
		if (parentItems.isEmpty()) {
			tvEmpty.setVisibility(View.VISIBLE);
			expandbleList.setVisibility(View.GONE);
		} else {
			expandbleList.setVisibility(View.VISIBLE);
			tvEmpty.setVisibility(View.GONE);
			adapter = new ExpandListAdapter(m_context, parentItems, childarr, thumItems);
			expandbleList.setAdapter(adapter);
		}
		return m_view;
	}

	public ArrayList<File> getfile(File dir) {
		parentItems.clear();
		File listFile[] = dir.listFiles();
		if (listFile != null && listFile.length > 0) {
			for (int i = listFile.length - 1; i >= 0; i--) {
				if (!listFile[i].isDirectory()) {
					if (listFile[i].getName().endsWith(".mp4")) {
						parentItems.add(listFile[i]);
						// System.out.println("get video Name in else = " + listFile[i]);
					}
				}
			}
		}
		return parentItems;
	}
	
	public ArrayList<File> getThum(File dir) {
		thumItems.clear();
		File listImageFile[] = dir.listFiles();
		if (listImageFile != null && listImageFile.length > 0) {
			for (int i = listImageFile.length-1; i >= 0 ; i--) {
 
				if (!listImageFile[i].isDirectory()) {
					if (listImageFile[i].getName().endsWith(".png")) {
						thumItems.add(listImageFile[i]);
					}
				}
			}
		}
		return thumItems;
	}

	@SuppressLint("InflateParams")
	private void showDeleteDialog() {
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Delete = (Button) m_viewDialog
				.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog
				.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog
				.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText(getResources().getString(
				R.string.lbl_sure_to_delete_video));
		btn_Cancel.setText(getString(R.string.lbl_cancel));
		btn_Delete.setText(getString(R.string.lbl_delete));
		btn_Delete.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean deleted = deleteFile(fileName);
				if (deleted == true) {
					m_dialog.dismiss();
				}
			}
		});

		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}

	public boolean deleteFile(String videoFileName) {
		String selectedFilePath = Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH
				+ videoFileName;
		System.out.println("selected file path =" + selectedFilePath);
		File file = new File(selectedFilePath);
		boolean deleted = file.delete();
		if (deleted == true) {
			parentItems.remove(deleteFIlePos);
			adapter.notifyDataSetChanged();
			if (parentItems.isEmpty()) {
				tvEmpty.setVisibility(View.VISIBLE);
			} else {
				tvEmpty.setVisibility(View.GONE);
			}
		}
		return deleted;
	}

	ExpandListAdapter adapter = null;

	public class ExpandListAdapter extends BaseExpandableListAdapter {
		private Context m_contxt;
		private ArrayList<File> m_Parent;
		private ArrayList<File> m_thumItems;
		private ArrayList<String> m_child;
		private ImageView thum;
		private TextView lblListHeader;
		private TextView tvPlay, tvDelete, tvShare;
		private ImageButton btnDownlaod;
		String dUrl;

		public ExpandListAdapter(Context p_contxt, ArrayList<File> p_grupParent, ArrayList<String> p_arrChild, ArrayList<File> p_thumItems) {
			m_contxt = p_contxt;
			m_thumItems = p_thumItems;
			m_Parent = p_grupParent;
			m_child = p_arrChild;
		}

		@Override
		public int getGroupCount() {
			return m_Parent.size();
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			return m_child.size();
		}

		@Override
		public Object getGroup(int groupPosition) {
			return m_Parent.get(groupPosition);
		}

		@Override
		public Object getChild(int groupPosition, int childPosition) {
			return m_child.get(childPosition);
		}

		@Override
		public long getGroupId(int groupPosition) {
			return m_Parent.get(groupPosition).length();
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return m_child.get(childPosition).length();
		}

		@Override
		public boolean hasStableIds() {
			return false;
		}

		@SuppressWarnings("deprecation")
		@SuppressLint("InflateParams")
		@Override
		public View getGroupView(final int groupPosition,
				final boolean isExpanded, View convertView, ViewGroup parent) {
			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) m_contxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(R.layout.parent_view, null);
			}

			try {
				thum = (ImageView) convertView.findViewById(R.id.iv_slPlay);
				btnDownlaod = (ImageButton) convertView.findViewById(R.id.btn_download);
				btnDownlaod.setVisibility(View.INVISIBLE);
				lblListHeader = (TextView) convertView.findViewById(R.id.tv_slSongTitle);
				lblListHeader.setText(trimName(m_Parent.get(groupPosition).toString()));
				String songName = trimName(m_Parent.get(groupPosition).toString());
				
				/* set Thumbnail images 
				 * by Dhaval Travadi
				 * ---------------------------------------------------------------------------- * 
				 */
				int i = 0;
				for (i = 0; i < m_thumItems.size(); i++) {
					if (m_thumItems.get(i).getName().contains(songName.substring(0, songName.lastIndexOf(".") - 3))) {
						System.out.println("image name = " + m_thumItems.get(i).toString());
						Drawable d = (Drawable) Drawable.createFromPath(m_thumItems.get(i).toString());
						thum.setBackgroundDrawable(d);
					}
				}
				/* -------------------------------------------------------------------------------------------------  */
			} catch (Exception e) {
				e.printStackTrace();
			}

			convertView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					fileName = trimName(m_Parent.get(groupPosition).toString());
					deleteFIlePos = groupPosition;
					if (isExpanded) {
						expandbleList.collapseGroup(groupPosition);
					} else {
						expandbleList.expandGroup(groupPosition);
						expandbleList.computeScroll();
					}
				}
			});
			return convertView;
		}

		@SuppressLint("InflateParams")
		@Override
		public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) m_contxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(R.layout.child_for_gallery, null);
			}

			tvPlay = (TextView) convertView.findViewById(R.id.btn_play_in_gallery);
			tvDelete = (TextView) convertView.findViewById(R.id.btn_delete_in_gallery);
			tvShare = (TextView) convertView.findViewById(R.id.btn_share_in_gallery);

			tvPlay.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent();
					intent.setAction(android.content.Intent.ACTION_VIEW);
					intent.setDataAndType(Uri.fromFile(new File(Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH + trimName(m_Parent.get(groupPosition).getName()))), "audio/*");
					startActivity(intent);
				}
			});

			tvDelete.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					showDeleteDialog();
				}
			});

			tvShare.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					shareVideo(trimName(m_Parent.get(groupPosition).getName()));
					System.out.println("share button is clicked");
				}
			});
			return convertView;
		}

		@Override
		public void onGroupExpanded(int groupPosition) {
			super.onGroupExpanded(groupPosition);
			try {
				int len = getGroupCount();
				for (int i = 0; i < len; i++) {
					if (i != groupPosition) {
						expandbleList.collapseGroup(i);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}
	}

	public String trimName(String str) {
		String temp = str.substring(str.lastIndexOf("/") + 1, str.length());
		return temp.replace("%20", " ");
	}

	public void shareVideo(final String file_name) {
		new Handler().post(new Runnable() {
			@Override
			public void run() {
				String temp = "mnt/sdcard/KaraokeVideo/Recorded/" + file_name;
			    File shareFile = new File(temp);
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
			    shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
			    shareIntent.setType("video/*");
			    Uri uri = Uri.fromFile(shareFile);
			    shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
				try {
					startActivity(Intent.createChooser(shareIntent, "Share video via:"));
				} catch (android.content.ActivityNotFoundException ex) {
					ex.printStackTrace();
				}
			}
		});
	}
}