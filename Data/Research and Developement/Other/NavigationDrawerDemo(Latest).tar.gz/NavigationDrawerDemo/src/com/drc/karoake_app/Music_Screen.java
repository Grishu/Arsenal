package com.drc.karoake_app;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Filter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.drc.karaoke_app.Vo.SongData;
import com.drc.karaoke_app.commonUtils.CommanClass;
import com.drc.karaoke_app.commonUtils.Constant;
import com.drc.karaoke_app.commonUtils.ImageLoader;
import com.drc.karaoke_app.commonUtils.JSONParser;

public class Music_Screen extends Fragment {

	private NotificationManager mNotificationManager;
	private int notificationID = 100;
	private CommonClass mClass;
	public static Context m_context;
	private Dialog m_dialog;
	private View m_view;
	public  static ListView lstMusic;
	public static TextView tvEmpty;	
	public static ArrayList<SongData> songData;
	private String url;
	private String fileName;
	private ProgressDialog mProgressDialog1 = null;
	int progress = 0;
	private DownloadVideo mDownloadVideo = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Karaoke English");
		MainActivity.selectedLanguage = "English";
		m_view		= inflater.inflate(R.layout.music_list_layout, container, false);
		m_context	= Music_Screen.this.getActivity();
		mClass		= new CommonClass();
		tvEmpty		= (TextView) m_view.findViewById(R.id.tv_no_record);
		lstMusic	= (ListView) m_view.findViewById(R.id.lst_mzList);
		songData = new ArrayList<SongData>();

		loadData = new LoadSongData();
		loadData.execute(Constant.WEB_SERVICES_URL);
		
		MainActivity.et_SearchBar.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				adapter.getFilter().filter(s.toString());
				adapter.notifyDataSetChanged();
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			@Override
			public void afterTextChanged(Editable s) {
			}
		});
		return m_view;
	}
	
	LoadSongData loadData = null;
	public class LoadSongData extends AsyncTask<String, String, String> {

		private ProgressDialog mProgressDialog = null;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(m_context);
			mProgressDialog.setMessage("Loading");
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.show();
		}

		@Override
		protected String doInBackground(String... url) {
			JSONParser jParser = new JSONParser();
			String json = jParser.getJSONFromUrl(url[0]);
			return json;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (mProgressDialog != null) {
				new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						mProgressDialog.dismiss();
					}
				}, 1000);
			}
			if (result != null) {
				Constant.ALL_DATA = result;
				int arrSize = 0;
				arrSize = setSongData(Constant.ALL_DATA, MainActivity.selectedLanguage);
				if(arrSize > 0){
					tvEmpty.setVisibility(View.GONE);
					adapter = new ListAdapter(m_context);
					lstMusic.setAdapter(adapter);
				} else {
					tvEmpty.setVisibility(View.VISIBLE);
				}
			} else {
				Toast.makeText(m_context, "no data found", Toast.LENGTH_LONG).show();
			}
		}
	}

	public static int setSongData(String data, String selectedLanguage){
		songData.clear();
		try {
			JSONObject mainObj = new JSONObject(data);
			JSONObject resultObj = new JSONObject(mainObj.get("result").toString());
			JSONArray arr = resultObj.getJSONArray("videos");
			for (int i = 0; i < arr.length(); i++) {
				JSONObject webData = arr.getJSONObject(i);
				String language = webData.getString("language");
				if(language.equalsIgnoreCase(selectedLanguage)){
					tvEmpty.setVisibility(View.GONE);
					String category = webData.getString("category");
					String videoLink = webData.getString("link");
					String title = webData.getString("title");
					String description = webData.getString("description");
					String thumbnail = webData.getString("thumbnail");
					int status = Integer.parseInt(webData.get("status").toString());
					songData.add(new SongData(category, language, videoLink, title, description, thumbnail, status));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return songData.size();
	}
	
	public static ListAdapter adapter = null;
	public class ListAdapter extends ArrayAdapter<SongData> {

		private Context m_cont;
		private ArrayList<SongData> mOriginalValues;
		private TextView tv_Title;
		private ImageButton btnDownload;
		private ImageView thum;
		View view;

		public ListAdapter(Context p_cont) {
			super(p_cont, R.layout.parent_view);
			m_cont = p_cont;
			this.mOriginalValues = songData;
		}

		@Override
		public int getCount() {
			return songData.size();
		}

		@Override
		public SongData getItem(int position) {
			return songData.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@SuppressLint("ViewHolder")
		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			LayoutInflater li = (LayoutInflater) m_cont.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view		= li.inflate(R.layout.parent_view, parent, false);
			thum		= (ImageView) view.findViewById(R.id.iv_slPlay);
			tv_Title	= (TextView) view.findViewById(R.id.tv_slSongTitle);
//			tv_Desc		= (TextView) view.findViewById(R.id.tv_slDesc);
			btnDownload = (ImageButton) view.findViewById(R.id.btn_download);
			
			thum.setScaleType(ScaleType.FIT_XY);
			ImageLoader mImageLoader = new ImageLoader(m_cont,
			CommonClass.getDIP(m_cont,getResources().getDimension(R.dimen.IMG_WIDTH)),
			CommonClass.getDIP(m_cont,getResources().getDimension(R.dimen.IMG_HEIGHT)), true,R.drawable.ic_play);
			mImageLoader.DisplayImage(songData.get(position).getThumbnail(), thum);
			tv_Title.setText(songData.get(position).getTitle());
//			tv_Desc.setText(songData.get(position).getDescription());
			btnDownload.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if (mClass.CheckNetwork(m_context) == true) {
						String videoUrl = songData.get(position).getLink().replace(" ", "%20"); 
						String name = songData.get(position).getTitle() + ".mp4";
						String imgUrl = songData.get(position).getThumbnail();
						showDownloadDialog(videoUrl, name, imgUrl);
					} else {
						Toast.makeText(m_context, "Please check internet connection", Toast.LENGTH_LONG).show();
					}
				}
			});
			return view;
		}
		
		@Override
		public Filter getFilter() {
			Filter filter = new Filter() {
				@SuppressWarnings("unchecked")
				@Override
				protected void publishResults(CharSequence constraint, FilterResults results) {
					songData = (ArrayList<SongData>) results.values;
					adapter.notifyDataSetChanged();
					if(results.count <= 0){
						tvEmpty.setVisibility(View.VISIBLE);
					} else {
						tvEmpty.setVisibility(View.GONE);
					}
				}
				
				@SuppressLint("DefaultLocale")
				@Override
				protected FilterResults performFiltering(CharSequence constraint) {
					FilterResults results = new FilterResults(); // Holds the results of a filtering operation in values
					ArrayList<SongData> FilteredArrList = new ArrayList<SongData>();

					if (mOriginalValues == null) {
						mOriginalValues = new ArrayList<SongData>(songData); // saves the original data in mOriginalValues
					}
					
					if (constraint == null || constraint.length() == 0) {
						results.count = mOriginalValues.size();
						results.values = mOriginalValues;
					} else {
						constraint = constraint.toString().toLowerCase();
						System.out.println("constraint = " + constraint);

						for (int i = 0; i < mOriginalValues.size(); i++) {
							String data = mOriginalValues.get(i).title;
							if (data.toLowerCase().contains(constraint.toString())) {
								FilteredArrList.add(new SongData(mOriginalValues.get(i).category, mOriginalValues.get(i).language, mOriginalValues.get(i).link, mOriginalValues.get(i).title, mOriginalValues.get(i).description, mOriginalValues.get(i).thumbnail, mOriginalValues.get(i).status));
							}
						}
						results.count = FilteredArrList.size();
						results.values = FilteredArrList;
					}
					return results;
				}
			};
			return filter;
		}
	}

	@SuppressLint("InflateParams")
	private void showDownloadDialog(String p_videoUrl, String fName, final String imageUrl) {
		url = p_videoUrl;
		System.out.println("video url = " + url);
		fileName = fName;
		System.out.println("file name = " + fileName);
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Download = (Button) m_viewDialog.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText(m_context.getResources().getString(R.string.lbl_sure_to_download_video));
		btn_Cancel.setText(m_context.getString(R.string.lbl_cancel));
		btn_Download.setText(m_context.getString(R.string.lbl_download));
		btn_Download.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.e("Video URL", url);
				mDownloadVideo = new DownloadVideo();
				mDownloadVideo.execute(url, imageUrl);
				m_dialog.dismiss();
			}
		});
		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}

	private class DownloadVideo extends AsyncTask<String, Integer, Boolean> {
		boolean Status = false, inPostExecute = false;

		protected void onPreExecute() {
			Status = true;
			mProgressDialog1 = new ProgressDialog(m_context);
			mProgressDialog1.setCancelable(true);
			mProgressDialog1.setCanceledOnTouchOutside(false);
			mProgressDialog1.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			mProgressDialog1.setMessage(Constant.DOWNLOAD.DOWNLOADING_MESSAGE);
			mProgressDialog1.setOnDismissListener(new OnDismissListener() {
				@Override
				public void onDismiss(DialogInterface dialog) {
					getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					if (inPostExecute == false) {
						Status = false;
					}
					if (!(DownloadVideo.this.isCancelled())) {
						DownloadVideo.this.cancel(true);
						if (CommanClass.MemoryCardCheck() && Status == false) {
							if (new File(Constant.PLAY_VIDEO.VIDEO_PATH
									+ fileName).exists()) {
								new File(Constant.PLAY_VIDEO.VIDEO_PATH
										+ fileName).delete();
							}
						}
					}
				}
			});
			mProgressDialog1.show();
			super.onPreExecute();
		}

		synchronized protected Boolean doInBackground(String... MP3URL) {

			if (CommanClass.MemoryCardCheck()) {
				int count;
				try {
					getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

					URL url = new URL(MP3URL[0]);
					URLConnection conexion = url.openConnection();
					conexion.connect();

					File VideoDirectory = new File(Constant.DOWNLOAD.SDCARD_VIDEO_URL);
					if (!VideoDirectory.exists()) {
						VideoDirectory.mkdir();
					}
					int lenghtOfFile = conexion.getContentLength();
					InputStream mInputStream = conexion.getInputStream();
					FileOutputStream fos = new FileOutputStream(VideoDirectory + "/" + fileName);
					byte data[] = new byte[1024];
					long total = 0;
					while ((count = mInputStream.read(data)) != -1 && Status) {
						total += count;
						publishProgress((int) ((total * 100) / lenghtOfFile));
						fos.write(data, 0, count);
					}
					fos.close();
					mInputStream.close();
					
					URL url1 = new URL(MP3URL[1]);
					Bitmap image = BitmapFactory.decodeStream(url1.openConnection().getInputStream());
					saveImage(image, fileName.replace(".mp4", ".png"));
					System.out.println("image file name = " + fileName);

				} catch (Exception e) {
					e.printStackTrace();
					Status = false;
				}
			} else {
				Status = false;
			}
			System.out.println("Do in... before IF " + MP3URL);
			return Status;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			super.onProgressUpdate(values);
//			System.out.println("Progressing...."); //
			mProgressDialog1.setProgress(values[0]);
		}

		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
			if (result) {
				inPostExecute = true;
				Toast.makeText(m_context, Html.fromHtml(Constant.DOWNLOAD.DOWNLOAD), Toast.LENGTH_SHORT).show();
				System.out.println("Finish.....");
			} else {
				if (CommanClass.MemoryCardCheck()) {
					if (new File(Constant.PLAY_VIDEO.VIDEO_PATH + fileName)
							.exists()) {
						new File(Constant.PLAY_VIDEO.VIDEO_PATH + fileName)
								.delete();
					}
				}
			}
			getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

			if (mProgressDialog1 != null) {
				if (mProgressDialog1.isShowing()) {
					mProgressDialog1.dismiss();
				}
			}
			
			if(inPostExecute == true){
				displayNotification();
				LoadFragmentsScreens("FavoriteScreen", new Favorite_Fragment());
				MainActivity.selectedPos = 3;
				MainActivity.iv_Search.setVisibility(View.INVISIBLE);
				MainActivity.iv_Language.setVisibility(View.INVISIBLE);
				MainActivity.line.setVisibility(View.INVISIBLE);
				MainActivity.adapter.notifyDataSetChanged();
			}
			mDownloadVideo = null;
		}
	}
	
	private void LoadFragmentsScreens(String p_tagName, Fragment p_fragClass) {
		FragmentManager m_fmngr = getFragmentManager();
		FragmentTransaction m_ftrans = m_fmngr.beginTransaction();
		MainActivity.showScreen = 0;
		m_ftrans.replace(R.id.content_frame, p_fragClass);
		m_ftrans.commit();
	}

public static Bitmap getBitmapFromURL(String src) {
    try {
        URL url = new URL(src);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();
        InputStream input = connection.getInputStream();
        Bitmap myBitmap = BitmapFactory.decodeStream(input);
        return myBitmap;
    } catch (IOException e) {
        // Log exception
        return null;
    }
}

	public void saveImage(Bitmap img, String name){
//		String file_path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PhysicsSketchpad";
		File dir = new File(Constant.PLAY_VIDEO.VIDEO_PATH);
		if(!dir.exists()){
			dir.mkdirs();
		}
		File file = new File(dir, name);
		try {
			FileOutputStream fOut;
			fOut = new FileOutputStream(file);
			img.compress(Bitmap.CompressFormat.PNG, 85, fOut);
			fOut.flush();
			fOut.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	protected void displayNotification() {
		Intent intent = new Intent(m_context, MainActivity.class);
		intent.setAction(Constant.ACTIONS_FROM_NOTIFICATION);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
		PendingIntent pIntent = PendingIntent.getActivity(m_context, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
		Notification noti = new Notification(R.drawable.ic_launcher, "Karaoke Star", System.currentTimeMillis());
		noti.setLatestEventInfo(m_context, fileName, "Successfully downloaded.", pIntent);
		noti.flags = Notification.FLAG_AUTO_CANCEL;
		NotificationManager notificationManager = (NotificationManager) m_context.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(0, noti); 
	   }

	   protected void cancelNotification() {
	      Log.i("Cancel", "notification");
	      mNotificationManager.cancel(notificationID);
	   }
	   
	public String trimName(String str) {
		String temp = str.substring(str.lastIndexOf("/") + 1, str.length());
		return temp.replace("%20", " ");
	}
}
