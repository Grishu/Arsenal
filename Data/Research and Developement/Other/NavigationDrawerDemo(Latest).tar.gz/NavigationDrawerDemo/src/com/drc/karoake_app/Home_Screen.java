package com.drc.karoake_app;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

public class Home_Screen extends Fragment {

	private WebView gif;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Home Screen");
		View m_view = inflater.inflate(R.layout.home_layout, container, false);
		
		gif = (WebView) m_view.findViewById(R.id.webView1);
		gif.loadUrl("file:///android_asset/gif.html");
		return m_view;
	}
}
