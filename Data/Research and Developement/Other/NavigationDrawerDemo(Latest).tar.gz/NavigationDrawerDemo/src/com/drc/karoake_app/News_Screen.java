package com.drc.karoake_app;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karoake_app.lazyload.ImageLoader;

public class News_Screen extends Fragment {

	private Context m_context;
	private ImageView iv_AppThumb;
	private TextView tv_Title, tv_Desc;
	private ImageLoader m_loader;
	private String m_result, m_title, m_Message, m_AppUrl;
//	private String m_CompUrl;
	private Boolean m_status;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("News Center");
		View m_view = inflater.inflate(R.layout.news_layout, container, false);
		m_context = News_Screen.this.getActivity();
		iv_AppThumb = (ImageView) m_view.findViewById(R.id.iv_nlAppThumbnail);
		tv_Title = (TextView) m_view.findViewById(R.id.tv_nlAppTitle);
		tv_Desc = (TextView) m_view.findViewById(R.id.tv_nlDescription);
		m_loader = new ImageLoader(m_context);

		callNewsWS newsWs = new callNewsWS();
		newsWs.execute();
		return m_view;
	}

	/**
	 * Call news webservice to get the news updates
	 */
	private class callNewsWS extends AsyncTask<String, Integer, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			CommonUtils.showProgress(m_context, getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			// http://appcloud.drcsystems.com/API/NewsUpdate/get?id=8
			m_result = parseJSON("http://appcloud.drcsystems.com/API/NewsUpdate/get?id=8");

			return m_result;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			CommonUtils.dismissDialog();
			if (result != null) {
				try {
					JSONObject m_obj = new JSONObject(result);
					m_status = m_obj.getBoolean("Status");
					if (m_status) {
						JSONArray m_arr = m_obj.getJSONArray("Data");
						for (int i = 0; i < m_arr.length(); i++) {
							JSONObject m_resObj = m_arr.getJSONObject(i);
							m_title = m_resObj.getString("Title");
							m_Message = m_resObj.getString("Message");
							m_AppUrl = m_resObj.getString("ImageUrl");
//							m_CompUrl = m_resObj.getString("TileUrl");
						}
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

				tv_Title.setText(m_title);
				tv_Desc.setText(m_Message);
				m_loader.DisplayImage(m_AppUrl, R.drawable.thumb,
						iv_AppThumb);
			}
		}
	}

	public static String parseJSON(String p_url) {
//		JSONObject jsonObject = null;
		String json = null;
		try {
			// Create a new HTTP Client
			DefaultHttpClient defaultClient = new DefaultHttpClient();
			// Setup the get request
			HttpGet httpGetRequest = new HttpGet(p_url);
			System.out.println("Request URL--->" + p_url);
			// Execute the request in the client
			HttpResponse httpResponse = defaultClient.execute(httpGetRequest);
			// Grab the response
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent(), "UTF-8"));
			json = reader.readLine();
			System.err.println("JSON Response--->" + json);
			// Instantiate a JSON object from the request response
//			jsonObject = new JSONObject(json);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}
}
