package com.drc.karaoke_app.commonUtils;

import java.io.File;

import android.os.Environment;

public class Constant {
	public final static String HELP_PAGE_URL = "http://www.travjous.com/index.php/en/help-check-in-companion/";
	public final static String NETWORK_NOT_AVAILABLE = "Network Connectivity not available.";
	public final static String BASE_URL = "http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/";
	public final static String WEB_SERVICES_URL = "http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/videoLists/";
	public static final String ACTIONS_FROM_ACTIVITY = "ACTION_FROM_ACTIVITY";
	public static final String ACTIONS_FROM_NOTIFICATION = "ACTIONS_FROM_NOTIFICATION";
	public static String ALL_DATA = " ";

	public static final class ACTION {
		public static final String ACTION_HOMESCREEN = "HomeScreen";
		public static final String ACTION_KARAOKESCREEN = "KaraokeScreen";
		public static final String ACTION_GALLERYSCREEN = "GalleryScreen";
		public static final String ACTION_SAMPLESONGSSCREEN = "SampleSongsScreen";
		public static final String ACTION_MORESCREEN = "MoreScreen";
	}

	public static final class TAB_TEXT {
		public static final String HOME = "Home";
		public static final String KARAOKE = "Karaoke";
		public static final String GALLERY = "Gallery";
		public static final String SAMPLESONG = "Sample Songs";
		public static final String MORE = "More";
	}

	public static final class DOWNLOAD {
		// public static final String DOWNLOAD_VIDEO_TITLE = "Download Video?";
		public static final String DOWNLOAD_MASSAGE = "Do u want to download?";
		public static final String DOWNLOAD = "Video is downloaded";
		public static final String DOWNLOAD_START = "Video Downloading...";
		public static final String NOT_DOWNLOAD = "No video downloaded";
		public static final String DOWNLOAD_INPROCESS = "Downloading.....";
		public static final String DIALOG_BUTTON_YES = "Yes";
		public static final String DIALOG_BUTTON_NO = "No";
		public static final String DOWNLOADING_MESSAGE = "Video is downloading...";
		public static final String SDCARD_VIDEO_URL = Environment.getExternalStorageDirectory() + "/KaraokeVideo/";
		public static final String RECORD_DUPLICATE_MESSAGE = "Video has already been saved";
		public static final String VEDIO_STORE_SUCCESSFULLY_TITLE = "Video saved";
		public static final String VEDIO_STORE_SUCCESSFULLY_MESSAGE = "The video can now be watched in the video archive at any time.";
		public static final String DIALOG_BUTTON_OK = "OK";
	}

	public static final class PLAY_VIDEO {
		public static final String VIDEO_PATH = Environment.getExternalStorageDirectory() + File.separator + "KaraokeVideo" + File.separator;
		public static final String RECORDED_FOLDER_PATH = Environment.getExternalStorageDirectory() + File.separator + "KaraokeVideo" + File.separator + "Recorded" + File.separator;
		public static final String LIST_VIDEO_KEY = "list_video_key";
		public static final String PLAY_LIST_VEDIO = "play_list_vedio";
		public static final String DOWNLOAD_VIDIO_KEY = "download_vedio_key";
		public static final String PLAY_DONLOAD_VEDIO = "play_doWnload_vedio";
		public static final String STREMING_VIDEO = "Video is loading...";
	}
}