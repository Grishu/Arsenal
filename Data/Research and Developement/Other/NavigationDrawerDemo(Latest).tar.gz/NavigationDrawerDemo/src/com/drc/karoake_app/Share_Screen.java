package com.drc.karoake_app;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class Share_Screen extends Fragment {

	private Context m_context;
	private CommonClass mClass;
	private ImageView iv_FBShare, iv_TwitterShare, iv_DailyMotionShare, iv_iTuneShare;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Share");
		View m_view = inflater.inflate(R.layout.sharing_layout, container, false);
		m_context			= Share_Screen.this.getActivity();
		mClass				= new CommonClass();
		iv_FBShare			= (ImageView) m_view.findViewById(R.id.iv_shrFacebook);
		iv_TwitterShare		= (ImageView) m_view.findViewById(R.id.iv_shrTwitter);
		iv_DailyMotionShare = (ImageView) m_view.findViewById(R.id.iv_shrDailyMotion);
		iv_iTuneShare		= (ImageView) m_view.findViewById(R.id.iv_shriTune);

		iv_FBShare.setOnClickListener(m_OnClickListener);
		iv_TwitterShare.setOnClickListener(m_OnClickListener);
		iv_DailyMotionShare.setOnClickListener(m_OnClickListener);
		iv_iTuneShare.setOnClickListener(m_OnClickListener);
		return m_view;
	}

	/**
	 * Common click listener
	 */
	OnClickListener m_OnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			if (mClass.CheckNetwork(m_context) == true) {
				switch (v.getId()) {
				case R.id.iv_shrFacebook:
					ShareMedia(getResources().getString(R.string.fb_url));
					break;
				case R.id.iv_shrTwitter:
					ShareMedia(getResources().getString(R.string.twitter_url));
					break;
				case R.id.iv_shrDailyMotion:
					ShareMedia(getResources().getString(R.string.dailmotion_url));
					break;
				case R.id.iv_shriTune:
					ShareMedia(getResources().getString(R.string.itune_url));
					break;
				default:
					break;
				}
			} else {
				Toast.makeText(m_context, "Please check internet connection", Toast.LENGTH_LONG).show();
			}
		}
	};

	private void ShareMedia(String p_url) {
		Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(p_url), "text/html");
		startActivity(intent);
	}
}
