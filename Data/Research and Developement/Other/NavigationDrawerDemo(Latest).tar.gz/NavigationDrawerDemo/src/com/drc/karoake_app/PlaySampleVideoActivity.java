package com.drc.karoake_app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.MediaController;

public class PlaySampleVideoActivity extends Activity {

	public MediaController		mController = null;
	public static final int		USER_MOBILE = 0;
	private WebView				playVideo;
	private CommonClass			mCommonClass;
	private String				path;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_play_sample_video);
		initialize();
		System.out.println("video url = " + path);
		
		if(mCommonClass.CheckNetwork(getApplicationContext()) == true){
			playVideo();
		}

	}
	
	public void initialize(){
		playVideo		=	(WebView) findViewById(R.id.play_video);
		mCommonClass	=	new CommonClass();
		path = getIntent().getStringExtra("sample_video");
	}
	
	@SuppressLint("SetJavaScriptEnabled")
	private void playVideo() {
		try {
			playVideo.setWebViewClient(new WebViewClient() {
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			}
			});
			playVideo.getSettings().setJavaScriptEnabled(true);
			playVideo.setWebChromeClient(new WebChromeClient());
			playVideo.getSettings().setAllowFileAccess(true);
			playVideo.setWebChromeClient(new WebChromeClient() {
				@Override
				public void onProgressChanged(WebView view, int newProgress) {
					super.onProgressChanged(view, newProgress);
					if (newProgress == 100) {
					} else {
					}
				}

			});
			/****************************************************************************
			 * The below code is to open keyboard while surfing the site in
			 * webview.Webview has to be requested focus explicitly so that it
			 * can open keyboard in turn when any textbox is tapped into webpage
			 ****************************************************************************/
			playVideo.requestFocus(View.FOCUS_DOWN);
			playVideo.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View mView, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
						case MotionEvent.ACTION_UP:
							try {
								if (!mView.hasFocus()) {
									mView.requestFocus();
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							break;
					}
					return false;
				}
			});
			playVideo.loadUrl(path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Override
	public void onBackPressed() {
		finish();
		super.onBackPressed();
	}
}
