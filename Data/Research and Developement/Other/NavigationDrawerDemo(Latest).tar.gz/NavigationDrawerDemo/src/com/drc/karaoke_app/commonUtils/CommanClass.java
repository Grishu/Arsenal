package com.drc.karaoke_app.commonUtils;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Environment;
import android.util.DisplayMetrics;

public class CommanClass {

	/**
	 * This method use to Check Memory Card
	 */
	public static Boolean MemoryCardCheck() {

		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			return true;
		} else {
			return false;
		}
	}

	// Getting DIP
	public static boolean isTablet(Context context) {
		int DPI = context.getResources().getDisplayMetrics().densityDpi;
		// int width = context.getResources().getDisplayMetrics().widthPixels;
		// int height = context.getResources().getDisplayMetrics().heightPixels;

		if ((DisplayMetrics.DENSITY_MEDIUM == DPI)
				&& (context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_XLARGE) {
			System.out.println("isTABLET - TRUE");
			return true;
		}
		System.out.println("isTABLET - FALSE");
		return false;

	}

	public class Meta {
		public String num;
		public String type;
		public String ext;

		public Meta(String num, String ext, String type) {
			this.num = num;
			this.ext = ext;
			this.type = type;
		}
	}

	public class Video {
		public String ext = "";
		public String type = "";
		public String url = "";

		Video(String ext, String type, String url) {
			this.ext = ext;
			this.type = type;
			this.url = url;
		}
	}

}
