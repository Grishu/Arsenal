package com.drc.karoake_app;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karaoke_app.commonUtils.Constant;
import com.drc.karoake_app.lazyload.ImageLoader;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class MainActivity extends Activity {

    private String popUpContents[];
    private PopupWindow popupWindowLanguage;
    public static String selectedLanguage = "english";
    
	private LinearLayout llDrawer;
	private ImageView imgProfile;
	public static ImageView iv_Search, iv_Language;
	private ImageView btnSlide;
	private TextView tvProfileName;
	public static View line;
	private DrawerLayout mDrawerLayout;
	public static Button btnTitle;
	private Dialog m_dialog;
	public static EditText et_SearchBar;
	private Animation m_anim, m_animEnd;
	public static int selectedPos = 0;
	private boolean isSearchShow = false;
	private Bitmap bitmap;
	public static boolean goToGalleryScreen = false;
	public static int showScreen = 0;
	public static int showSelectedAction = 0;
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;
	private String mTitle = "";
	private String activityFromNotification = " ";
	private ArrayList<CustomRow> imgList;
	public static String profileImage = " ", profileName = " ", id = "";
	int[] imageID = { R.drawable.home_normal, R.drawable.gallery_normal, R.drawable.karakoe_normal, R.drawable.favorite_normal, R.drawable.more_normal };
	int[] imageIDSelected = { R.drawable.home_hover, R.drawable.gallery_hover, R.drawable.karakoe_hover, R.drawable.favorite_hover, R.drawable.more_hover };

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		showActionBar(showSelectedAction);
		Log.i("MainActivity", "onCreate");
		setContentView(R.layout.activity_main);
		mTitle = (String) getTitle();
		
		// add items on the array dynamically
        // format is LanguageName::LanguageID
		
        List<String> languageList = new ArrayList<String>();
        languageList.add("English::1");
        languageList.add("Hindi::2");
        languageList.add("Tamil::3");
        languageList.add("Spanish::4");
 
        // convert to simple array
        popUpContents = new String[languageList.size()];
        languageList.toArray(popUpContents);
 
         
        // initialize pop up window
        popupWindowLanguage = popupWindowLanguage();
		
		imgList = new ArrayList<CustomRow>();
		for (int i = 0; i < 5; i++) {
			imgList.add(new CustomRow(imageID[i], imageIDSelected[i]));
		}
		mDrawerLayout	= (DrawerLayout) findViewById(R.id.drawer_layout);
		imgProfile		= (ImageView) findViewById(R.id.img_profile);
		tvProfileName	= (TextView) findViewById(R.id.tv_profile_name);
		
		if (CommonUtils.getBooleanSharedPref(getApplicationContext(), getString(R.string.key_login_info), false)) {
			id	= CommonUtils.getStringSharedPref(getApplicationContext(), "ID", "");
			if(id.equalsIgnoreCase("FROM_NORMAL_USER")){
				profileImage	= CommonUtils.getStringSharedPref(getApplicationContext(), "PROFILE_IMAGE", "");
				profileName		= CommonUtils.getStringSharedPref(getApplicationContext(), "PROFILE_NAME", "");
				imgProfile.setScaleType(ScaleType.FIT_XY);
				ImageLoader mImageLoader = new ImageLoader(MainActivity.this);
				mImageLoader.DisplayImage(profileImage, R.drawable.ic_launcher, imgProfile);
			} else {
				try {
					profileName		= CommonUtils.getStringSharedPref(getApplicationContext(), "PROFILE_NAME", "");
					fb_pic			= new openFBProfilePic();
					fb_pic.execute(id);
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			tvProfileName.setText(profileName);
		}
		
		llDrawer = (LinearLayout) findViewById(R.id.ll_drawer);
		mDrawerList = (ListView) findViewById(R.id.drawer_list);
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.menu_icon, R.string.drawer_open,
				R.string.drawer_close) {
			/** Called when drawer is closed */
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu();
			}

			/** Called when a drawer is opened */
			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle("Select a river");
				invalidateOptionsMenu();
			}
		};

		activityFromNotification = getIntent().getAction();
		mDrawerLayout.setDrawerListener(mDrawerToggle);
		adapter = new CustomList(MainActivity.this);
		mDrawerList.setAdapter(adapter);

		if(activityFromNotification.equals(Constant.ACTIONS_FROM_NOTIFICATION)){
			LoadFragment("FavoriteScreen", new Favorite_Fragment());
			showActionBar(4);
			selectedPos = 3;
			adapter.notifyDataSetChanged();
		} else {
			LoadFragment("HomeScreen", new Home_Screen());
		}
	}
	
	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		mDrawerToggle.syncState();
	}

	/** Handling the touch event of app icon */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** Called whenever we call invalidateOptionsMenu() */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// If the drawer is open, hide action items related to the content view
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(llDrawer);
		menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return false;
	}
	private openFBProfilePic fb_pic = null;
	private class openFBProfilePic extends AsyncTask<String, String, Bitmap> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			bitmap = getFacebookProfilePicture(params[0]);
			return bitmap;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			super.onPostExecute(result);
//			storeImage(bitmap, profileName);
//			String storagePath = Environment.getExternalStorageDirectory() + "/KaraokeImages/" + profileImage;
//            Bitmap mBitmap = CommonClass.DecodeFileGetBitmap(MainActivity.this, storagePath, 100, 100);
			bitmap = getRoundBitmap(result);
			imgProfile.setImageBitmap(bitmap);
		}
	}


	public static Bitmap getFacebookProfilePicture(String userID){
	    Bitmap bitmap = null;
		try {
		    URL imageURL = new URL("https://graph.facebook.com/" + userID + "/picture?type=large");
			bitmap = BitmapFactory.decodeStream(imageURL.openConnection().getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	    return bitmap;
	}
	
	public static CustomList adapter = null;
	public class CustomList extends BaseAdapter {

		private Context context;
		private ImageView imgView;
		private View rowView;

		public CustomList(Context c) {
			this.context = c;
		}

		@Override
		public int getCount() {
			return imgList.size();
		}

		@Override
		public CustomRow getItem(int position) {
			return imgList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@SuppressLint("ViewHolder")
		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			try {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				rowView = inflater.inflate(R.layout.drawer_list_item, parent, false);
				imgView = (ImageView) rowView.findViewById(R.id.img_button);

				if (position == selectedPos) {
					imgView.setImageResource(imgList.get(position).getImageIDSelected());
				} else {
					imgView.setImageResource(imgList.get(position).getImageID());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			rowView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					System.out.println("item is clicked = " + position);
					selectedPos = position;
					adapter.notifyDataSetChanged();
					switch (position) {
					case 0:
						LoadFragment("HomeScreen", new Home_Screen());
						showActionBar(0);
						break;
					case 1:
						LoadFragment("GalleryScreen", new Gallery_Fragment());
						showActionBar(1);
						break;
					case 2:
						LoadFragment("MusicScreen", new Music_Screen());
						showActionBar(2);
						break;
					case 3:
						LoadFragment("FavoriteScreen", new Favorite_Fragment());
						showActionBar(3);
						break;
					case 4:
						LoadFragment("MoreScreen", new More_Screen());
						showActionBar(4);
						break;
					default:
						break;
					}
					 mDrawerLayout.closeDrawer(llDrawer);
				}
			});
			return rowView;
		}
	}

	public Bitmap getRoundBitmap(Bitmap bitmap) {
		try {
			if (bitmap.getWidth() >= bitmap.getHeight()) {
				bitmap = Bitmap.createBitmap(bitmap, bitmap.getWidth() / 6 - bitmap.getHeight() / 6, 0, bitmap.getHeight(), bitmap.getHeight());
				Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
				BitmapShader shader = new BitmapShader(bitmap, TileMode.CLAMP, TileMode.CLAMP);
				Paint paint = new Paint();
				paint.setAntiAlias(true);
				paint.setShader(shader);
				Canvas c = new Canvas(circleBitmap);
				c.drawCircle(bitmap.getHeight() / 2, bitmap.getHeight() / 2, bitmap.getHeight() / 2, paint);
				return circleBitmap;
			} else {
				bitmap = Bitmap.createBitmap(bitmap, 0, bitmap.getHeight() / 6 - bitmap.getWidth() / 6, bitmap.getWidth(), bitmap.getWidth());
				Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
				BitmapShader shader = new BitmapShader(bitmap, TileMode.CLAMP, TileMode.CLAMP);
				Paint paint = new Paint();
				paint.setAntiAlias(true);
				paint.setShader(shader);
				Canvas c = new Canvas(circleBitmap);
				c.drawCircle(bitmap.getWidth() / 2, bitmap.getWidth() / 2, bitmap.getWidth() / 2, paint);
				return circleBitmap;
			}
		} catch (Exception e) {
			return null;
		}
	}

	@SuppressLint("InflateParams")
	public void showActionBar(int showActionBarTitle) {
		ActionBar mActionBar = getActionBar();
		mActionBar.setDisplayShowHomeEnabled(false);
		mActionBar.setDisplayShowTitleEnabled(false);
		LayoutInflater mInflater = LayoutInflater.from(this);
		View mCustomView = mInflater.inflate(R.layout.custom_actionbar, null);
		btnTitle = (Button) mCustomView.findViewById(R.id.btn_mzTitle);
		btnSlide = (ImageView) mCustomView.findViewById(R.id.btn_side_navigate);
		iv_Search = (ImageView) mCustomView.findViewById(R.id.iv_mzSearch);
		iv_Language = (ImageView) mCustomView.findViewById(R.id.iv_mzLanguage);
		et_SearchBar = (EditText) mCustomView.findViewById(R.id.et_mzSearchBar);
		line = (View) mCustomView.findViewById(R.id.line);
		if (showActionBarTitle == 0) {
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.INVISIBLE);
			iv_Search.setVisibility(View.INVISIBLE);
			line.setVisibility(View.INVISIBLE);
			btnTitle.setText("Home Screen");
		} else if (showActionBarTitle == 1) {
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.INVISIBLE);
			iv_Search.setVisibility(View.INVISIBLE);
			line.setVisibility(View.INVISIBLE);
			btnTitle.setText("Gallery");
		} else if (showActionBarTitle == 2) {
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.VISIBLE);
			line.setVisibility(View.VISIBLE);
			iv_Search.setVisibility(View.VISIBLE);
			btnTitle.setText("Karaoke English");
		} else if (showActionBarTitle == 3) {
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.INVISIBLE);
			et_SearchBar.setVisibility(View.INVISIBLE);
			iv_Search.setVisibility(View.INVISIBLE);
			line.setVisibility(View.INVISIBLE);
			btnTitle.setText("Favorite");
		} else if (showActionBarTitle == 4) {
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.INVISIBLE);
			et_SearchBar.setVisibility(View.INVISIBLE);
			iv_Search.setVisibility(View.INVISIBLE);
			line.setVisibility(View.INVISIBLE);
			btnTitle.setText("More");
		}

		iv_Search.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(isSearchShow == false){
					m_anim = AnimationUtils.loadAnimation(MainActivity.this, R.anim.in_from_right);
					btnTitle.setVisibility(View.GONE);
					iv_Language.setVisibility(View.GONE);
					et_SearchBar.setVisibility(View.VISIBLE);
					line.setVisibility(View.INVISIBLE);
					et_SearchBar.startAnimation(m_anim);
					isSearchShow = true;
				} else {
					m_animEnd = AnimationUtils.loadAnimation(MainActivity.this, R.anim.out_to_right);
					btnTitle.setVisibility(View.VISIBLE);
					iv_Language.setVisibility(View.VISIBLE);
					et_SearchBar.setVisibility(View.INVISIBLE);
					et_SearchBar.startAnimation(m_animEnd);
					InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(et_SearchBar.getWindowToken(), 0);
					line.setVisibility(View.VISIBLE);
					isSearchShow = false;
				}
			}
		});
		
		iv_Language.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				 popupWindowLanguage.showAsDropDown(v, -5, 0);
			}
		});
		
		btnSlide.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean drawerOpen = mDrawerLayout.isDrawerOpen(llDrawer);
				if (drawerOpen == true) {
					mDrawerLayout.closeDrawer(llDrawer);
				} else {
					mDrawerLayout.openDrawer(llDrawer);
				}
				System.out.println("slide button is clicked");
			}
		});
		mActionBar.setCustomView(mCustomView);
		mActionBar.setDisplayShowCustomEnabled(true);

		if (isSearchShow == true) {
			m_animEnd = AnimationUtils.loadAnimation(MainActivity.this, R.anim.out_to_right);
			btnTitle.setVisibility(View.VISIBLE);
			iv_Language.setVisibility(View.INVISIBLE);
			et_SearchBar.setVisibility(View.INVISIBLE);
			line.setVisibility(View.INVISIBLE);
			et_SearchBar.startAnimation(m_animEnd);
			InputMethodManager imm = (InputMethodManager) MainActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(et_SearchBar.getWindowToken(), 0);
			isSearchShow = false;
		}
	}

	@Override
	protected void onRestart() {
		if(goToGalleryScreen == true) {
			LoadFragment("GalleryScreen", new Gallery_Fragment());
			showActionBar(1);
			selectedPos = 1;
			adapter.notifyDataSetChanged();
			goToGalleryScreen = false;
		}
		super.onRestart();
	}
	
	public void LoadFragment(String p_tagName, Fragment p_fragmnt) {
		FragmentManager fmangr = getFragmentManager();
		FragmentTransaction ftrans = fmangr.beginTransaction();
		if(p_tagName.equalsIgnoreCase("homescreen")){
			showScreen = -1;
		} else {
			showScreen = 0;
		}
		fmangr.popBackStack();
		ftrans.replace(R.id.content_frame, p_fragmnt);
		ftrans.commit();
	}
	
	@Override
	public void onBackPressed() {
		if(showScreen == 0) {
			LoadFragment("HomeScreen", new Home_Screen());
			showActionBar(0);
			selectedPos = 0;
			adapter.notifyDataSetChanged();
			showScreen = -1;
		} else if(showScreen == 1) {
			LoadFragment("MoreScreen", new More_Screen());
			showActionBar(4);
			selectedPos = 4;
			adapter.notifyDataSetChanged();
			showScreen = 0;
		} else {
			showDownloadDialog();
		}

	}
	
	@SuppressLint("InflateParams")
	private void showDownloadDialog() {
		m_dialog = new Dialog(this, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(this);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Download = (Button) m_viewDialog.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText("Are you sure to Log out ? ");
		btn_Cancel.setText(this.getString(R.string.lbl_cancel));
		btn_Download.setText("Log out");
		btn_Download.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
				finish();
			}
		});

		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}
	
	public PopupWindow popupWindowLanguage() {
		 
        // initialize a pop up window type
        PopupWindow popupWindow = new PopupWindow(this);
 
        // the drop down list is a list view
        ListView listViewLanguage = new ListView(this);
         
        // set our adapter and pass our pop up window contents
        listViewLanguage.setAdapter(languageAdapter(popUpContents));
        listViewLanguage.setScrollbarFadingEnabled(false);
        listViewLanguage.setVerticalScrollBarEnabled(false);
        listViewLanguage.setHorizontalScrollBarEnabled(false);
        listViewLanguage.setDivider(null);
        listViewLanguage.setDividerHeight(1);
        // set the item click listener
        listViewLanguage.setOnItemClickListener(new LanguageDropdownOnItemClickListener());
        // some other visual settings
        popupWindow.setFocusable(true);
        popupWindow.setWidth(400);
        //popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        // set the list view as pop up window content
        popupWindow.setContentView(listViewLanguage);
        return popupWindow;
    }
	
	private ArrayAdapter<String> languageAdapter(String languageArray[]) {
		 
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, languageArray) {
 
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // setting the ID and text for every items in the list
                String item = getItem(position);
                String[] itemArr = item.split("::");
                String text = itemArr[0];
                String id = itemArr[1];
                // visual settings for the list item
                TextView listItem = new TextView(MainActivity.this);
                listItem.setText(text);
                listItem.setTag(id);
                listItem.setTextSize(20);
                listItem.setGravity(Gravity.CENTER_HORIZONTAL);
                listItem.setPadding(20, 40, 20, 40);
                listItem.setTextColor(Color.WHITE);
                listItem.setBackgroundResource(R.color.bg);
                return listItem;
            }
        };

        return adapter;
    }

	public class LanguageDropdownOnItemClickListener implements OnItemClickListener {

	    String TAG = "LanguageDropdownOnItemClickListener.java";

	    @Override
	    public void onItemClick(AdapterView<?> arg0, View v, int arg2, long arg3) {

	        // get the context and main activity to access variables
	        Context mContext = v.getContext();
	        MainActivity mainActivity = ((MainActivity) mContext);

	        // add some animation when a list item was clicked
	        Animation fadeInAnimation = AnimationUtils.loadAnimation(v.getContext(), android.R.anim.fade_in);
	        fadeInAnimation.setDuration(10);
	        v.startAnimation(fadeInAnimation);

	        // dismiss the pop up
	        mainActivity.popupWindowLanguage.dismiss();

	        // get the text and set it as the button text
	        selectedLanguage = ((TextView) v).getText().toString();
	        System.out.println("selectedLanguage = " + selectedLanguage);
			int arrSize = 0;
			arrSize = Music_Screen.setSongData(Constant.ALL_DATA, selectedLanguage);
	        System.out.println(" is data available " + arrSize);
	        if(arrSize > 0){
				Music_Screen.tvEmpty.setVisibility(View.GONE);
				Music_Screen.adapter.notifyDataSetChanged();
	        } else {
				Music_Screen.tvEmpty.setVisibility(View.VISIBLE);
				Music_Screen.adapter.notifyDataSetChanged();
	        }

        // get the id
	        String selectedItemTag = ((TextView) v).getTag().toString();
	        if(selectedItemTag.equalsIgnoreCase("1")){
	    		btnTitle.setText("Karaoke English");
	        } else if (selectedItemTag.equalsIgnoreCase("2")){
	    		btnTitle.setText("Karaoke Hindi");
	        } else if (selectedItemTag.equalsIgnoreCase("3")) {
	    		btnTitle.setText("Karaoke Tamil");
	        } else {
	    		btnTitle.setText("Karaoke Spanish");
	        }
//	        Toast.makeText(mContext, "Language ID is: " + selectedItemTag, Toast.LENGTH_SHORT).show();
	    }
	}
}
