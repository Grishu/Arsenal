package com.drc.karoake_app;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Lessons_Details_Screen extends Fragment {

//	private Context m_context;
	private TextView tv_LessonTitle, tv_LessonDesc;
//	private ImageView iv_Back, iv_home;
	private Bundle m_bundle;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View m_vView = inflater.inflate(R.layout.lesson_details_layout,
				container, false);
//		m_context = Lessons_Details_Screen.this.getActivity();
		tv_LessonTitle = (TextView) m_vView.findViewById(R.id.tv_lesdetTitle);
		tv_LessonDesc = (TextView) m_vView
				.findViewById(R.id.tv_lesdetDescription);
//		iv_Back = (ImageView) m_vView.findViewById(R.id.iv_lesdetBack);
//		iv_home = (ImageView) m_vView.findViewById(R.id.iv_lesdetHome);
		// Get the lesson title and description.
		m_bundle = this.getArguments();
		if (m_bundle.getString("lessonTitle") != null
				&& m_bundle.getString("lessonDesc") != null) {
			tv_LessonTitle.setText(m_bundle.getString("lessonTitle") + ":");
			tv_LessonDesc.setText(m_bundle.getString("lessonDesc"));
		}

//		iv_Back.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				getActivity().onBackPressed();
//
//			}
//		});

//		iv_home.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				FragmentManager fmngr = getFragmentManager();
//				FragmentTransaction ftrans = fmngr.beginTransaction();
//				fmngr.popBackStack();
//				Home_Screen m_frag = new Home_Screen();
////				ftrans.replace(R.id.fl_fragmentLayout, m_frag);
//				ftrans.commit();
//
//			}
//		});
		return m_vView;
	}
	

}
