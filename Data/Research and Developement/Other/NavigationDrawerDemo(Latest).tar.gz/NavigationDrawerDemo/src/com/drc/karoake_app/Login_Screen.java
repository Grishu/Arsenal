package com.drc.karoake_app;

import java.util.Arrays;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karaoke_app.commonUtils.Constant;
import com.drc.karaoke_app.commonUtils.CustomValidator;
import com.facebook.FacebookException;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;
import com.facebook.widget.LoginButton.OnErrorListener;

public class Login_Screen extends Activity {

	private CommonClass mClass;
	private Context m_context;
	private Button btnLogin;
	private LoginButton btnFbLogin;
	private EditText et_username, et_password;
	private TextView btnForgotPassword;
	private TextView btnSignup;
	private Dialog m_dialog;
	private String m_result, m_loginURL, m_successMsg, m_url;
	private String loginData;
	private String emailID;
	private String storedUserName = " ", StoredPass = " ";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_layout);
		allocateMemory();
		
		if (CommonUtils.getBooleanSharedPref(m_context, getString(R.string.key_remeber), false)) {
			storedUserName	= CommonUtils.getStringSharedPref(m_context, getString(R.string.key_emailid), "");
			StoredPass		= CommonUtils.getStringSharedPref(m_context, getString(R.string.key_password), "");
			et_username.setText(storedUserName);
			et_password.setText(StoredPass);
		}
		
		btnLogin.setOnClickListener(m_onClickListener);
		btnForgotPassword.setOnClickListener(m_onClickListener);
		btnSignup.setOnClickListener(m_onClickListener);
		
		btnFbLogin.setOnErrorListener(new OnErrorListener() {
			@Override
			public void onError(FacebookException error) {
				Log.i("TAG", "Error " + error.getMessage());
			}
		});

		// set permission list, Don't foeget to add email
		btnFbLogin.setReadPermissions(Arrays.asList("email"));

		// session state call back event
		btnFbLogin.setSessionStatusCallback(new Session.StatusCallback() {
			@SuppressWarnings("deprecation")
			@Override
			public void call(Session session, SessionState state, Exception exception) {
				btnFbLogin.setFocusable(true);
				btnFbLogin.setFocusableInTouchMode(true);
				if (session.isOpened()) {
					Log.i("TAG","Access Token"+ session.getAccessToken());
				    Request.executeMeRequestAsync(session, new Request.GraphUserCallback() {
				    	@Override
				        public void onCompleted(GraphUser user,Response response) {
				    		if (user != null) {
				    			Log.i("TAG","User ID "+ user.getId());
				                Log.i("TAG","Email "+ user.asMap().get("email"));
				                Log.i("TAG","profile " );
				                Log.i("TAG","first name "+ user.getFirstName());
				                String fb_id = user.getId();
				                String fb_name = user.getFirstName();
				                if(fb_id.equalsIgnoreCase("null") || fb_id.equals(null)){
				                	System.out.println("facebook id is " + fb_id);
				                } else {
				    				CommonUtils.setStringSharedPref(m_context, "ID", fb_id);
				    				CommonUtils.setStringSharedPref(m_context, "PROFILE_NAME", fb_name);
				    				CommonUtils.setBooleanSharedPref(m_context, getString(R.string.key_login_info), true);
					                Intent intent = new Intent(Login_Screen.this, MainActivity.class);
					                intent.setAction(Constant.ACTIONS_FROM_ACTIVITY);
					                startActivity(intent);
					                finish();
				                }
				    		}
				    	}
				    });
				}
			}
		});
	}
	
	 @Override
	 public void onActivityResult(int requestCode, int resultCode, Intent data) {
	     super.onActivityResult(requestCode, resultCode, data);
	     Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
	 }

	public void allocateMemory() {
		m_context = Login_Screen.this;
		btnLogin	= (Button) findViewById(R.id.btn_login);
		btnFbLogin	= (LoginButton) findViewById(R.id.activity_login_facebook_btn_login);
		et_username = (EditText) findViewById(R.id.et_username);
		et_password = (EditText) findViewById(R.id.et_password);
		btnForgotPassword = (TextView) findViewById(R.id.tv_forgot_pass);
		btnSignup = (TextView) findViewById(R.id.tv_sign_up);
		mClass = new CommonClass();
	}

	OnClickListener m_onClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.tv_sign_up:
				startActivity(new Intent(m_context, Registration_Activity.class));
				break;
			case R.id.tv_forgot_pass:
				showForgetPasswordDialog();
				break;
			case R.id.btn_login:
				if (mClass.CheckNetwork(m_context) == true) {
					CustomValidator.m_isError = false;
					CustomValidator.validateForEmptyValue(et_username, getString(R.string.msg_please_enter_username));
					CustomValidator.validateForEmptyValue(et_password, getString(R.string.msg_please_enter_password));
					if (!CustomValidator.m_isError) {
						if (CommonUtils.getBooleanSharedPref(m_context, getString(R.string.key_remeber), false) == false) {
							String tempUser = et_username.getText().toString();
							if(!storedUserName.equalsIgnoreCase(tempUser)) {
									showSavePasswordDialog();
							}
						} else {
							m_loginURL = "user_login/email/" + et_username.getText().toString() + "/password/" + et_password.getText().toString();
							new callLoginWS().execute(m_loginURL);
						}
					}
				} else {
					Toast.makeText(Login_Screen.this, "Please check internet connection", Toast.LENGTH_LONG).show();
				}
				break;
			default:
				break;
			}
		}
	};

	/**
	 * Call login webservice to authenticate user.
	 */
	private class callLoginWS extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// CommonUtils.showProgress(m_context, getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			// http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/user_login/email/%@/password/%@
			m_result = CommonUtils.parseJSON(params[0]);
			Log.e("Login Result---", m_result);
			try {
				JSONObject m_obj = new JSONObject(m_result);
				JSONObject m_resultObj = m_obj.getJSONObject("result");
				m_successMsg = m_resultObj.getString("result");
				loginData = m_resultObj.getString("data");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return m_successMsg;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			// CommonUtils.dismissDialog();
			
			System.out.println("result = " + result);
			if(result.equalsIgnoreCase("login succesfully")) {
				try {
					JSONObject data = new JSONObject(loginData);
					String profileImage = data.get("image").toString();
					String profileName = data.get("firstname").toString();

					CommonUtils.setStringSharedPref(m_context, "ID", "FROM_NORMAL_USER");
    				CommonUtils.setStringSharedPref(m_context, "PROFILE_IMAGE", profileImage);
    				CommonUtils.setStringSharedPref(m_context, "PROFILE_NAME", profileName);
    				CommonUtils.setBooleanSharedPref(m_context, getString(R.string.key_login_info), true);

					Intent intent = new Intent(m_context, MainActivity.class);
	                intent.setAction(Constant.ACTIONS_FROM_ACTIVITY);
//					intent.putExtra("PROFILE_IMAGE", profileImage);
//					intent.putExtra("PROFILE_NAME", profileName);
					startActivity(intent);
					finish();
				} catch(JSONException e) {
					e.printStackTrace();
				}
			} else {
				Toast.makeText(m_context, result, Toast.LENGTH_LONG).show();
			}
		}
	}

	/**
	 * Parse the facebook login request response and provide details like
	 * id,image icon etc.
	 */
	
	@SuppressLint("InflateParams")
	private void showForgetPasswordDialog() {
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		 m_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.forget_password_layout, null);

		final EditText et_Email = (EditText) m_viewDialog.findViewById(R.id.et_fpEmail);
		ImageView iv_Cancel = (ImageView) m_viewDialog.findViewById(R.id.iv_fpCancel);
		Button btn_Ok = (Button) m_viewDialog.findViewById(R.id.btn_fpOk);

		btn_Ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mClass.CheckNetwork(m_context) == true) {
					CustomValidator.m_isError = false;
					CustomValidator.validateEmail(et_Email, getString(R.string.msg_please_enter_emailid), getString(R.string.msg_please_enter_valid_emailid));

					if (!CustomValidator.m_isError) {
						m_url = "getPassword/Email/" + et_Email.getText().toString().trim();
						emailID = et_Email.getText().toString().trim();
						callForgetPasswordWS m_frgt = new callForgetPasswordWS();
						m_frgt.execute(m_url);
						m_dialog.dismiss();
					}
				} else {
					Toast.makeText(Login_Screen.this, "Please check internet connection", Toast.LENGTH_LONG).show();
				}
			}
		});

		iv_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}

	private class callForgetPasswordWS extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			CommonUtils.showProgress(m_context, getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			String m_result = CommonUtils.parseJSON(params[0]);
			try {
				JSONObject m_obj = new JSONObject(m_result);
				JSONObject m_resultObj = m_obj.getJSONObject("result");
				m_successMsg = m_resultObj.getString("result");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return m_successMsg;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			CommonUtils.dismissDialog();
			System.out.println("result of forgot pass = " + result);
			
			if(result.equalsIgnoreCase("mail sent")){
				Toast.makeText(m_context, "Password sent To " + emailID, Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(m_context, "Email ID does not match", Toast.LENGTH_LONG).show();
			}

		}
	}

	@Override
	public void onStop() {
		super.onStop();
		// Session.getActiveSession().removeCallback(statusCallback);
		if (Session.getActiveSession() != null) {
			Session.getActiveSession().closeAndClearTokenInformation();
		}
	}

	@SuppressLint("InflateParams")
	private void showSavePasswordDialog() {
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Download = (Button) m_viewDialog.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText("Remember Password");
		btn_Cancel.setText("No");
		btn_Download.setText("Yes");
		m_loginURL = "user_login/email/" + et_username.getText().toString() + "/password/" + et_password.getText().toString();
		btn_Download.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				CommonUtils.setStringSharedPref(m_context, getString(R.string.key_emailid), et_username.getText().toString());
				CommonUtils.setStringSharedPref(m_context, getString(R.string.key_password), et_password.getText().toString());
				CommonUtils.setBooleanSharedPref(m_context, getString(R.string.key_remeber), true);
				m_dialog.dismiss();
				new callLoginWS().execute(m_loginURL);
			}
		});
		
		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
				new callLoginWS().execute(m_loginURL);
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}
}