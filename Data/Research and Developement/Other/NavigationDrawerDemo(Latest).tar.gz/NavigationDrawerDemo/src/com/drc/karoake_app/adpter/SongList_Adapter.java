package com.drc.karoake_app.adpter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ImageView.ScaleType;

import com.drc.karaoke_app.Vo.SongListVo;
import com.drc.karaoke_app.commonUtils.ImageLoader;
import com.drc.karoake_app.CommonClass;
import com.drc.karoake_app.R;

public class SongList_Adapter extends BaseAdapter {

	private Context m_cont;
	private ArrayList<SongListVo> m_arrListVo;
//	private ImageLoader m_loader;

	public SongList_Adapter(Context p_cont, ArrayList<SongListVo> p_arrList) {
		m_cont = p_cont;
		m_arrListVo = p_arrList;
//		m_loader = new ImageLoader(m_cont);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return m_arrListVo.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return m_arrListVo.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View m_view = convertView;
		ViewHolder m_holder;
		if (m_view == null) {
			LayoutInflater li		= (LayoutInflater) m_cont.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			m_view					= li.inflate(R.layout.parent_view, parent, false);

			m_holder				= new ViewHolder();
			m_holder.iv_Thumb		= (ImageView) m_view.findViewById(R.id.iv_slPlay);
			m_holder.tv_Title		= (TextView) m_view.findViewById(R.id.tv_slSongTitle);
//			m_holder.tv_Desc		= (TextView) m_view.findViewById(R.id.tv_slDesc);
			m_holder.btnDownload	= (ImageButton) m_view.findViewById(R.id.btn_download);

			m_view.setTag(m_holder);
		} else {
			m_holder = (ViewHolder) m_view.getTag();
		}

		m_holder.iv_Thumb.setScaleType(ScaleType.FIT_XY);
		ImageLoader mImageLoader = new ImageLoader(m_cont,
		CommonClass.getDIP(m_cont, m_cont.getResources().getDimension(R.dimen.IMG_WIDTH)),
		CommonClass.getDIP(m_cont, m_cont.getResources().getDimension(R.dimen.IMG_HEIGHT)), true,R.drawable.ic_play);
		mImageLoader.DisplayImage(m_arrListVo.get(position).getM_sVideoThumb(), m_holder.iv_Thumb);
		m_holder.tv_Title.setText(m_arrListVo.get(position).getM_sTitle());
//		m_holder.tv_Desc.setText(m_arrListVo.get(position).getM_sDescription());
		m_holder.btnDownload.setVisibility(View.INVISIBLE);
		return m_view;
	}

	private class ViewHolder {
		private ImageView iv_Thumb;
		private TextView tv_Title;
		private ImageButton btnDownload;
	}
}
