package com.drc.karoake_app;

public class CustomRow {

	int imageID;
	int imageIDSelected;
	
	public CustomRow(int imageID, int imageIDSelected) {
		this.imageID = imageID;
		this.imageIDSelected = imageIDSelected;
	}

	public int getImageID() {
		return imageID;
	}

	public void setImageID(int imageID) {
		this.imageID = imageID;
	}

	public int getImageIDSelected() {
		return imageIDSelected;
	}

	public void setImageIDSelected(int imageIDSelected) {
		this.imageIDSelected = imageIDSelected;
	}
}
