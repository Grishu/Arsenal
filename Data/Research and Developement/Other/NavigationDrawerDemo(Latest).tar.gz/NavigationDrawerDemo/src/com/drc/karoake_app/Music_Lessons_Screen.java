package com.drc.karoake_app;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.drc.karaoke_app.Vo.LessonsVo;
import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karoake_app.adpter.MusicList_Adapter;

public class Music_Lessons_Screen extends Fragment {

	private Context m_context;
	private ListView lv_musicList;
//	private ImageView iv_back;
	private String m_result;
	private ArrayList<LessonsVo> m_arrList;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Music Lessons");
		View m_view = inflater.inflate(R.layout.music_lessons_layout, container, false);
		m_context = Music_Lessons_Screen.this.getActivity();
		m_arrList = new ArrayList<LessonsVo>();
		lv_musicList = (ListView) m_view.findViewById(R.id.lv_musicList);
//		iv_back = (ImageView) m_view.findViewById(R.id.iv_music_Back);

//		iv_back.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				getActivity().onBackPressed();
//
//			}
//		});

		callMusiceLessonWS m_lesson = new callMusiceLessonWS();
		m_lesson.execute();

		lv_musicList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				FragmentManager fmngr = getFragmentManager();
				FragmentTransaction ftrans = fmngr.beginTransaction();
				Lessons_Details_Screen m_frag = new Lessons_Details_Screen();
				Bundle m_bundle = new Bundle();
				m_bundle.putString("lessonTitle", m_arrList.get(position).getM_lessonTitle());
				m_bundle.putString("lessonDesc", m_arrList.get(position).getM_lessonDesc());
				m_frag.setArguments(m_bundle);
				ftrans.addToBackStack("LessonDetails");
				ftrans.replace(R.id.content_frame, m_frag);
				ftrans.commit();

			}
		});
		return m_view;
	}

	private class callMusiceLessonWS extends AsyncTask<String, Integer, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			CommonUtils.showProgress(m_context, getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			// http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/lessonsJson
			m_result = CommonUtils.parseJSON("lessonsJson");
			LessonsVo m_lVo;
			try {
				JSONObject m_obj = new JSONObject(m_result);
				JSONObject m_resultObj = m_obj.getJSONObject("result");
				JSONArray m_musicArr = m_resultObj
						.getJSONArray("Music Lessons");
				for (int i = 0; i < m_musicArr.length(); i++) {
					JSONObject m_objRes = m_musicArr.getJSONObject(i);
					m_lVo = new LessonsVo();
					m_lVo.setM_lessonTitle(m_objRes.getString("title"));
					m_lVo.setM_lessonDesc(m_objRes.getString("description"));

					m_arrList.add(m_lVo);
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return m_result;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (m_arrList.size() > 0) {
				lv_musicList.setAdapter(new MusicList_Adapter(m_context, m_arrList));
			}
			Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					CommonUtils.dismissDialog();
				}
			}, 1000);
		}
	}

}
