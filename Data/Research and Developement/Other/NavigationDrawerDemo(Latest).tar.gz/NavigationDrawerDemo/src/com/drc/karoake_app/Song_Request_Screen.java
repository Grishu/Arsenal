package com.drc.karoake_app;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karaoke_app.commonUtils.CustomValidator;

public class Song_Request_Screen extends Fragment {

	private Context m_context;
	private CommonClass mClass;
	private Button btn_singUp;
	private String m_url, m_result;
	private EditText et_firstName, et_lastName, et_emailId, et_songName,
			et_movieArtist_Name;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Song Request");
		View m_view			= inflater.inflate(R.layout.song_request_layout, container, false);
		m_context			= Song_Request_Screen.this.getActivity();
		mClass				= new CommonClass();
		btn_singUp			= (Button) m_view.findViewById(R.id.btn_song_request);
		et_firstName		= (EditText) m_view.findViewById(R.id.sret_firstName);
		et_lastName			= (EditText) m_view.findViewById(R.id.sret_lastName);
		et_emailId			= (EditText) m_view.findViewById(R.id.sret_emailId);
		et_songName			= (EditText) m_view.findViewById(R.id.sret_songName);
		et_movieArtist_Name = (EditText) m_view.findViewById(R.id.sret_movieArtName);

		btn_singUp.setOnClickListener(m_OnClickListener);

		return m_view;
	}

	OnClickListener m_OnClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (mClass.CheckNetwork(m_context) == true) {
				switch (v.getId()) {
				case R.id.btn_song_request:
					CustomValidator.m_isError = false;
					CustomValidator.validateForEmptyValue(et_firstName, getString(R.string.msg_please_enter_first_name));
					CustomValidator.validateForEmptyValue(et_lastName, getString(R.string.msg_please_enter_last_name));
					CustomValidator.validateForEmptyValue(et_songName, getString(R.string.msg_please_enter_song_name));
					CustomValidator.validateEmail(et_emailId, getString(R.string.msg_please_enter_email_address), getString(R.string.msg_please_enter_valid_emailid));
					if (!CustomValidator.m_isError) {
						m_url = "sendMail_reply/Fname/"
								+ et_firstName.getText().toString().trim()
								+ "/Lname/"
								+ et_lastName.getText().toString().trim()
								+ "/Email/"
								+ et_emailId.getText().toString().trim() + "/Song/"
								+ et_songName.getText().toString().trim()
								+ "/Movie/"
								+ et_movieArtist_Name.getText().toString().trim();
						String temp = m_url.replaceAll(" ", "%20");
						callSongRequestWS m_songReq = new callSongRequestWS();
						m_songReq.execute(temp);
					}
				break;
				default:
					break;
				}
			} else {
				Toast.makeText(m_context, "Please check internet connection", Toast.LENGTH_LONG).show();
			}
		}
	};

	/**
	 * Webservice for requesting song.
	 */
	private class callSongRequestWS extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			CommonUtils.showProgress(m_context,
					getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			// http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/sendMail_reply/Fname/john/
			// Lname/smith/Email/john@yahoo.com/Song/aaj%20dil%20shayrana/Movie/holiday
			m_result = CommonUtils.parseJSON(params[0]);
			return m_result;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			CommonUtils.dismissDialog();
			Toast.makeText(m_context, "Your request is sent", Toast.LENGTH_LONG).show();
//			getActivity().finish();
			FragmentManager fmangr = getFragmentManager();
			fmangr.popBackStack();
		}
	}
}
