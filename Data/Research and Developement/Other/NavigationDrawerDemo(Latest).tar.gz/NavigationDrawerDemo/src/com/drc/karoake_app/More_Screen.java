package com.drc.karoake_app;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

public class More_Screen extends Fragment {

	private CommonClass mClass;
	private ImageView iv_samplVideo, iv_musicLesson, iv_songRequest, iv_newsCenter, iv_Share;
	private Context m_context;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("More");
		View m_view		= inflater.inflate(R.layout.more_layout, container, false);
		m_context		= More_Screen.this.getActivity();
		mClass			= new CommonClass();
		iv_samplVideo	= (ImageView) m_view.findViewById(R.id.iv_sample_video);
		iv_musicLesson	= (ImageView) m_view.findViewById(R.id.iv_music_lesson);
		iv_songRequest	= (ImageView) m_view.findViewById(R.id.iv_song_request);
		iv_newsCenter	= (ImageView) m_view.findViewById(R.id.iv_news_center);
		iv_Share		= (ImageView) m_view.findViewById(R.id.iv_share);

		iv_samplVideo.setOnClickListener(m_OnClickListener);
		iv_musicLesson.setOnClickListener(m_OnClickListener);
		iv_songRequest.setOnClickListener(m_OnClickListener);
		iv_newsCenter.setOnClickListener(m_OnClickListener);
		iv_Share.setOnClickListener(m_OnClickListener);

		return m_view;
	}

	OnClickListener m_OnClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (mClass.CheckNetwork(m_context) == true) {
				switch (v.getId()) {
				case R.id.iv_sample_video:
					LoadFragmentsScreens("SampleVideoScreen", new Sample_Video_Screen());
					break;
				case R.id.iv_music_lesson:
					LoadFragmentsScreens("MusicLessonScreen", new Music_Lessons_Screen());
					break;
				case R.id.iv_song_request:

					LoadFragmentsScreens("SongsScreen", new Song_Request_Screen());
					break;
				case R.id.iv_news_center:
					LoadFragmentsScreens("News center", new News_Screen());
					break;
				case R.id.iv_share:
					LoadFragmentsScreens("ShareScreen", new Share_Screen());
					break;
				default:
					break;
				}
			} else {
				Toast.makeText(m_context, "Please check internet connection", Toast.LENGTH_LONG).show();
			}
		}
	};

	private void LoadFragmentsScreens(String p_tagName, Fragment p_fragClass) {
		try{
			FragmentManager m_fmngr = getFragmentManager();
			FragmentTransaction m_ftrans = m_fmngr.beginTransaction();
			MainActivity.showScreen = 1;
			m_ftrans.addToBackStack(p_tagName);
			m_ftrans.replace(R.id.content_frame, p_fragClass);
			m_ftrans.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}