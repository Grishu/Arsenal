package com.drc.karoake_app;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karaoke_app.commonUtils.Constant;
import com.drc.karaoke_app.commonUtils.CustomValidator;

public class Registration_Activity extends Activity {

	private static int RESULT_LOAD_IMAGE = 1;
	private CommonClass mClass;
	private Context m_context;
	private Button btn_singUp;
	private ImageView addPhoto;
	private EditText et_firstName, et_lastName, et_email, et_password, et_cofrmPassword;
	private String result, m_countryVal=null;
	private int m_singup_type;
	private String base64_url = "";
	private String imageExt = "";
	private ArrayList<NameValuePair> mPair;
	private Bitmap mBitmap;
//	private Spinner spinner;
//	private ArrayList<String> countries;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.registration_layout);
		m_context		= Registration_Activity.this;
		mClass			= new CommonClass();
		btn_singUp		= (Button) findViewById(R.id.btn_signUp_in_registration);
		addPhoto		= (ImageView) findViewById(R.id.iv_add_image_in_registration);
		et_firstName	= (EditText) findViewById(R.id.et_firstName_in_registration);
		et_lastName		= (EditText) findViewById(R.id.et_lastName_in_registration);
		et_email		= (EditText) findViewById(R.id.et_emailId_in_registration);
		et_password		= (EditText) findViewById(R.id.et_password_in_registration);
		et_cofrmPassword = (EditText) findViewById(R.id.et_confirm_pass_in_registration);
		
//		btn_singUp.setFocusableInTouchMode(true);
//		btn_singUp.requestFocus();
		btn_singUp.setOnClickListener(m_onClickListener);
		addPhoto.setOnClickListener(m_onClickListener);

//		showLanguages();
//		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> parent, View view,
//					int position, long id) {
//				int selectedPosition = spinner.getSelectedItemPosition();
//				Toast.makeText(
//						m_context,
//						"The Item Clicked is " + "---->" + selectedPosition
//								+ countries.get(position).toString(),
//						Toast.LENGTH_LONG).show();
//				m_countryVal = countries.get(position).toString();
//			}

//			@Override
//			public void onNothingSelected(AdapterView<?> parent) {
//				// TODO Auto-generated method stub
//				Log.e("Nothing---", parent.getSelectedItem().toString());
//			}
//		});
	}

	/**
	 * Common Item click listener
	 */
	OnClickListener m_onClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btn_signUp_in_registration:
				if (mClass.CheckNetwork(m_context) == true) {
					m_singup_type = 2;
					CustomValidator.m_isError=false;
					CustomValidator.validateForEmptyValue(et_firstName, getString(R.string.msg_please_enter_first_name));
					CustomValidator.validateForEmptyValue(et_lastName, getString(R.string.msg_please_enter_last_name));
					CustomValidator.validateForEmptyValue(et_password, getString(R.string.msg_please_enter_password));
					CustomValidator.validateForEmptyValue(et_cofrmPassword, getString(R.string.msg_please_confirm_password));
					CustomValidator.validateEmail(et_email, getString(R.string.msg_please_enter_email_address), getString(R.string.msg_please_enter_valid_emailid));
					CustomValidator.validatePassMatch(et_password, et_cofrmPassword, getString(R.string.msg_please_confirm_password), getString(R.string.msg_password_doesn_t_match));
					if (!CustomValidator.m_isError) {
								System.out.println("after et_password");
								mPair = new ArrayList<NameValuePair>();
								mPair.add(new BasicNameValuePair("email", et_email.getText().toString()));
								mPair.add(new BasicNameValuePair("firstname", et_firstName.getText().toString()));	
								mPair.add(new BasicNameValuePair("lastname", et_lastName.getText().toString()));	
								mPair.add(new BasicNameValuePair("sign_type", "" + m_singup_type));	
								mPair.add(new BasicNameValuePair("password", et_password.getText().toString()));	
								mPair.add(new BasicNameValuePair("country", m_countryVal));	
								mPair.add(new BasicNameValuePair("profile_pic", base64_url));	
								mPair.add(new BasicNameValuePair("ext", imageExt));
								callRegistrationWS m_regWs = new callRegistrationWS();
								m_regWs.execute(Constant.BASE_URL);
					} 
				} else {
					Toast.makeText(Registration_Activity.this, "Please check internet connection", Toast.LENGTH_LONG).show();
				}
				break;
			case R.id.iv_add_image_in_registration:
				Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
				break;
			default:
				break;
			}
		}
	};
	
	
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
         
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            System.out.println("image path = " + picturePath);
            imageExt = picturePath.subSequence(picturePath.lastIndexOf("."), picturePath.length()).toString();
            System.out.println("image Ext = " + imageExt);
            
            mBitmap = CommonClass.DecodeFileGetBitmap(Registration_Activity.this, picturePath, 160, 160);
            mBitmap = getRoundBitmap(mBitmap);
            addPhoto.setImageBitmap(mBitmap);
			base64_url = CommonClass.getBase64(m_context, mBitmap);
			System.out.println("base 64 url = " + base64_url);
        }
    }
	
	public static Bitmap getRoundBitmap(Bitmap bitmap) {

		  try {

		   // Bitmap bitmap = BitmapFactory.decodeFile(ImagePath);
		   if (bitmap.getWidth() >= bitmap.getHeight()) {
		    bitmap = Bitmap.createBitmap(bitmap, bitmap.getWidth() / 6 - bitmap.getHeight() / 6, 0, bitmap.getHeight(), bitmap.getHeight());

		    Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		    BitmapShader shader = new BitmapShader(bitmap, TileMode.CLAMP, TileMode.CLAMP);
		    Paint paint = new Paint();
		    paint.setAntiAlias(true);
		    paint.setShader(shader);

		    Canvas c = new Canvas(circleBitmap);
		    c.drawCircle(bitmap.getHeight() / 2, bitmap.getHeight() / 2, bitmap.getHeight() / 2, paint);
		    // imageView.setImageBitmap(circleBitmap);
		    return circleBitmap;

		   } else {
		    bitmap = Bitmap.createBitmap(bitmap, 0, bitmap.getHeight() / 6 - bitmap.getWidth() / 6, bitmap.getWidth(), bitmap.getWidth());

		    Bitmap circleBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
		    BitmapShader shader = new BitmapShader(bitmap, TileMode.CLAMP, TileMode.CLAMP);
		    Paint paint = new Paint();
		    paint.setAntiAlias(true);
		    paint.setShader(shader);

		    Canvas c = new Canvas(circleBitmap);
		    c.drawCircle(bitmap.getWidth() / 2, bitmap.getWidth() / 2, bitmap.getWidth() / 2, paint);

		    // imageView.setImageBitmap(circleBitmap);
		    return circleBitmap;
		   }
		  } catch (Exception e) {
		   return null;
		  }
		 }
	/**
	 * Bind languages in spinner whichever is available in device.
	 */
//	private void showLanguages() {
//
//		Locale[] locale = Locale.getAvailableLocales();
//		countries = new ArrayList<String>();
//		String country;
//		for (Locale loc : locale) {
//			country = loc.getDisplayCountry();
//			if (country.length() > 0 && !countries.contains(country)) {
//				countries.add(country);
//			}
//		}
//		Collections.sort(countries, String.CASE_INSENSITIVE_ORDER);
//
//		ArrayAdapter<String> adapter = new ArrayAdapter<String>(m_context,
//				android.R.layout.simple_spinner_item, countries);
//		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
////		spinner.setPrompt("Language");
////		spinner.setAdapter(adapter);
//
//	}

	 /* private void showSpinLanguages() { final Spinner m_spin = new
	 * Spinner(m_context); ArrayAdapter<CharSequence> adapter =
	 * ArrayAdapter.createFromResource( m_context, R.array.country_list,
	 * android.R.layout.select_dialog_singlechoice);
	 * m_spin.setPrompt("Language");
	 * adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
	 * m_spin.setAdapter(adapter); m_spin.performClick();
	 * m_spin.setOnItemSelectedListener(new OnItemSelectedListener() {
	 * 
	 * @Override public void onItemSelected(AdapterView<?> parent, View view,
	 * int position, long id) { Log.e("Lang--->",
	 * m_spin.getSelectedItem().toString()); }
	 * 
	 * @Override public void onNothingSelected(AdapterView<?> parent) { // TODO
	 * Auto-generated method stub
	 * 
	 * } }); }
	 */
	/**
	 * Call the registration webservice to register user.
	 */
	private class callRegistrationWS extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			CommonUtils.showProgress(m_context, getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			String mString = "";
			try {
				mString = mClass.PostConnection(params[0]+"register/", mPair);
				System.out.println("mString = " + mString);
				JSONObject m_obj = new JSONObject(mString);
				JSONObject m_resultObj = m_obj.getJSONObject("result");
				result = m_resultObj.getString("result");
				System.out.println("result = " + result);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			CommonUtils.dismissDialog();
			finish();
			if(result.equalsIgnoreCase("yes")){
				Toast.makeText(m_context, "Successfully Registered", Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(m_context, result, Toast.LENGTH_LONG).show();
			}
		}
	}
}