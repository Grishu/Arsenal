package com.drc.karaoke_app.Vo;

public class SongListVo {

	private String m_sCategory, m_sLanguage, m_sVideoLink, m_sTitle,
			m_sDescription, m_sVideoThumb, m_status;

	/**
	 * @return the m_sCategory
	 */
	public String getM_sCategory() {
		return m_sCategory;
	}

	/**
	 * @param m_sCategory
	 *            the m_sCategory to set
	 */
	public void setM_sCategory(String m_sCategory) {
		this.m_sCategory = m_sCategory;
	}

	/**
	 * @return the m_sLanguage
	 */
	public String getM_sLanguage() {
		return m_sLanguage;
	}

	/**
	 * @param m_sLanguage
	 *            the m_sLanguage to set
	 */
	public void setM_sLanguage(String m_sLanguage) {
		this.m_sLanguage = m_sLanguage;
	}

	/**
	 * @return the m_sVideoLink
	 */
	public String getM_sVideoLink() {
		return m_sVideoLink;
	}

	/**
	 * @param m_sVideoLink
	 *            the m_sVideoLink to set
	 */
	public void setM_sVideoLink(String m_sVideoLink) {
		this.m_sVideoLink = m_sVideoLink;
	}

	/**
	 * @return the m_sTitle
	 */
	public String getM_sTitle() {
		return m_sTitle;
	}

	/**
	 * @param m_sTitle
	 *            the m_sTitle to set
	 */
	public void setM_sTitle(String m_sTitle) {
		this.m_sTitle = m_sTitle;
	}

	/**
	 * @return the m_sDescription
	 */
	public String getM_sDescription() {
		return m_sDescription;
	}

	/**
	 * @param m_sDescription
	 *            the m_sDescription to set
	 */
	public void setM_sDescription(String m_sDescription) {
		this.m_sDescription = m_sDescription;
	}

	/**
	 * @return the m_sVideoThumb
	 */
	public String getM_sVideoThumb() {
		return m_sVideoThumb;
	}

	/**
	 * @param m_sVideoThumb
	 *            the m_sVideoThumb to set
	 */
	public void setM_sVideoThumb(String m_sVideoThumb) {
		this.m_sVideoThumb = m_sVideoThumb;
	}

	/**
	 * @return the m_status
	 */
	public String getM_status() {
		return m_status;
	}

	/**
	 * @param m_status
	 *            the m_status to set
	 */
	public void setM_status(String m_status) {
		this.m_status = m_status;
	}

}
