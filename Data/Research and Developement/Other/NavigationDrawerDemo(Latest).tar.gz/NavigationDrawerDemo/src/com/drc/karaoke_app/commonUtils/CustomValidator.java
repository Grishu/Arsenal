package com.drc.karaoke_app.commonUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.widget.EditText;

/**
 * This class contain methods for validate inputfield value.
 * 
 */
public class CustomValidator {

	public static boolean m_isError = false;

	/**
	 * This is method to check edit text empty or not.
	 * 
	 * @param p_editText
	 *            - edittext
	 * @param p_nullMsg
	 *            -display message if edittext null
	 */
	public static void validateForEmptyValue(EditText p_editText, String p_nullMsg) {
		clearMassege(p_editText);
		if (p_editText != null && p_nullMsg != null) {
			// use trim() while checking for blank values
			if (TextUtils.isEmpty(p_editText.getText().toString().trim())) {
				m_isError = true;
				p_editText.setFocusableInTouchMode(true);
				p_editText.requestFocus();
				p_editText.setError(p_nullMsg);
			}
		}
	}

	/**
	 * This is method to clear edit text message .
	 * 
	 * @param p_editText
	 *            - edittext
	 * @param p_nullMsg
	 *            -display message if edittext null
	 */
	public static void clearMassege(final EditText p_editText) {
		p_editText.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				p_editText.setError(null);
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			@Override
			public void afterTextChanged(Editable s) {
			}
		});
	}
	
	/**
	 * This is method to check null and valid emailid or not.
	 * 
	 * @param p_editText
	 *            - edittext
	 * @param p_nullMsg
	 *            -display message if edittext null
	 * @param p_validMsg
	 *            -display message if email id not valid.
	 */
	public static void validateEmail(EditText p_editText, String p_nullMsg,
			String p_validMsg) {

		if (p_editText != null && p_nullMsg != null && p_validMsg != null) {
			String txt = p_editText.getText().toString();
			if(Patterns.EMAIL_ADDRESS.matcher(txt).matches() != true) {
				m_isError = true;
				p_editText.setError(p_validMsg);
			}
			validateForEmptyValue(p_editText, p_nullMsg);
		}
	}
	
	
	public static void validatePassMatch(EditText pass, EditText confirmPass, String p_nullMsg, String p_validMsg) {

		if (pass != null && confirmPass != null && p_nullMsg != null && p_validMsg != null) {
			String txt = pass.getText().toString();
			String txt1 = confirmPass.getText().toString();
			if(!txt.equals(txt1)) {
				System.out.println("in to confirm match");
				m_isError = true;
				confirmPass.setError(p_validMsg);
			}
			validateForEmptyValue(confirmPass, p_nullMsg);
		}
	}

	/**
	 * // - Phone Number Validation
	 * 
	 * Method to check if the entered String is a valid phone number of
	 * specified digits Phone number length between 8 to 11
	 * 
	 * @param p_editText
	 *            -edittext
	 * @param p_nullMsg
	 *            -display message if edittext null
	 * @param p_validMsg
	 *            -display message if email id not valid.
	 */
	public static void validatePhoneNumber(EditText p_editText, String p_nullMsg, String p_validMsg) {
		if (p_editText != null && p_nullMsg != null && p_validMsg != null) {
			Pattern m_pattern = Pattern.compile("^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{2,5})$");
			Matcher m_matcher = m_pattern.matcher(p_editText.getText().toString().trim());
			if (!m_matcher.matches()) {
				m_isError = true;
				p_editText.setError(p_validMsg);
			}
		}
	}
}