package com.drc.karaoke_app.Vo;

public class LessonsVo {

	private String m_lessonTitle, m_lessonDesc;

	public String getM_lessonTitle() {
		return m_lessonTitle;
	}

	public void setM_lessonTitle(String m_lessonTitle) {
		this.m_lessonTitle = m_lessonTitle;
	}

	public String getM_lessonDesc() {
		return m_lessonDesc;
	}

	public void setM_lessonDesc(String m_lessonDesc) {
		this.m_lessonDesc = m_lessonDesc;
	}

}
