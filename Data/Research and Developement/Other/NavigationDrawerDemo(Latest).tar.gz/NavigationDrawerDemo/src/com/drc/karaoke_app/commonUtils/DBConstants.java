package com.drc.karaoke_app.commonUtils;

public class DBConstants {
	public static final class DB {
		// Database Version
		public static final int DATABASE_VERSION = 1;
		// Database Name
		public static final String DATABASE_NAME = "favorites";

	}

	public static final class TABLE {
		// Contacts table name
		public static final String FAVORITE = "favorites";

	}

	public static final class FAVORITES {

	}
}