package com.drc.karoake_app.adpter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.drc.karaoke_app.Vo.LessonsVo;
import com.drc.karoake_app.R;

public class MusicList_Adapter extends BaseAdapter {

	private Context m_context;
	private ArrayList<LessonsVo> m_lessonArry;

	public MusicList_Adapter(Context p_context, ArrayList<LessonsVo> p_arrLesson) {
		m_context = p_context;
		m_lessonArry = p_arrLesson;
	}

	@Override
	public int getCount() {
		return m_lessonArry.size();
	}

	@Override
	public Object getItem(int position) {
		return m_lessonArry.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View m_view = convertView;
		ViewHolder m_holder;
		if (m_view == null) {
			LayoutInflater li = (LayoutInflater) m_context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			m_view = li.inflate(R.layout.lessons_layout, parent, false);

			m_holder = new ViewHolder();
			m_holder.m_tvTitle = (TextView) m_view
					.findViewById(R.id.tv_lesnTitle);

			m_view.setTag(m_holder);
		} else {
			m_holder = (ViewHolder) m_view.getTag();
		}

		m_holder.m_tvTitle.setText(m_lessonArry.get(position)
				.getM_lessonTitle().toString());
		return m_view;
	}

	private class ViewHolder {
		TextView m_tvTitle;
	}

}
