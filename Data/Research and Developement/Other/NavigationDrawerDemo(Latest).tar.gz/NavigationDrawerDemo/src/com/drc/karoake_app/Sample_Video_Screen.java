package com.drc.karoake_app;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.drc.karaoke_app.Vo.SongListVo;
import com.drc.karaoke_app.commonUtils.CommonUtils;
import com.drc.karaoke_app.commonUtils.CustomValidator;
import com.drc.karoake_app.adpter.SongList_Adapter;

public class Sample_Video_Screen extends Fragment {

	private Context m_context;
//	private CommonClass mClass;
	private View m_view;
//	private LoadMoreListView lv_smplLoadList;
	private ListView lstSampleVideo;
	private String m_slanguage = "English", m_sresult, m_sSongUrl,
			m_sSearchUrl;
	private ArrayList<SongListVo> m_smplarrList;
	private SongList_Adapter m_smplAdapter;
	private int m_spageVal = 1;
//	private Dialog m_smplDialog;
	private boolean m_isSearch = false;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Sample Video");
		m_view			= inflater.inflate(R.layout.music_list_layout, container, false);
		m_context		= Sample_Video_Screen.this.getActivity();
//		mClass			= new CommonClass();
		lstSampleVideo	= (ListView) m_view.findViewById(R.id.lst_mzList);
		m_smplarrList	= new ArrayList<SongListVo>();
		m_sSongUrl		= "categoryJson/caption/sample/language/" + m_slanguage + "/currentindex/" + m_spageVal;
		callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
		m_musicWS.execute(m_sSongUrl);

		m_smplAdapter = new SongList_Adapter(m_context, m_smplarrList);
		lstSampleVideo.setAdapter(m_smplAdapter);

//		lv_smplLoadList.setOnLoadMoreListener(new OnLoadMoreListener() {

//			@Override
//			public void onLoadMore() {
//				if (m_isSearch) {
//					callSearchWS();
//				} else {
//					callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
//					m_musicWS.execute(m_sSongUrl);
//				}
//			}
//		});
		
		lstSampleVideo.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				startActivity(new Intent(m_context, PlaySampleVideoActivity.class)
						.putExtra("sample_video", m_smplarrList.get(position)
								.getM_sVideoLink().toString()));

			}
		});



//		et_smplSearchBar.setOnKeyListener(new OnKeyListener() {
//			public boolean onKey(View view, int keyCode, KeyEvent event) {
//				if ((event.getAction() == KeyEvent.ACTION_DOWN)
//						&& (keyCode == KeyEvent.KEYCODE_ENTER)) {
//					m_smplAnimEnd = AnimationUtils.loadAnimation(m_context,
//							R.anim.out_to_right);
//					et_smplSearchBar.setVisibility(View.INVISIBLE);
//					et_smplSearchBar.startAnimation(m_smplAnimEnd);
//					InputMethodManager imm = (InputMethodManager) m_context
//							.getSystemService(Context.INPUT_METHOD_SERVICE);
//					imm.hideSoftInputFromWindow(
//							et_smplSearchBar.getWindowToken(), 0);
//					callSearchWS();
//					return true;
//				} else {
//					return false;
//				}
//			}
//		});
		return m_view;
	}

	/**
	 * Common Click listener
	 */
//	OnClickListener m_OnClickListener = new OnClickListener() {
//
//		@Override
//		public void onClick(View v) {
//			switch (v.getId()) {
//			case R.id.iv_mzLanguage:
//
//				showLanguages();
//				break;
//			case R.id.iv_mzSearch:
//				m_smplAnim = AnimationUtils.loadAnimation(m_context,
//						R.anim.in_from_right);
//				et_smplSearchBar.setVisibility(View.VISIBLE);
//				et_smplSearchBar.startAnimation(m_smplAnim);
//
//				break;
//			case R.id.btn_english:
//				m_slanguage = "English";
//				setButtonText(m_slanguage);
//				m_smplarrList.clear();
//				if (m_isSearch) {
//					callSearchWS();
//				} else {
//					m_sSongUrl = "categoryJson/caption/sample/language/"
//							+ m_slanguage + "/currentindex/" + m_spageVal;
//					callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
//					m_musicWS.execute(m_sSongUrl);
//				}
//				m_smplDialog.dismiss();
//				break;
//			case R.id.btn_hindi:
//				m_slanguage = "Hindi";
//				setButtonText(m_slanguage);
//				m_smplarrList.clear();
//				if (m_isSearch) {
//					callSearchWS();
//				} else {
//					m_sSongUrl = "categoryJson/caption/sample/language/"
//							+ m_slanguage + "/currentindex/" + m_spageVal;
//					callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
//					m_musicWS.execute(m_sSongUrl);
//				}
//				m_smplDialog.dismiss();
//				break;
//			case R.id.btn_French:
//				m_slanguage = "French";
//				setButtonText(m_slanguage);
//				m_smplarrList.clear();
//				if (m_isSearch) {
//					callSearchWS();
//				} else {
//					m_sSongUrl = "categoryJson/caption/sample/language/"
//							+ m_slanguage + "/currentindex/" + m_spageVal;
//					callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
//					m_musicWS.execute(m_sSongUrl);
//				}
//				m_smplDialog.dismiss();
//				break;
//			case R.id.btn_Tamil:
//				m_slanguage = "Tamil";
//				setButtonText(m_slanguage);
//				m_smplarrList.clear();
//				if (m_isSearch) {
//					callSearchWS();
//				} else {
//					m_sSongUrl = "categoryJson/caption/sample/language/"
//							+ m_slanguage + "/currentindex/" + m_spageVal;
//					callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
//					m_musicWS.execute(m_sSongUrl);
//				}
//				m_smplDialog.dismiss();
//				break;
//			default:
//				break;
//			}
//		}
//	};

	/**
	 * Display language dialog to select language and get the video's based on
	 * language.
	 */
//	private void showLanguages() {
//		m_smplDialog = new Dialog(m_context, R.style.Dialog_No_Border);
//		m_smplDialog.setCancelable(false);
//		LayoutInflater m_inflater = LayoutInflater.from(m_context);
//		final View m_viewDialog = m_inflater.inflate(R.layout.language_dialog, null);
//
//		Animation bottomUp = AnimationUtils.loadAnimation(m_context, R.anim.bottom_up);
//
//		m_viewDialog.startAnimation(bottomUp);
//		m_viewDialog.setVisibility(View.VISIBLE);
//
//		Button btn_English, btn_Hindi, btn_French, btn_Tamil, btn_Cancel;
//
//		btn_English = (Button) m_viewDialog.findViewById(R.id.btn_english);
//		btn_Hindi = (Button) m_viewDialog.findViewById(R.id.btn_hindi);
//		btn_French = (Button) m_viewDialog.findViewById(R.id.btn_French);
//		btn_Tamil = (Button) m_viewDialog.findViewById(R.id.btn_Tamil);
//		btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cancel);
//
//		btn_English.setOnClickListener(m_OnClickListener);
//		btn_Hindi.setOnClickListener(m_OnClickListener);
//		btn_French.setOnClickListener(m_OnClickListener);
//		btn_Tamil.setOnClickListener(m_OnClickListener);
//		btn_Cancel.setOnClickListener(m_OnClickListener);
//
//		btn_Cancel.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				Animation bottomDown = AnimationUtils.loadAnimation(m_context, R.anim.bottom_down);
//
//				m_viewDialog.startAnimation(bottomDown);
//				m_viewDialog.setVisibility(View.INVISIBLE);
//				m_smplDialog.dismiss();
//			}
//		});
//		m_smplDialog.setContentView(m_viewDialog);
//		m_smplDialog.show();
//
//	}

	/**
	 * Change the title of header according to language changed.
	 * 
	 * @param p_language
	 *            -Selected language.
	 */
//	private void setButtonText(String p_language) {
//		btn_smplTitle.setText(getString(R.string.app_name).toUpperCase()
//				+ "  	" + p_language.toUpperCase());
//	}

	/**
	 * Call the search webservice for searching video's.
	 */
	@SuppressWarnings("unused")
	private void callSearchWS() {
		m_smplarrList.clear();
		CustomValidator.m_isError = false;
//		CustomValidator.validateForEmptyValue(et_smplSearchBar,
//				"Please enter value");
		if (!CustomValidator.m_isError) {
			// http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/categoryJson/caption/sample/language/english/search_text/test
//			m_sSearchUrl = "categoryJson/caption/sample/language/"
//					+ m_slanguage + "/search_text/"
//					+ et_smplSearchBar.getText().toString().trim();
//			m_isSearch = true;
			callSampleMusicListWS m_musicWS = new callSampleMusicListWS();
			m_musicWS.execute(m_sSearchUrl);
		}
	}

	/**
	 * Request the music list webservice.
	 */
	
	private class callSampleMusicListWS extends
			AsyncTask<String, Integer, String> {

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			CommonUtils.showProgress(m_context,
					getString(R.string.msg_please_wait));
		}

		@Override
		protected String doInBackground(String... params) {
			// http://180.211.110.195/php-projects/serv/index.php?r=vediodesc/categoryJson/caption/normal/language/english/currentindex/1
			m_sresult = CommonUtils.parseJSON(params[0]);
			try {
				JSONObject m_obj = new JSONObject(m_sresult);
				JSONObject m_resultObj = m_obj.getJSONObject("result");
				JSONArray m_arrYoutube = m_resultObj.getJSONArray("youtube");
				SongListVo m_sVo;
				if (m_arrYoutube.length() > 0) {
					for (int i = 0; i < m_arrYoutube.length(); i++) {
						JSONObject m_details = m_arrYoutube.getJSONObject(i);

						m_sVo = new SongListVo();
						m_sVo.setM_sCategory(m_details.getString("category"));
						m_sVo.setM_sLanguage(m_details.getString("language"));
						m_sVo.setM_sVideoLink(m_details.getString("link"));
						m_sVo.setM_sTitle(m_details.getString("title"));
						m_sVo.setM_sDescription(m_details.getString("description"));
						m_sVo.setM_sVideoThumb(m_details.getString("thumbnail"));

						m_smplarrList.add(m_sVo);
					}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return m_sresult;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			m_smplAdapter.notifyDataSetChanged();
			if (!m_isSearch) {
				m_spageVal++;
			}
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					CommonUtils.dismissDialog();
				}
			}, 1000);
		}
	}
}
