package com.drc.karoake_app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class Play_Music_Screen extends Activity {

	private Dialog m_dialog;
	private Context m_context;
	private ImageView iv_muzcInfo, iv_muzcStart;
	String fileName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.play_music_layout);
		m_context = Play_Music_Screen.this;
//		iv_muzcBack = (ImageView) findViewById(R.id.iv_pmlBack);
		iv_muzcInfo = (ImageView) findViewById(R.id.iv_pmlInfo);
		iv_muzcStart = (ImageView) findViewById(R.id.iv_pmlStart);

//		iv_muzcBack.setOnClickListener(m_onClickListener);
		iv_muzcInfo.setOnClickListener(m_onClickListener);
		iv_muzcStart.setOnClickListener(m_onClickListener);
		
		fileName = getIntent().getStringExtra("file_name");
	}

	OnClickListener m_onClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
//			case R.id.iv_pmlBack:
//				finish();
//				break;

			case R.id.iv_pmlInfo:
//				startActivity(new Intent(m_context, Info_Screen.class));
				showDownloadDialog();

				break;
			case R.id.iv_pmlStart:
				finish();
				startActivity(new Intent(m_context, Play_Favourite_Screen.class).putExtra("URL", fileName));
				break;
			default:
				break;
			}
		}
	};
	
	@SuppressLint("InflateParams")
	public void showDownloadDialog() {
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.info_layout, null);
		String m_infodetails = "&#8226; Go Music Lesson to learn singing techincs. <br/>"
				+ "&#8226; You need silent place for good recording. <br/> &#8226; Start Singing...<br/>"
				+ "&#8226; Your voice will be mixed with the song just like you recorded in professional studio.<br/>"
				+ "&#8226; Once you done with singing please press done button to save your recording.<br/>"
				+ "&#8226; Your Recording will save to gallery. <br/>"
				+ "&#8226; If recording not done properly you can delete that recording also.<br/>"
				+ "&#8226; Go to gallery to Share your Recording. <br/>"
				+ "&#8226; You can share your recording on Facebook. <br/>"
				+ "&#8226; You can upload your recording to youtube also.<br/>"
				+ "&#8226; You can send recording via email.<br/><br/> "
				+ "WE WISH YOU GOOD LUCK FOR SINGING CAREER";

		TextView tv_Info = (TextView) m_viewDialog.findViewById(R.id.tv_infoDetails);
		tv_Info.setText(Html.fromHtml(m_infodetails));
		
		ImageView iv_infoClose = (ImageView) m_viewDialog.findViewById(R.id.iv_infoClose);
		iv_infoClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}
}
