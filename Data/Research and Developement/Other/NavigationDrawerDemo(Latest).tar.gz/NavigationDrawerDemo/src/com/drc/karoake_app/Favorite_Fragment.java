package com.drc.karoake_app;

import java.io.File;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Display;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.baoyz.swipemenulistview.SwipeMenuListView.OnMenuItemClickListener;
import com.baoyz.swipemenulistview.SwipeMenuListView.OnSwipeListener;
import com.drc.karaoke_app.commonUtils.Constant;

@SuppressLint("InflateParams")
public class Favorite_Fragment extends Fragment {

	private SwipeMenuListView mListView;
	SwipeMenu sMenu = null;
	private Context m_context;
	// public static ExpandableListView expandbleList;
	private TextView tvEmpty;
	private Dialog m_dialog;
	private File root;
	private ArrayList<File> parentItems;
	private ArrayList<File> imageItems;
	private ArrayList<String> childarr;
	private String fileName = "";
	private String imageName = "";
	private int deleteFIlePos = -1;
//	private ExpandListAdapter adapter = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		MainActivity.btnTitle.setText("Favourite");
		View m_view = inflater.inflate(R.layout.favorite_layout, container, false);
		m_context = Favorite_Fragment.this.getActivity();
		tvEmpty = (TextView) m_view.findViewById(R.id.tv_no_record);
		// expandbleList = (ExpandableListView)
		// m_view.findViewById(R.id.exp_slide_items_in_favorite);
		mListView = (SwipeMenuListView) m_view.findViewById(R.id.listView);
		sMenu = new SwipeMenu(m_context);
		parentItems = new ArrayList<File>();
		imageItems = new ArrayList<File>();
		childarr = new ArrayList<String>();
		root = new File(Constant.PLAY_VIDEO.VIDEO_PATH);
		getfile(root);
		getImageFile(root);
		childarr.add("1");
		if (parentItems.isEmpty()) {
			tvEmpty.setVisibility(View.VISIBLE);
		} else {
			tvEmpty.setVisibility(View.GONE);
			adapter = new AppAdapter();
			mListView.setAdapter(adapter);
		}
		
		// step 1. create a MenuCreator
		SwipeMenuCreator creator = new SwipeMenuCreator() {
			@Override
			public void create(SwipeMenu menu) {
				// create "open" item
				SwipeMenuItem openItem = new SwipeMenuItem(m_context);
				// set item background
				openItem.setBackground(new ColorDrawable(m_context.getResources().getColor(R.color.child_bg)));
				// set item width
				openItem.setWidth(dp2px(90));
				
//				// set item title
//				openItem.setTitle("Recorder");
//				// set item title fontsize
//				openItem.setTitleSize(18);
//				// set item title font color
//				openItem.setTitleColor(Color.WHITE);

				// set a icon
				openItem.setIcon(R.drawable.play_record);
				
				// add to menu
				menu.addMenuItem(openItem);

				// create "delete" item
				SwipeMenuItem deleteItem = new SwipeMenuItem(m_context);
				// set item background
				deleteItem.setBackground(new ColorDrawable(m_context.getResources().getColor(R.color.child_bg))); 
				// set item width
				deleteItem.setWidth(dp2px(90));
				// set a icon
				deleteItem.setIcon(R.drawable.delete);
				// add to menu
				
				menu.addMenuItem(deleteItem);
			}
		};
		
		// set creator
		mListView.setMenuCreator(creator);
		
		// step 2. listener item click event
		mListView.setOnMenuItemClickListener(new OnMenuItemClickListener() {
			@Override
			public void onMenuItemClick(int position, SwipeMenu menu, int index) {
				switch (index) {
				case 0:
					// open
					playAndRecord();
					Toast.makeText(m_context, position + " play and recording is clicked", Toast.LENGTH_LONG).show();
					break;
				case 1:
					showDeleteDialog();
					// delete
					// delete(item);
//					mAppList.remove(position);
//					mAdapter.notifyDataSetChanged();
					Toast.makeText(m_context, position + " delete is clicked", Toast.LENGTH_LONG).show();
					break;
				}
			}
		});

	
		// set SwipeListener
		mListView.setOnSwipeListener(new OnSwipeListener() {
			@Override
			public void onSwipeStart(int position) {
				
			}

			@Override
			public void onSwipeEnd(int position) {
				System.out.println("swipping is stoped");
			}
		});

		// other setting
		// listView.setCloseInterpolator(new BounceInterpolator());
		
		return m_view;
	}

	public ArrayList<File> getfile(File dir) {
		parentItems.clear();
		File listFile[] = dir.listFiles();
		if (listFile != null && listFile.length > 0) {
			for (int i = listFile.length - 1; i >= 0; i--) {

				if (!listFile[i].isDirectory()) {
					if (listFile[i].getName().endsWith(".mp4")
							|| listFile[i].getName().endsWith(".3gp")
							|| listFile[i].getName().endsWith(".mkv")) {
						parentItems.add(listFile[i]);
					}
				}
			}
		}
		return parentItems;
	}

	public ArrayList<File> getImageFile(File dir) {
		imageItems.clear();
		File listImageFile[] = dir.listFiles();
		if (listImageFile != null && listImageFile.length > 0) {
			for (int i = listImageFile.length - 1; i >= 0; i--) {

				if (!listImageFile[i].isDirectory()) {
					if (listImageFile[i].getName().endsWith(".png")) {
						imageItems.add(listImageFile[i]);
					}
				}
			}
		}
		return imageItems;
	}
	
	private void playAndRecord(){
		Intent intent = new Intent(Favorite_Fragment.this.getActivity(), Play_Music_Screen.class);
		intent.putExtra("file_name", fileName);
		startActivity(intent);
	}

	private void showDeleteDialog() {
		m_dialog = new Dialog(m_context, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(m_context);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Delete = (Button) m_viewDialog.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText(getResources().getString(R.string.lbl_sure_to_delete_video));
		btn_Cancel.setText(getString(R.string.lbl_cancel));
		btn_Delete.setText(getString(R.string.lbl_delete));
		btn_Delete.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				boolean deleted = deleteFile(fileName, imageName);
				System.out.println("file name = " + fileName);
				System.out.println("image name = " + imageName);
				if (deleted == true) {
					m_dialog.dismiss();
				}
			}
		});

		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_dialog.dismiss();
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}

	public boolean deleteFile(String videoFileName, String imageName) {
		String selectedFilePath = Constant.PLAY_VIDEO.VIDEO_PATH
				+ videoFileName;
		System.out.println("image path = " + imageName);

		File fileVideo = new File(selectedFilePath);
		File fillImage = new File(imageName);

		boolean deleted = fileVideo.delete();
		boolean deletedImage = fillImage.delete();
		System.out.println("image is deleted = " + deletedImage);
		if (deleted == true) {
			parentItems.remove(deleteFIlePos);
			imageItems.remove(deleteFIlePos);
			adapter.notifyDataSetChanged();
			if (parentItems.isEmpty()) {
				tvEmpty.setVisibility(View.VISIBLE);
			} else {
				tvEmpty.setVisibility(View.GONE);
			}
		}
		return deleted;
	}

	private AppAdapter adapter;
	class AppAdapter extends BaseAdapter {
		
		int selectedPos = 0;

		@Override
		public int getCount() {
			return parentItems.size();
		}

		@Override
		public File getItem(int position) {
			return parentItems.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = View.inflate(m_context, R.layout.item_list_app, null);
				new ViewHolder(convertView);
			}
			ViewHolder holder = (ViewHolder) convertView.getTag();
			Drawable d = (Drawable) Drawable.createFromPath(imageItems.get(position).toString());
			holder.iv_icon.setImageDrawable(d);
			holder.tv_name.setText(trimName(parentItems.get(position).toString()));
			
			convertView.setOnTouchListener(new OnTouchListener() {
				@SuppressLint("ClickableViewAccessibility")
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					fileName = trimName(parentItems.get(position).toString());
					imageName = imageItems.get(position).toString();
					deleteFIlePos = position;
					return false;
				}
			});
			
			return convertView;
		}
		
		class ViewHolder {
			ImageView iv_icon;
			TextView tv_name;

			public ViewHolder(View view) {
				iv_icon = (ImageView) view.findViewById(R.id.iv_icon);
				tv_name = (TextView) view.findViewById(R.id.tv_name);
				view.setTag(this);
			}
		}
	}

	public String trimName(String str) {
		String temp = str.substring(str.lastIndexOf("/") + 1, str.length());
		return temp.replace("%20", " ");
	}

	private int dp2px(int dp) {
		return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
	}
}