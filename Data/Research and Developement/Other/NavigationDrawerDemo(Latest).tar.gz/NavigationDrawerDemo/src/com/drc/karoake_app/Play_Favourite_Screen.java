package com.drc.karoake_app;

import java.io.File;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.drc.karaoke_app.commonUtils.Constant;

public class Play_Favourite_Screen extends Activity {

	private String SONG_NAME;
	private String getFile;
	private String outputFile = null;
	private MediaRecorder myAudioRecorder;
	private VideoView m_video;
	private Dialog m_dialog;
	private ImageButton btnPlay;
	private ImageButton btnStop;
	private ImageButton btnRecord;
	private int count = 1;
	private boolean isStoped = false;
	private boolean isRecorderCancel = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.play_sample_video_layout);
		allocateMemory();
		
		playVideo(getFile);
//		playRecorder();
		
		btnPlay.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(!m_video.isPlaying()){
					playVideo(getFile);
				}
			}
		});
		
		btnStop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(m_video.isPlaying()){
					stop();
				}
			}
		});
		
		btnRecord.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(myAudioRecorder == null){
					playVideo(getFile);
				}
//				playRecorder();
			}
		});
	}
	
	public void allocateMemory(){
		m_video			= (VideoView) findViewById(R.id.videoView1);
		btnPlay			= (ImageButton) findViewById(R.id.btn_play);
		btnStop			= (ImageButton) findViewById(R.id.btn_stop);
		btnRecord		= (ImageButton) findViewById(R.id.btn_record);
		getFile			= getIntent().getStringExtra("URL");
		SONG_NAME		= trimName(getFile);
		Log.e("Url---", SONG_NAME);
	}
	
	public void playVideo(String songName){
		MediaController mediaController = new MediaController(this);
		m_video.setMediaController(mediaController);
		mediaController.setMediaPlayer(m_video);
		mediaController.setAnchorView(m_video);
		m_video.setVideoPath(Constant.PLAY_VIDEO.VIDEO_PATH + songName);
		
		m_video.requestFocus();
		m_video.start();
		playRecorder();
		m_video.setOnCompletionListener(new OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer mp) {
				showSaveDialog();
			}
		});
	}
	
	public void playRecorder(){
		try {
			count = 1;
			isRecorderCancel = false;
			File dir = new File(Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH);
			if(!dir.exists() && !dir.isDirectory()){
				dir.mkdir();
				System.out.println("directory is created");
			}
			
			String tempPath = Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH + SONG_NAME + ".mp4";
			File f = new File(tempPath);
			if(!f.exists()){
				outputFile = Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH + SONG_NAME + ".mp4";
				System.out.println("output file in if = " + outputFile);
			} else {
				while(count >= 0){
					if(checkFileName(Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH + SONG_NAME + count + ".mp4") == true){
						count++;
						System.out.println(" count = " + count);
					} else {
						outputFile = Constant.PLAY_VIDEO.RECORDED_FOLDER_PATH + SONG_NAME + count + ".mp4";
						System.out.println("output file in else = " + outputFile);
						count = -1;
					}
				}
			}
				myAudioRecorder = new MediaRecorder();
				myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
				myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
				myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
				myAudioRecorder.setOutputFile(outputFile);
				myAudioRecorder.prepare();
				myAudioRecorder.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkFileName(String fileName){
		File f = new File(fileName);
		if(f.exists()){
			return true;
		} else {
			return false;
		}
	}

	public void stop() {
		try {
			if(isStoped == false) {
				isStoped = true;
				m_video.pause();
				if (myAudioRecorder != null) {
					myAudioRecorder.stop();
					myAudioRecorder = null;
				}
				showSaveDialog();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressLint("InflateParams")
	private void showSaveDialog() {
		m_dialog = new Dialog(Play_Favourite_Screen.this, R.style.Dialog_No_Border);
		m_dialog.setCancelable(false);
		LayoutInflater m_inflater = LayoutInflater.from(Play_Favourite_Screen.this);
		View m_viewDialog = m_inflater.inflate(R.layout.common_dialog_layout, null);

		Button btn_Save = (Button) m_viewDialog.findViewById(R.id.btn_cdlDownload);
		Button btn_Cancel = (Button) m_viewDialog.findViewById(R.id.btn_cdlCancel);
		TextView tv_Message = (TextView) m_viewDialog.findViewById(R.id.tv_cdlMessage);
		tv_Message.setText(getResources().getString(R.string.lbl_want_to_save));
		btn_Cancel.setText(getString(R.string.lbl_cancel));
		btn_Save.setText(getString(R.string.lbl_save));
		btn_Save.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.e("Karaoke", "video is saved");
					isStoped = false;
					Toast.makeText(Play_Favourite_Screen.this, "Recorded file is saved", Toast.LENGTH_LONG).show();
					MainActivity.goToGalleryScreen = true;
					m_dialog.dismiss();
					finish();
			}
		});
		
		btn_Cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					File recordedFile = new File(outputFile);
					recordedFile.delete();
					m_dialog.dismiss();
					isStoped = false;
					isRecorderCancel = true;

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		m_dialog.setContentView(m_viewDialog);
		m_dialog.show();
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK) {
	    	if(isRecorderCancel == false){
		    	stop();
		    	return true;
	    	}
	    }
	    return super.onKeyDown(keyCode, event);
	}
	
//	private void LoadFragmentsScreens(String p_tagName, Fragment p_fragClass) {
//		FragmentManager m_fmngr = getFragmentManager();
//		FragmentTransaction m_ftrans = m_fmngr.beginTransaction();
//		m_ftrans.addToBackStack(p_tagName);
//		m_ftrans.replace(R.id.content_frame, p_fragClass);
//		m_ftrans.commit();
//	}
	
	public String trimName(String str) {
		String temp = str.substring(0, str.lastIndexOf("."));
		return temp.replace("%20", " ");
	}

//	public static byte[] readFile(String path){
//		File file = new File(path);
//	    int size = (int) file.length();
//	    byte[] bytes = new byte[size];
//	    try {
//	        BufferedInputStream buf = new BufferedInputStream(new FileInputStream(file));
//	        buf.read(bytes, 0, bytes.length);
//	        buf.close();
//	    } catch (FileNotFoundException e) {
//	        // TODO Auto-generated catch block
//	        e.printStackTrace();
//	    } catch (IOException e) {
//	        // TODO Auto-generated catch block
//	        e.printStackTrace();
//	    }
//	    return bytes;
//	}
//	
//	public static void writeBytesToFile(File theFile, byte[] bytes)
//			throws IOException {
//		BufferedOutputStream bos = null;
//
//		try {
//			FileOutputStream fos = new FileOutputStream(theFile);
//			bos = new BufferedOutputStream(fos);
//			bos.write(bytes);
//		} finally {
//			if (bos != null) {
//				try {
//					// flush and close the BufferedOutputStream
//					bos.flush();
//					bos.close();
//				} catch (Exception e) {
//				}
//			}
//		}
//	}
//	
//	public String convertFile(String filePath){
//		byte[] newByte = readFile(filePath);
//		String newPath = Constant.PLAY_VIDEO.VIDEO_PATH + "temp.mp4";
//		File VIDEO_FILE = new File(newPath);
//
//		try {
//			writeBytesToFile(VIDEO_FILE, newByte);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return newPath;
//	}
}