package com.drc.karoake_app;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class Info_Screen extends Activity {

	private TextView tv_Info;
//	private Context m_context;
	private ImageView iv_infoClose;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.info_layout);
		tv_Info = (TextView) findViewById(R.id.tv_infoDetails);
		iv_infoClose = (ImageView) findViewById(R.id.iv_infoClose);

		String m_infodetails = "&#8226; Go Music Lesson to learn singing techincs. <br/>"
				+ "&#8226; You need silent place for good recording. <br/> &#8226; Start Singing...<br/>"
				+ "&#8226; Your voice will be mixed with the song just like you recorded in professional studio.<br/>"
				+ "&#8226; Once you done with singing please press done button to save your recording.<br/>"
				+ "&#8226; Your Recording will save to gallery. <br/>"
				+ "&#8226; If recording not done properly you can delete that recording also.<br/>"
				+ "&#8226; Go to gallery to Share your Recording. <br/>"
				+ "&#8226; You can share your recording on Facebook. <br/>"
				+ "&#8226; You can upload your recording to youtube also.<br/>"
				+ "&#8226; You can send recording via email.<br/><br/> "
				+ "WE WISH YOU GOOD LUCK FOR SINGING CAREER";
		tv_Info.setText(Html.fromHtml(m_infodetails));

		iv_infoClose.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();

			}
		});
	}
}
